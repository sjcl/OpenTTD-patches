/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file console_cmds.cpp Implementation of the console hooks. */

#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/stdafx.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/company_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/passenger_service_database.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/passenger_journey_shadow.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/passenger_journey_active.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/core/string_consumer.hpp"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/console_internal.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/crashlog.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/debug.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/engine_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/landscape.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/sl/saveload_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/core/network_game_info.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network_admin.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network_client.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network_server.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/command_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/command_log.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/settings_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/fios.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/fileio_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/fontcache.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/screenshot.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/genworld.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/string_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/strings_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/viewport_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/window_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/date_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/timer/timer.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/timer/timer_game_calendar.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/company_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/gamelog.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/ai/ai.hpp"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/ai/ai_config.hpp"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/newgrf.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/newgrf_profiling.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/console_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/engine_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/engine_override.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/road.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/rail.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/game/game.hpp"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/aircraft.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/airport.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/station_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/waypoint_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/waypoint_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/economy_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/town.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/town_type.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/town_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/industry.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/string_func_extra.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/linkgraph/linkgraphjob.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/base_media_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/base_media_graphics.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/debug_settings.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/walltime_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/debug_desync.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/scope_info.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/event_logs.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/tile_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/object_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/newgrf_newsignals.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/roadstop_base.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/core/backup_type.hpp"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/company_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/misc_cmd.h"
#ifdef WITH_PASSENGER_BENCHMARK
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/order_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/timetable_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/vehicle_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/road_map.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/road_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/station_cmd.h"
#endif
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/order_backup.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/cheat_func.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/walltime_func.h"
#include <time.h>

#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/3rdparty/cpp-btree/btree_set.h"

#include <sstream>

#if defined(WITH_ZLIB)
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/network/network_content.h"
#endif /* WITH_ZLIB */

#include "table/strings.h"

#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/sl/saveload.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/build-wpr-f7c44f0d/save-integrity/integrity.h"
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/src/safeguards.h"

/* scriptfile handling */
static uint _script_current_depth; ///< Depth of scripts running (used to abort execution when #ConReturn is encountered).

/* Scheduled execution handling. */
static std::string _scheduled_monthly_script; ///< Script scheduled to execute by the 'schedule' console command (empty if no script is scheduled).

/** Timer that runs every month of game time for the 'schedule' console command. */
static const IntervalTimer<TimerGameCalendar> _scheduled_monthly_timer = {{TimerGameCalendar::Trigger::Month, TimerGameCalendar::Priority::None}, [](auto) {
	if (_scheduled_monthly_script.empty()) {
		return;
	}

	/* Clear the schedule before rather than after the script to allow the script to itself call
	 * schedule without it getting immediately cleared. */
	const std::string filename = _scheduled_monthly_script;
	_scheduled_monthly_script.clear();

	IConsolePrint(CC_DEFAULT, "Executing scheduled script file '{}'...", filename);
	IConsoleCmdExec(fmt::format("exec {}", filename));
}};

/**
 * Parse an integer using #ParseInteger and convert it to the requested type.
 * @param arg The string to be converted.
 * @tparam T The type to return.
 * @return The number in the given type, or std::nullopt when it could not be parsed.
 */
template <typename T>
static std::optional<T> ParseType(std::string_view arg)
{
	auto i = ParseInteger(arg);
	if (i.has_value()) return static_cast<T>(*i);
	return std::nullopt;
}

/** File list storage for the console, for caching the last 'ls' command. */
class ConsoleFileList : public FileList {
public:
	ConsoleFileList(AbstractFileType abstract_filetype, bool show_dirs) : FileList(), abstract_filetype(abstract_filetype), show_dirs(show_dirs)
	{
	}

	/** Declare the file storage cache as being invalid, also clears all stored files. */
	void InvalidateFileList()
	{
		this->clear();
		this->file_list_valid = false;
	}

	/**
	 * (Re-)validate the file storage cache. Only makes a change if the storage was invalid, or if \a force_reload.
	 * @param force_reload Always reload the file storage cache.
	 */
	void ValidateFileList(bool force_reload = false)
	{
		if (force_reload || !this->file_list_valid) {
			this->BuildFileList(this->abstract_filetype, SaveLoadOperation::Load, this->show_dirs);
			this->file_list_valid = true;
		}
	}

	AbstractFileType abstract_filetype; ///< The abstract file type to list.
	bool show_dirs; ///< Whether to show directories in the file list.
	bool file_list_valid = false; ///< If set, the file list is valid.
};

static ConsoleFileList _console_file_list_savegame{AbstractFileType::Savegame, true}; ///< File storage cache for savegames.
static ConsoleFileList _console_file_list_scenario{AbstractFileType::Scenario, false}; ///< File storage cache for scenarios.
static ConsoleFileList _console_file_list_heightmap{AbstractFileType::Heightmap, false}; ///< File storage cache for heightmaps.

/****************
 * command hooks
 ****************/

/**
 * Check network availability and inform in console about failure of detection.
 * @param echo Whether to print an error message or not.
 * @return \c true iff the network is available.
 */
static inline bool NetworkAvailable(bool echo)
{
	if (!_network_available) {
		if (echo) IConsolePrint(CC_ERROR, "You cannot use this command because there is no network available.");
		return false;
	}
	return true;
}

/**
 * Check whether we are a server.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookServerOnly(bool echo)
{
	if (!NetworkAvailable(echo)) return ConsoleHookResult::Disallow;

	if (!_network_server) {
		if (echo) IConsolePrint(CC_ERROR, "This command is only available to a network server.");
		return ConsoleHookResult::Disallow;
	}
	return ConsoleHookResult::Allow;
}

/**
 * Check whether we are a client in a network game.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookClientOnly(bool echo)
{
	if (!NetworkAvailable(echo)) return ConsoleHookResult::Disallow;

	if (_network_server) {
		if (echo) IConsolePrint(CC_ERROR, "This command is not available to a network server.");
		return ConsoleHookResult::Disallow;
	}
	return ConsoleHookResult::Allow;
}

/**
 * Check whether we are in a multiplayer game.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookNeedNetwork(bool echo)
{
	if (!NetworkAvailable(echo)) return ConsoleHookResult::Disallow;

	if (!_networking || (!_network_server && !MyClient::IsConnected())) {
		if (echo) IConsolePrint(CC_ERROR, "Not connected. This command is only available in multiplayer.");
		return ConsoleHookResult::Disallow;
	}
	return ConsoleHookResult::Allow;
}

/**
 * Check whether we are in a multiplayer game and are playing, i.e. we are not the dedicated server, or not in a network game.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookNeedNonDedicatedOrNoNetwork(bool echo)
{
	if (!_networking) return ConsoleHookResult::Allow;

	if (!NetworkAvailable(echo)) return ConsoleHookResult::Disallow;

	if (_network_dedicated) {
		if (echo) IConsolePrint(CC_ERROR, "This command is not available to a dedicated network server.");
		return ConsoleHookResult::Disallow;
	}
	return ConsoleHookResult::Allow;
}

/**
 * Check whether we are in singleplayer mode.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookNoNetwork(bool echo)
{
	if (_networking) {
		if (echo) IConsolePrint(CC_ERROR, "This command is forbidden in multiplayer.");
		return ConsoleHookResult::Disallow;
	}
	return ConsoleHookResult::Allow;
}

/**
 * Check if are either in singleplayer or a server.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookServerOrNoNetwork(bool echo)
{
	if (_networking && !_network_server) {
		if (echo) IConsolePrint(CC_ERROR, "This command is only available to a network server, or in single-player.");
		return ConsoleHookResult::Disallow;
	}
	return ConsoleHookResult::Allow;
}

/**
 * Check whether NewGRF developer tools are enabled.
 * @copydoc IConsoleHook
 */
static ConsoleHookResult ConHookNewGRFDeveloperTool(bool echo)
{
	if (_settings_client.gui.newgrf_developer_tools) {
		if (_game_mode == GameMode::Menu) {
			if (echo) IConsolePrint(CC_ERROR, "This command is only available in-game and in the editor.");
			return ConsoleHookResult::Disallow;
		}
		return ConHookNoNetwork(echo);
	}
	return ConsoleHookResult::Hide;
}

static ConsoleHookResult ConHookSpecialCmd(bool echo)
{
	if (HasBit(_misc_debug_flags, MDF_SPECIAL_CMDS)) {
		return ConHookNoNetwork(echo);
	}
	return ConsoleHookResult::Hide;
}

/**
 * Reset status of all engines.
 * @copydoc IConsoleCmdProc
 */
static bool ConResetEngines(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Reset status data of all engines. This might solve some issues with 'lost' engines. Usage: 'resetengines'.");
		return true;
	}

	extern uint32_t _engine_seed;
	_engine_seed = 0; // Reset engine seed to re-randomise engine values.
	StartupEngines();
	return true;
}

/**
 * Reset status of the engine pool.
 * @note Resetting the pool only succeeds when there are no vehicles ingame.
 * @copydoc IConsoleCmdProc
 */
static bool ConResetEnginePool(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Reset NewGRF allocations of engine slots. This will remove invalid engine definitions, and might make default engines available again.");
		return true;
	}

	if (_game_mode == GameMode::Menu) {
		IConsolePrint(CC_ERROR, "This command is only available in-game and in the editor.");
		return true;
	}

	if (!EngineOverrideManager::ResetToCurrentNewGRFConfig()) {
		IConsolePrint(CC_ERROR, "This can only be done when there are no vehicles in the game.");
		return true;
	}

	return true;
}

#ifdef _DEBUG
/**
 * Reset a tile to bare land in debug mode.
 * @copydoc IConsoleCmdProc
 */
static bool ConResetTile(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Reset a tile to bare land. Usage: 'resettile <tile>'.");
		IConsolePrint(CC_HELP, "Tile can be either decimal (34161) or hexadecimal (0x4a5B).");
		return true;
	}

	if (argv.size() == 2) {
		auto result = ParseInteger(argv[1], 0);
		if (result.has_value() && IsValidTile(TileIndex{*result})) {
			DoClearSquare(TileIndex{*result});
			return true;
		}
	}

	return false;
}
#endif /* _DEBUG */

/**
 * Zoom map to given level.
 * @copydoc IConsoleCmdProc
 */
static bool ConZoomToLevel(std::span<std::string_view> argv)
{
	switch (argv.size()) {
		case 0:
			IConsolePrint(CC_HELP, "Set the current zoom level of the main viewport.");
			IConsolePrint(CC_HELP, "Usage: 'zoomto <level>'.");

			if (ZoomLevel::Min < _settings_client.gui.zoom_min) {
				IConsolePrint(CC_HELP, "The lowest zoom-in level allowed by current client settings is {}.", std::max(ZoomLevel::Min, _settings_client.gui.zoom_min));
			} else {
				IConsolePrint(CC_HELP, "The lowest supported zoom-in level is {}.", std::max(ZoomLevel::Min, _settings_client.gui.zoom_min));
			}

			if (_settings_client.gui.zoom_max < ZoomLevel::Max) {
				IConsolePrint(CC_HELP, "The highest zoom-out level allowed by current client settings is {}.", std::min(_settings_client.gui.zoom_max, ZoomLevel::Max));
			} else {
				IConsolePrint(CC_HELP, "The highest supported zoom-out level is {}.", std::min(_settings_client.gui.zoom_max, ZoomLevel::Max));
			}
			return true;

		case 2: {
			auto level = ParseInteger<std::underlying_type_t<ZoomLevel>>(argv[1]);
			if (level.has_value()) {
				auto zoom_lvl = static_cast<ZoomLevel>(*level);
				if (!IsInsideMM(zoom_lvl, ZoomLevel::Begin, ZoomLevel::End)) {
					IConsolePrint(CC_ERROR, "Invalid zoom level. Valid range is {} to {}.", ZoomLevel::Min, ZoomLevel::Max);
				} else if (!IsInsideMM(zoom_lvl, _settings_client.gui.zoom_min, _settings_client.gui.zoom_max + 1)) {
					IConsolePrint(CC_ERROR, "Current client settings limit zoom levels to range {} to {}.", _settings_client.gui.zoom_min, _settings_client.gui.zoom_max);
				} else {
					Window *w = GetMainWindow();
					Viewport *vp = w->viewport;
					while (vp->zoom > zoom_lvl) DoZoomInOutWindow(ZOOM_IN, w);
					while (vp->zoom < zoom_lvl) DoZoomInOutWindow(ZOOM_OUT, w);
				}
				return true;
			}
			break;
		}
	}

	return false;
}

/**
 * Scroll to a tile on the map.
 * @copydoc IConsoleCmdProc
 */
static bool ConScrollToTile(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Center the screen on a given tile.");
		IConsolePrint(CC_HELP, "Usage: 'scrollto [instant] <tile>' or 'scrollto [instant] <x> <y>'.");
		IConsolePrint(CC_HELP, "Numbers can be either decimal (34161) or hexadecimal (0x4a5B).");
		IConsolePrint(CC_HELP, "'instant' will immediately move and redraw viewport without smooth scrolling.");
		return true;
	}
	if (argv.size() < 2) return false;

	uint32_t arg_index = 1;
	bool instant = false;
	if (argv[arg_index] == "instant") {
		++arg_index;
		instant = true;
	}

	switch (argv.size() - arg_index) {
		case 1: {
			auto result = ParseInteger(argv[arg_index], 0);
			if (result.has_value()) {
				if (*result >= Map::Size()) {
					IConsolePrint(CC_ERROR, "Tile does not exist.");
					return true;
				}
				ScrollMainWindowToTile(TileIndex{*result}, instant);
				return true;
			}
			break;
		}

		case 2: {
			auto x = ParseInteger(argv[arg_index], 0);
			auto y = ParseInteger(argv[arg_index + 1], 0);
			if (x.has_value() && y.has_value()) {
				if (*x >= Map::SizeX() || *y >= Map::SizeY()) {
					IConsolePrint(CC_ERROR, "Tile does not exist.");
					return true;
				}
				ScrollMainWindowToTile(TileXY(*x, *y), instant);
				return true;
			}
			break;
		}
	}

	return false;
}

/**
 * Highlight a tile on the map.
 * param x tile number or tile x coordinate.
 * param y optional y coordinate.
 * @note When only one argument is given it is interpreted as the tile number.
 *       When two arguments are given, they are interpreted as the tile's x
 *       and y coordinates.
 * @return True when either console help was shown or a proper amount of parameters given.
 */
static bool ConHighlightTile(std::span<std::string_view> argv)
{
	switch (argv.size()) {
		case 0:
			IConsolePrint(CC_HELP, "Highlight a given tile.");
			IConsolePrint(CC_HELP, "Usage: 'highlight_tile <tile>' or 'highlight_tile <x> <y>'");
			IConsolePrint(CC_HELP, "Numbers can be either decimal (34161) or hexadecimal (0x4a5B).");
			return true;

		case 2: {
			auto result = ParseInteger(argv[1]);
			if (result.has_value()) {
				if (*result >= Map::Size()) {
					IConsolePrint(CC_ERROR, "Tile does not exist.");
					return true;
				}
				SetRedErrorSquare((TileIndex)*result);
				return true;
			}
			break;
		}

		case 3: {
			auto x = ParseInteger(argv[1]);
			auto y = ParseInteger(argv[2]);
			if (x.has_value() && y.has_value()) {
				if (*x >= Map::SizeX() || *y >= Map::SizeY()) {
					IConsolePrint(CC_ERROR, "Tile does not exist.");
					return true;
				}
				SetRedErrorSquare(TileXY(*x, *y));
				return true;
			}
			break;
		}
	}

	return false;
}

/**
 * Save the map to a file.
 * @copydoc IConsoleCmdProc
 */
static bool ConSave(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Save the current game. Usage: 'save <filename>'.");
		return true;
	}

	if (argv.size() == 2) {
		std::string filename = fmt::format("{}.sav", argv[1]);
		IConsolePrint(CC_DEFAULT, "Saving map...");

		if (SaveOrLoad(filename, SaveLoadOperation::Save, DetailedFileType::GameFile, Subdirectory::Save) != SaveLoadResult::Ok) {
			IConsolePrint(CC_ERROR, "Saving map failed.");
		} else {
			IConsolePrint(CC_INFO, "Map successfully saved to '{}'.", filename);
		}
		return true;
	}

	return false;
}

/**
 * Explicitly save the configuration.
 * @copydoc IConsoleCmdProc
 */
static bool ConSaveConfig(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Saves the configuration for new games to the configuration file, typically 'openttd.cfg'.");
		IConsolePrint(CC_HELP, "It does not save the configuration of the current game to the configuration file.");
		return true;
	}

	SaveToConfig(STCF_ALL);
	IConsolePrint(CC_DEFAULT, "Saved config.");
	return true;
}

/** Load a savegame. @copydoc IConsoleCmdProc */
static bool ConLoad(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Load a game by name or index. Usage: 'load <file | number>'.");
		return true;
	}

	if (argv.size() != 2) return false;

	std::string_view file = argv[1];
	_console_file_list_savegame.ValidateFileList();
	const FiosItem *item = _console_file_list_savegame.FindItem(file);
	if (item != nullptr) {
		if (item->type.abstract == AbstractFileType::Savegame) {
			_switch_mode = SwitchMode::LoadGame;
			_file_to_saveload.Set(*item);
		} else {
			IConsolePrint(CC_ERROR, "'{}' is not a savegame.", file);
		}
	} else {
		IConsolePrint(CC_ERROR, "'{}' cannot be found.", file);
	}

	return true;
}

/** Load a scenario. @copydoc IConsoleCmdProc */
static bool ConLoadScenario(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Load a scenario by name or index. Usage: 'load_scenario <file | number>'.");
		return true;
	}

	if (argv.size() != 2) return false;

	std::string_view file = argv[1];
	_console_file_list_scenario.ValidateFileList();
	const FiosItem *item = _console_file_list_scenario.FindItem(file);
	if (item != nullptr) {
		if (item->type.abstract == AbstractFileType::Scenario) {
			_switch_mode = SwitchMode::LoadGame;
			_file_to_saveload.Set(*item);
		} else {
			IConsolePrint(CC_ERROR, "'{}' is not a scenario.", file);
		}
	} else {
		IConsolePrint(CC_ERROR, "'{}' cannot be found.", file);
	}

	return true;
}

/** Load a heightmap. @copydoc IConsoleCmdProc */
static bool ConLoadHeightmap(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Load a heightmap by name or index. Usage: 'load_heightmap <file | number>'.");
		return true;
	}

	if (argv.size() != 2) return false;

	std::string_view file = argv[1];
	_console_file_list_heightmap.ValidateFileList();
	const FiosItem *item = _console_file_list_heightmap.FindItem(file);
	if (item != nullptr) {
		if (item->type.abstract == AbstractFileType::Heightmap) {
			_switch_mode = SwitchMode::StartHeightmap;
			_file_to_saveload.Set(*item);
		} else {
			IConsolePrint(CC_ERROR, "'{}' is not a heightmap.", file);
		}
	} else {
		IConsolePrint(CC_ERROR, "'{}' cannot be found.", file);
	}

	return true;
}

/** Remove a savegame file from disk. @copydoc IConsoleCmdProc */
static bool ConRemove(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Remove a savegame by name or index. Usage: 'rm <file | number>'.");
		return true;
	}

	if (argv.size() != 2) return false;

	std::string_view file = argv[1];
	_console_file_list_savegame.ValidateFileList();
	const FiosItem *item = _console_file_list_savegame.FindItem(file);
	if (item != nullptr) {
		if (item->type.abstract == AbstractFileType::Savegame) {
			if (!FioRemove(item->name)) {
				IConsolePrint(CC_ERROR, "Failed to delete '{}'.", item->name);
			}
		} else {
			IConsolePrint(CC_ERROR, "'{}' is not a savegame.", file);
		}
	} else {
		IConsolePrint(CC_ERROR, "'{}' could not be found.", file);
	}

	_console_file_list_savegame.InvalidateFileList();
	return true;
}


/** List all the files in the current dir via console. @copydoc IConsoleCmdProc */
static bool ConListFiles(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List all loadable savegames and directories in the current dir via console. Usage: 'ls | dir'.");
		return true;
	}

	_console_file_list_savegame.ValidateFileList(true);
	for (uint i = 0; i < _console_file_list_savegame.size(); i++) {
		IConsolePrint(CC_DEFAULT, "{}) {}", i, _console_file_list_savegame[i].title.GetDecodedString());
	}

	return true;
}

/** List all the scenarios. @copydoc IConsoleCmdProc */
static bool ConListScenarios(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List all loadable scenarios. Usage: 'list_scenarios'.");
		return true;
	}

	_console_file_list_scenario.ValidateFileList(true);
	for (uint i = 0; i < _console_file_list_scenario.size(); i++) {
		IConsolePrint(CC_DEFAULT, "{}) {}", i, _console_file_list_scenario[i].title.GetDecodedString());
	}

	return true;
}

/** List all the heightmaps. @copydoc IConsoleCmdProc */
static bool ConListHeightmaps(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List all loadable heightmaps. Usage: 'list_heightmaps'.");
		return true;
	}

	_console_file_list_heightmap.ValidateFileList(true);
	for (uint i = 0; i < _console_file_list_heightmap.size(); i++) {
		IConsolePrint(CC_DEFAULT, "{}) {}", i, _console_file_list_heightmap[i].title.GetDecodedString());
	}

	return true;
}

/** Change the dir via console. @copydoc IConsoleCmdProc */
static bool ConChangeDirectory(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Change the dir via console. Usage: 'cd <directory | number>'.");
		return true;
	}

	if (argv.size() != 2) return false;

	std::string_view file = argv[1];
	_console_file_list_savegame.ValidateFileList(true);
	const FiosItem *item = _console_file_list_savegame.FindItem(file);
	if (item != nullptr) {
		switch (item->type.detailed) {
			case DetailedFileType::FiosDirectory:
			case DetailedFileType::FiosDrive:
			case DetailedFileType::FiosParent:
				FiosBrowseTo(item);
				break;
			default: IConsolePrint(CC_ERROR, "{}: Not a directory.", file);
		}
	} else {
		IConsolePrint(CC_ERROR, "{}: No such file or directory.", file);
	}

	_console_file_list_savegame.InvalidateFileList();
	return true;
}

/** Print the current working directory. @copydoc IConsoleCmdProc */
static bool ConPrintWorkingDirectory(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Print out the current working directory. Usage: 'pwd'.");
		return true;
	}

	/* XXX - Workaround for broken file handling */
	_console_file_list_savegame.ValidateFileList(true);
	_console_file_list_savegame.InvalidateFileList();

	IConsolePrint(CC_DEFAULT, FiosGetCurrentPath());
	return true;
}

/** Clear the console's buffer. @copydoc IConsoleCmdProc */
static bool ConClearBuffer(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Clear the console buffer. Usage: 'clear'.");
		return true;
	}

	IConsoleClearBuffer();
	SetWindowDirty(WindowClass::Console, 0);
	return true;
}


/**********************************
 * Network Core Console Commands
 **********************************/

/**
 * Helper to kick or ban a user.
 * @param arg The client id or IP address.
 * @param ban Whether to ban, when \c false only a kick is performed.
 * @param reason The reason for this action.
 * @return \c true iff the command is handled correctly, i.e. \c false to show a help message.
 */
static bool ConKickOrBan(std::string_view arg, bool ban, std::string_view reason)
{
	uint n;

	if (arg.find_first_of(".:") == std::string::npos) { // banning with ID
		auto client_id = ParseType<ClientID>(arg);
		if (!client_id.has_value()) {
			IConsolePrint(CC_ERROR, "The given client-id is not a valid number.");
			return true;
		}

		/* Don't kill the server, or the client doing the rcon. The latter can't be kicked because
		 * kicking frees closes and subsequently free the connection related instances, which we
		 * would be reading from and writing to after returning. So we would read or write data
		 * from freed memory up till the segfault triggers. */
		if (*client_id == ClientID::Server || *client_id == _redirect_console_to_client) {
			IConsolePrint(CC_ERROR, "You can not {} yourself!", ban ? "ban" : "kick");
			return true;
		}

		NetworkClientInfo *ci = NetworkClientInfo::GetByClientID(*client_id);
		if (ci == nullptr) {
			IConsolePrint(CC_ERROR, "Invalid client-id.");
			return true;
		}

		if (!ban) {
			/* Kick only this client, not all clients with that IP */
			NetworkServerKickClient(*client_id, reason);
			return true;
		}

		/* When banning, kick+ban all clients with that IP */
		n = NetworkServerKickOrBanIP(*client_id, ban, reason);
	} else {
		n = NetworkServerKickOrBanIP(arg, ban, reason);
	}

	if (n == 0) {
		IConsolePrint(CC_DEFAULT, ban ? "Client not online, address added to banlist." : "Client not found.");
	} else {
		IConsolePrint(CC_DEFAULT, "{}ed {} client(s).", ban ? "Bann" : "Kick", n);
	}

	return true;
}

/** Kick a user from a network game. @copydoc IConsoleCmdProc */
static bool ConKick(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Kick a client from a network game. Usage: 'kick <ip | client-id> [<kick-reason>]'.");
		IConsolePrint(CC_HELP, "For client-id's, see the command 'clients'.");
		return true;
	}

	if (argv.size() != 2 && argv.size() != 3) return false;

	/* No reason supplied for kicking */
	if (argv.size() == 2) return ConKickOrBan(argv[1], false, {});

	/* Reason for kicking supplied */
	size_t kick_message_length = argv[2].size();
	if (kick_message_length >= 255) {
		IConsolePrint(CC_ERROR, "Maximum kick message length is 254 characters. You entered {} characters.", kick_message_length);
		return false;
	} else {
		return ConKickOrBan(argv[1], false, argv[2]);
	}
}

/** Ban a user from a network game. @copydoc IConsoleCmdProc */
static bool ConBan(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Ban a client from a network game. Usage: 'ban <ip | client-id> [<ban-reason>]'.");
		IConsolePrint(CC_HELP, "For client-id's, see the command 'clients'.");
		IConsolePrint(CC_HELP, "If the client is no longer online, you can still ban their IP.");
		return true;
	}

	if (argv.size() != 2 && argv.size() != 3) return false;

	/* No reason supplied for kicking */
	if (argv.size() == 2) return ConKickOrBan(argv[1], true, {});

	/* Reason for kicking supplied */
	size_t kick_message_length = argv[2].size();
	if (kick_message_length >= 255) {
		IConsolePrint(CC_ERROR, "Maximum kick message length is 254 characters. You entered {} characters.", kick_message_length);
		return false;
	} else {
		return ConKickOrBan(argv[1], true, argv[2]);
	}
}

/** Unban a user from a network game. @copydoc IConsoleCmdProc */
static bool ConUnBan(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Unban a client from a network game. Usage: 'unban <ip | banlist-index>'.");
		IConsolePrint(CC_HELP, "For a list of banned IP's, see the command 'banlist'.");
		return true;
	}

	if (argv.size() != 2) return false;

	/* Try by IP. */
	uint index;
	for (index = 0; index < _network_ban_list.size(); index++) {
		if (_network_ban_list[index] == argv[1]) break;
	}

	/* Try by index. */
	if (index >= _network_ban_list.size()) {
		index = ParseInteger(argv[1]).value_or(0) - 1U; // let it wrap
	}

	if (index < _network_ban_list.size()) {
		IConsolePrint(CC_DEFAULT, "Unbanned {}.", _network_ban_list[index]);
		_network_ban_list.erase(_network_ban_list.begin() + index);
	} else {
		IConsolePrint(CC_DEFAULT, "Invalid list index or IP not in ban-list.");
		IConsolePrint(CC_DEFAULT, "For a list of banned IP's, see the command 'banlist'.");
	}

	return true;
}

/** Show the list of banned clients. @copydoc IConsoleCmdProc */
static bool ConBanList(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List the IP's of banned clients: Usage 'banlist'.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "Banlist:");

	uint i = 1;
	for (const auto &entry : _network_ban_list) {
		IConsolePrint(CC_DEFAULT, "  {}) {}", i, entry);
		i++;
	}

	return true;
}

/** Manually pause the game. @copydoc IConsoleCmdProc */
static bool ConPauseGame(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Pause a network game. Usage: 'pause'.");
		return true;
	}

	if (_game_mode == GameMode::Menu) {
		IConsolePrint(CC_ERROR, "This command is only available in-game and in the editor.");
		return true;
	}

	if (!_pause_mode.Test(PauseMode::Normal)) {
		Command<Commands::Pause>::Post(PauseMode::Normal, true);
		if (!_networking) IConsolePrint(CC_DEFAULT, "Game paused.");
	} else {
		IConsolePrint(CC_DEFAULT, "Game is already paused.");
	}

	return true;
}

/** Manually unpause the game. @copydoc IConsoleCmdProc */
static bool ConUnpauseGame(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Unpause a network game. Usage: 'unpause'.");
		return true;
	}

	if (_game_mode == GameMode::Menu) {
		IConsolePrint(CC_ERROR, "This command is only available in-game and in the editor.");
		return true;
	}

    /* Copied measurement TU: keep the product's error-pause policy intact. */
    if (getenv("OPENTTD_PASSENGER_MEASURE") != nullptr && _pause_mode.Test(PauseMode::Error)) {
        IConsolePrint(CC_WARNING, "Measurement resumed a NewGRF error pause.");
        Command<Commands::Pause>::Post(PauseMode::Error, false);
    }
	if (_pause_mode.Test(PauseMode::Normal)) {
		Command<Commands::Pause>::Post(PauseMode::Normal, false);
		if (!_networking) IConsolePrint(CC_DEFAULT, "Game unpaused.");
	} else if (_pause_mode.Test(PauseMode::Error)) {
		IConsolePrint(CC_DEFAULT, "Game is in error state and cannot be unpaused via console.");
	} else if (_pause_mode.Any()) {
		IConsolePrint(CC_DEFAULT, "Game cannot be unpaused manually; disable pause_on_join/min_active_clients.");
	} else {
		IConsolePrint(CC_DEFAULT, "Game is already unpaused.");
	}

	return true;
}

static bool ConStepGame(std::span<std::string_view> argv)
{
	if (argv.empty() || argv.size() > 2) {
		IConsolePrint(CC_HELP, "Advances the game for a certain amount of ticks (default 1). Usage: 'step [n]'");
		return true;
	}
	uint32_t n = 1;
	if (argv.size() > 1) {
		n = ParseInteger(argv[1]).value_or(0);
	}

	extern void UnpauseStepGame(uint32_t steps);
	UnpauseStepGame(n);

	return true;
}

/** Run a console command on the server. @copydoc IConsoleCmdProc */
static bool ConRcon(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Remote control the server from another client. Usage: 'rcon <password> <command>'.");
		IConsolePrint(CC_HELP, "Remember to enclose the command in quotes, otherwise only the first parameter is sent.");
		IConsolePrint(CC_HELP, "When your client's public key is in the 'authorized keys' for 'rcon', '*' may be used instead of the password.");
		return true;
	}

	if (argv.size() < 3) return false;

	if (_network_server) {
		IConsoleCmdExec(argv[2]);
	} else {
		NetworkClientSendRcon(argv[1], argv[2]);
	}
	return true;
}

static bool ConSettingsAccess(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Enable changing game settings from this client. Usage: 'settings_access <password>'");
		IConsolePrint(CC_HELP, "Send an empty password \"\" to drop access");
		IConsolePrint(CC_HELP, "When your client's public key is in the 'authorized keys' for 'settings', the password is not checked and may be '*'.");
		return true;
	}

	if (argv.size() < 2) return false;

	if (!_network_server) {
		NetworkClientSendSettingsPassword(argv[1]);
	}
	return true;
}

/** Get the status of connected clients. @copydoc IConsoleCmdProc */
static bool ConStatus(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List the status of all clients connected to the server. Usage 'status'.");
		return true;
	}

	NetworkServerShowStatusToConsole();
	return true;
}

/** Get information like client/company count/limits for the server. @copydoc IConsoleCmdProc */
static bool ConServerInfo(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List current and maximum client/company limits. Usage 'server_info'.");
		IConsolePrint(CC_HELP, "You can change these values by modifying settings 'network.max_clients' and 'network.max_companies'.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "Invite code:                {}", _network_server_invite_code);
	IConsolePrint(CC_DEFAULT, "Current/maximum clients:    {:3d}/{:3d}", _network_game_info.clients_on, _settings_client.network.max_clients);
	IConsolePrint(CC_DEFAULT, "Current/maximum companies:  {:3d}/{:3d}", Company::GetNumItems(), _settings_client.network.max_companies);
	IConsolePrint(CC_DEFAULT, "Current spectators:         {:3d}", NetworkSpectatorCount());

	return true;
}

/** Change the name of a client. @copydoc IConsoleCmdProc */
static bool ConClientNickChange(std::span<std::string_view> argv)
{
	if (argv.size() != 3) {
		IConsolePrint(CC_HELP, "Change the nickname of a connected client. Usage: 'client_name <client-id> <new-name>'.");
		IConsolePrint(CC_HELP, "For client-id's, see the command 'clients'.");
		return true;
	}

	auto client_id = ParseType<ClientID>(argv[1]);
	if (!client_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given client-id is not a valid number.");
		return true;
	}

	if (*client_id == ClientID::Server) {
		IConsolePrint(CC_ERROR, "Please use the command 'name' to change your own name!");
		return true;
	}

	if (NetworkClientInfo::GetByClientID(*client_id) == nullptr) {
		IConsolePrint(CC_ERROR, "Invalid client-id.");
		return true;
	}

	std::string client_name{StrTrimView(argv[2], StringConsumer::WHITESPACE_NO_NEWLINE)};
	if (!NetworkIsValidClientName(client_name)) {
		IConsolePrint(CC_ERROR, "Cannot give a client an empty name.");
		return true;
	}

	if (!NetworkServerChangeClientName(*client_id, client_name)) {
		IConsolePrint(CC_ERROR, "Cannot give a client a duplicate name.");
	}

	return true;
}

/**
 * Helper to parse a company ID. Note that 'Company #1' has ID 0.
 * @param arg The string to get the company ID from.
 * @return The company's ID, or std::nullopt when no valid ID was found.
 */
static std::optional<CompanyID> ParseCompanyID(std::string_view arg)
{
	auto company_id = ParseType<CompanyID>(arg);
	if (company_id.has_value() && *company_id <= MAX_COMPANIES) return static_cast<CompanyID>(*company_id - 1);
	return company_id;
}

/** As client, join a company. @copydoc IConsoleCmdProc */
static bool ConJoinCompany(std::span<std::string_view> argv)
{
	if (argv.size() < 2) {
		IConsolePrint(CC_HELP, "Request joining another company. Usage: 'join <company-id> [<password>]'.");
		IConsolePrint(CC_HELP, "For valid company-id see company list, use 255 for spectator.");
		return true;
	}

	auto company_id = ParseCompanyID(argv[1]);
	if (!company_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	if (!_networking) {
		/* Check we have a valid company id! */
		if (!Company::IsValidID(*company_id)) {
			IConsolePrint(CC_ERROR, "Company does not exist. Company-id must be between 1 and {}.", MAX_COMPANIES);
			return true;
		}

		OrderBackup::Reset();
		SetLocalCompany(*company_id);
		_cheats.switch_company.been_used = true;
		return true;
	}

	const NetworkClientInfo *info = NetworkClientInfo::GetByClientID(_network_own_client_id);
	if (info == nullptr) {
		IConsolePrint(CC_ERROR, "You have not joined the game yet!");
		return true;
	}

	/* Check we have a valid company id! */
	if (!Company::IsValidID(*company_id) && *company_id != COMPANY_SPECTATOR) {
		IConsolePrint(CC_ERROR, "Company does not exist. Company-id must be between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	if (info->client_playas == *company_id) {
		IConsolePrint(CC_ERROR, "You are already there!");
		return true;
	}

	if (*company_id != COMPANY_SPECTATOR && !Company::IsHumanID(*company_id)) {
		IConsolePrint(CC_ERROR, "Cannot join AI company.");
		return true;
	}

	/* Check if the company requires a password */
	if (NetworkCompanyIsPassworded(*company_id) && argv.size() < 3) {
		IConsolePrint(CC_ERROR, "Company {} requires a password to join.", *company_id + 1);
		return true;
	}

	/* non-dedicated server may just do the move! */
	if (_network_server) {
		NetworkServerDoMove(ClientID::Server, *company_id);
	} else {
		NetworkClientRequestMove(*company_id, NetworkCompanyIsPassworded(*company_id) ? argv[2] : "");
	}

	return true;
}

/** Move a client to a specific company. @copydoc IConsoleCmdProc */
static bool ConMoveClient(std::span<std::string_view> argv)
{
	if (argv.size() < 3) {
		IConsolePrint(CC_HELP, "Move a client to another company. Usage: 'move <client-id> <company-id>'.");
		IConsolePrint(CC_HELP, "For valid client-id see 'clients', for valid company-id see 'companies', use 255 for moving to spectators.");
		return true;
	}

	auto client_id = ParseType<ClientID>(argv[1]);
	if (!client_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given client-id is not a valid number.");
		return true;
	}
	const NetworkClientInfo *ci = NetworkClientInfo::GetByClientID(*client_id);

	auto company_id = ParseCompanyID(argv[2]);
	if (!company_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	/* check the client exists */
	if (ci == nullptr) {
		IConsolePrint(CC_ERROR, "Invalid client-id, check the command 'clients' for valid client-id's.");
		return true;
	}

	if (!Company::IsValidID(*company_id) && *company_id != COMPANY_SPECTATOR) {
		IConsolePrint(CC_ERROR, "Company does not exist. Company-id must be between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	if (*company_id != COMPANY_SPECTATOR && !Company::IsHumanID(*company_id)) {
		IConsolePrint(CC_ERROR, "You cannot move clients to AI companies.");
		return true;
	}

	if (ci->client_id == ClientID::Server && _network_dedicated) {
		IConsolePrint(CC_ERROR, "You cannot move the server!");
		return true;
	}

	if (ci->client_playas == *company_id) {
		IConsolePrint(CC_ERROR, "You cannot move someone to where they already are!");
		return true;
	}

	/* we are the server, so force the update */
	NetworkServerDoMove(ci->client_id, *company_id);

	return true;
}

/** Remove a company from the game. @copydoc IConsoleCmdProc */
static bool ConResetCompany(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Remove an idle company from the game. Usage: 'reset_company <company-id>'.");
		IConsolePrint(CC_HELP, "For company-id's, see the list of companies from the dropdown menu. Company 1 is 1, etc.");
		return true;
	}

	if (argv.size() != 2) return false;

	auto index = ParseCompanyID(argv[1]);
	if (!index.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	/* Check valid range */
	if (!Company::IsValidID(*index)) {
		IConsolePrint(CC_ERROR, "Company does not exist. company-id must be between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	if (!Company::IsHumanID(*index)) {
		IConsolePrint(CC_ERROR, "Company is owned by an AI.");
		return true;
	}

	if (NetworkCompanyHasClients(*index)) {
		IConsolePrint(CC_ERROR, "Cannot remove company: a client is connected to that company.");
		return false;
	}
	const NetworkClientInfo *ci = NetworkClientInfo::GetByClientID(ClientID::Server);
	assert(ci != nullptr);
	if (ci->client_playas == *index) {
		IConsolePrint(CC_ERROR, "Cannot remove company: the server is connected to that company.");
		return true;
	}

	/* It is safe to remove this company */
	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::Delete, *index, CompanyRemoveReason::Manual, ClientID::Invalid, {});
	IConsolePrint(CC_DEFAULT, "Company deleted.");

	return true;
}

static bool ConOfferCompanySale(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Offer a company for sale. Usage: 'offer_company_sale <company-id>'");
		IConsolePrint(CC_HELP, "For company-id's, see the list of companies from the dropdown menu. Company 1 is 1, etc.");
		return true;
	}

	if (argv.size() != 2) return false;

	auto index = ParseCompanyID(argv[1]);
	if (!index.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	/* Check valid range */
	if (!Company::IsValidID(*index)) {
		IConsolePrint(CC_ERROR, "Company does not exist. Company-id must be between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::Sale, *index, CompanyRemoveReason::None, ClientID::Invalid, {});
	IConsolePrint(CC_DEFAULT, "Company offered for sale.");

	return true;
}

static bool ConMergeCompanies(std::span<std::string_view> argv)
{
	if (argv.size() != 3) {
		IConsolePrint(CC_HELP, "Merge two companies together. Usage: 'merge_companies <main-company-id> <to-merge-company-id>'");
		IConsolePrint(CC_HELP, "The first company ID <main-company-id> will be left with the combined assets of both companies.");
		IConsolePrint(CC_HELP, "The second company ID <to-merge-company-id> will be removed, with all assets transferred to the first company ID.");
		IConsolePrint(CC_HELP, "For company-id's, see the list of companies from the dropdown menu. Company 1 is 1, etc.");
		return true;
	}

	auto main_company = ParseCompanyID(argv[1]);
	auto to_merge_company = ParseCompanyID(argv[2]);
	if (!main_company.has_value() || !to_merge_company.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	/* Check valid range */
	if (!Company::IsValidID(*main_company)) {
		IConsolePrint(CC_ERROR, "Main company does not exist. Company-id must be between 1 and {}.", MAX_COMPANIES);
		return true;
	}
	if (!Company::IsValidID(*to_merge_company)) {
		IConsolePrint(CC_ERROR, "Company to merge does not exist. Company-id must be between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::Merge, *main_company, CompanyRemoveReason::None, ClientID::Invalid, *to_merge_company);
	IConsolePrint(CC_DEFAULT, "Companies merged.");

	return true;
}

/** List the clients. @copydoc IConsoleCmdProc */
static bool ConNetworkClients(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Get a list of connected clients including their ID, name, company-id, and IP. Usage: 'clients'.");
		return true;
	}

	NetworkPrintClients();

	return true;
}

/** Connect to the last client you were connected to. @copydoc IConsoleCmdProc */
static bool ConNetworkReconnect(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Reconnect to server to which you were connected last time. Usage: 'reconnect [<company-id>]'.");
		IConsolePrint(CC_HELP, "Company 255 is spectator (default, if not specified), 254 means creating new company.");
		IConsolePrint(CC_HELP, "All others are a certain company with Company 1 being #1.");
		return true;
	}

	CompanyID playas = COMPANY_SPECTATOR;
	if (argv.size() >= 2) {
		auto company_id = ParseCompanyID(argv[1]);
		if (!company_id.has_value()) {
			IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
			return true;
		}
		if (*company_id >= MAX_COMPANIES && *company_id != COMPANY_NEW_COMPANY && *company_id != COMPANY_SPECTATOR) return false;
		playas = *company_id;
	}

	if (_settings_client.network.last_joined.empty()) {
		IConsolePrint(CC_DEFAULT, "No server for reconnecting.");
		return true;
	}

	/* Don't resolve the address first, just print it directly as it comes from the config file. */
	IConsolePrint(CC_DEFAULT, "Reconnecting to {} ...", _settings_client.network.last_joined);

	return NetworkClientConnectGame(_settings_client.network.last_joined, playas);
}

/** Connect to a specific server. @copydoc IConsoleCmdProc */
static bool ConNetworkConnect(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Connect to a remote OTTD server and join the game. Usage: 'connect <ip>'.");
		IConsolePrint(CC_HELP, "IP can contain port and company: 'IP[:Port][#Company]', eg: 'server.ottd.org:443#2'.");
		IConsolePrint(CC_HELP, "Company #255 is spectator all others are a certain company with Company 1 being #1.");
		return true;
	}

	if (argv.size() < 2) return false;

	return NetworkClientConnectGame(argv[1], COMPANY_NEW_COMPANY);
}

/*********************************
 *  script file console commands
 *********************************/

/** Run a local script file. @copydoc IConsoleCmdProc */
static bool ConExec(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Execute a local script file. Usage: 'exec <script> [0]'.");
		IConsolePrint(CC_HELP, "By passing '0' after the script name, no warning about a missing script file will be shown.");
		return true;
	}

	if (argv.size() < 2) return false;

	auto script_file = FioFOpenFile(argv[1], "r", Subdirectory::Base);

	if (!script_file.has_value()) {
		if (argv.size() == 2 || argv[2] != "0") IConsolePrint(CC_ERROR, "Script file '{}' not found.", argv[1]);
		return true;
	}

	if (_script_current_depth == 11) {
		IConsolePrint(CC_ERROR, "Maximum 'exec' depth reached; script A is calling script B is calling script C ... more than 10 times.");
		return true;
	}

	_script_current_depth++;
	uint script_depth = _script_current_depth;

	char buffer[ICON_CMDLN_SIZE];
	while (fgets(buffer, sizeof(buffer), *script_file) != nullptr) {
		/* Remove newline characters from the executing script */
		std::string_view cmdline{buffer};
		auto last_non_newline = cmdline.find_last_not_of("\r\n");
		if (last_non_newline != std::string_view::npos) cmdline = cmdline.substr(0, last_non_newline + 1);

		IConsoleCmdExec(cmdline);
		/* Ensure that we are still on the same depth or that we returned via 'return'. */
		assert(_script_current_depth == script_depth || _script_current_depth == script_depth - 1);

		/* The 'return' command was executed. */
		if (_script_current_depth == script_depth - 1) break;
	}

	if (ferror(*script_file) != 0) {
		IConsolePrint(CC_ERROR, "Encountered error while trying to read from script file '{}'.", argv[1]);
	}

	if (_script_current_depth == script_depth) _script_current_depth--;
	return true;
}

/** Schedule the execution of a script. @copydoc IConsoleCmdProc */
static bool ConSchedule(std::span<std::string_view> argv)
{
	if (argv.size() < 3 || std::string_view(argv[1]) != "on-next-calendar-month") {
		IConsolePrint(CC_HELP, "Schedule a local script to execute later. Usage: 'schedule on-next-calendar-month <script>'.");
		return true;
	}

	/* Check if the file exists. It might still go away later, but helpful to show an error now. */
	if (!FioCheckFileExists(argv[2], Subdirectory::Base)) {
		IConsolePrint(CC_ERROR, "Script file '{}' not found.", argv[2]);
		return true;
	}

	/* We only support a single script scheduled, so we tell the user what's happening if there was already one. */
	std::string_view filename = std::string_view(argv[2]);
	if (!_scheduled_monthly_script.empty() && filename == _scheduled_monthly_script) {
		IConsolePrint(CC_INFO, "Script file '{}' was already scheduled to execute at the start of next calendar month.", filename);
	} else if (!_scheduled_monthly_script.empty() && filename != _scheduled_monthly_script) {
		IConsolePrint(CC_INFO, "Script file '{}' scheduled to execute at the start of next calendar month, replacing the previously scheduled script file '{}'.", filename, _scheduled_monthly_script);
	} else {
		IConsolePrint(CC_INFO, "Script file '{}' scheduled to execute at the start of next calendar month.", filename);
	}

	/* Store the filename to be used by _schedule_timer on the start of next calendar month. */
	_scheduled_monthly_script = filename;

	return true;
}

/** End the execution of the current script. @copydoc IConsoleCmdProc */
static bool ConReturn(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Stop executing a running script. Usage: 'return'.");
		return true;
	}

	_script_current_depth--;
	return true;
}

/*****************************
 *  default console commands
 ******************************/
extern bool CloseConsoleLogIfActive();
extern std::span<const GRFFile> GetAllGRFFiles();
extern void ConPrintFramerate(); // framerate_gui.cpp
extern void ShowFramerateWindow();

/** Enable or disable logging of console output. @copydoc IConsoleCmdProc */
static bool ConScript(std::span<std::string_view> argv)
{
	extern std::optional<FileHandle> _iconsole_output_file;

	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Start or stop logging console output to a file. Usage: 'script <filename>'.");
		IConsolePrint(CC_HELP, "If filename is omitted, a running log is stopped if it is active.");
		return true;
	}

	if (!CloseConsoleLogIfActive()) {
		if (argv.size() < 2) return false;

		_iconsole_output_file = FileHandle::Open(std::string(argv[1]), "ab");
		if (!_iconsole_output_file.has_value()) {
			IConsolePrint(CC_ERROR, "Could not open console log file '{}'.", argv[1]);
		} else {
			IConsolePrint(CC_INFO, "Console log output started to '{}'.", argv[1]);
		}
	}

	return true;
}

/** Simply print the arguments. @copydoc IConsoleCmdProc */
static bool ConEcho(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Print back the first argument to the console. Usage: 'echo <arg>'.");
		return true;
	}

	if (argv.size() < 2) return false;
	IConsolePrint(CC_DEFAULT, "{}", argv[1]);
	return true;
}

/** Print the arguments in a particular colour. @copydoc IConsoleCmdProc */
static bool ConEchoC(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Print back the first argument to the console in a given colour. Usage: 'echoc <colour> <arg2>'.");
		return true;
	}

	if (argv.size() < 3) return false;

	auto colour = ParseInteger(argv[1]);
	if (!colour.has_value() || !IsInsideMM(*colour, to_underlying(TextColour::Begin), to_underlying(TextColour::End))) {
		IConsolePrint(CC_ERROR, "The colour must be a number between {} and {}.", TextColour::Begin, to_underlying(TextColour::End) - 1);
		return true;
	}

	IConsolePrint(static_cast<TextColour>(*colour), "{}", argv[2]);
	return true;
}

/** Start/create a new game. @copydoc IConsoleCmdProc */
static bool ConNewGame(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Start a new game. Usage: 'newgame [seed]'.");
		IConsolePrint(CC_HELP, "The server can force a new game using 'newgame'; any client joined will rejoin after the server is done generating the new game.");
		return true;
	}

	uint32_t seed = GENERATE_NEW_SEED;
	if (argv.size() >= 2) {
		auto param = ParseInteger(argv[1]);
		if (!param.has_value()) {
			IConsolePrint(CC_ERROR, "The given seed must be a valid number.");
			return true;
		}
		seed = *param;
	}

	StartNewGameWithoutGUI(seed);
	return true;
}

/** Restart the game. @copydoc IConsoleCmdProc */
static bool ConRestart(std::span<std::string_view> argv)
{
	if (argv.empty() || argv.size() > 2) {
		IConsolePrint(CC_HELP, "Restart game. Usage: 'restart [current|newgame]'.");
		IConsolePrint(CC_HELP, "Restarts a game, using either the current or newgame (default) settings.");
		IConsolePrint(CC_HELP, " * if you started from a new game, and your current/newgame settings haven't changed, the game will be identical to when you started it.");
		IConsolePrint(CC_HELP, " * if you started from a savegame / scenario / heightmap, the game might be different, because the current/newgame settings might differ.");
		return true;
	}

	if (argv.size() == 1 || std::string_view(argv[1]) == "newgame") {
		StartNewGameWithoutGUI(_settings_game.game_creation.generation_seed);
	} else {
		_settings_game.game_creation.map_x = Map::LogX();
		_settings_game.game_creation.map_y = Map::LogY();
		_switch_mode = SwitchMode::RestartGame;
	}

	return true;
}

/** Reload a game from the loaded savegame/scenario/heightmap. @copydoc IConsoleCmdProc */
static bool ConReload(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Reload game. Usage: 'reload'.");
		IConsolePrint(CC_HELP, "Reloads a game if loaded via savegame / scenario / heightmap.");
		return true;
	}

	if (_file_to_saveload.ftype.abstract == AbstractFileType::None || _file_to_saveload.ftype.abstract == AbstractFileType::Invalid) {
		IConsolePrint(CC_ERROR, "No game loaded to reload.");
		return true;
	}

	/* Use a switch-mode to prevent copying over newgame settings to active settings. */
	_settings_game.game_creation.map_x = Map::LogX();
	_settings_game.game_creation.map_y = Map::LogY();
	_switch_mode = SwitchMode::ReloadGame;
	return true;
}

/**
 * Print a text buffer line by line to the console. Lines are separated by '\n'.
 * @param full_string The multi-line string to print.
 */
static void PrintLineByLine(std::string_view full_string)
{
	ProcessLineByLine(full_string, [&](std::string_view line) {
		IConsolePrint(CC_DEFAULT, std::string{line});
	});
}

/** List all AI libraries. @copydoc IConsoleCmdProc */
static bool ConListAILibs(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List installed AI libraries. Usage: 'list_ai_libs'.");
		return true;
	}

	PrintLineByLine(AI::GetConsoleLibraryList(true));
	return true;
}

/** List all AI scripts. @copydoc IConsoleCmdProc */
static bool ConListAI(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List installed AIs. Usage: 'list_ai'.");
		return true;
	}

	PrintLineByLine(AI::GetConsoleList(false));
	return true;
}

/** List all game script libraries. @copydoc IConsoleCmdProc */
static bool ConListGameLibs(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List installed Game Script libraries. Usage: 'list_game_libs'.");
		return true;
	}

	PrintLineByLine(Game::GetConsoleLibraryList(true));
	return true;
}

/** List all game scripts. @copydoc IConsoleCmdProc */
static bool ConListGame(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List installed Game Scripts. Usage: 'list_game'.");
		return true;
	}

	PrintLineByLine(Game::GetConsoleList(false));
	return true;
}

/** Start a new AI. @copydoc IConsoleCmdProc */
static bool ConStartAI(std::span<std::string_view> argv)
{
	if (argv.empty() || argv.size() > 3) {
		IConsolePrint(CC_HELP, "Start a new AI. Usage: 'start_ai [<AI>] [<settings>]'.");
		IConsolePrint(CC_HELP, "Start a new AI. If <AI> is given, it starts that specific AI (if found).");
		IConsolePrint(CC_HELP, "If <settings> is given, it is parsed and the AI settings are set to that.");
		return true;
	}

	if (_game_mode != GameMode::Normal) {
		IConsolePrint(CC_ERROR, "AIs can only be managed in a game.");
		return true;
	}

	if (Company::GetNumItems() == CompanyPool::MAX_SIZE) {
		IConsolePrint(CC_ERROR, "Can't start a new AI (no more free slots).");
		return true;
	}
	if (_networking && !_network_server) {
		IConsolePrint(CC_ERROR, "Only the server can start a new AI.");
		return true;
	}
	if (_networking && !_settings_game.ai.ai_in_multiplayer) {
		IConsolePrint(CC_ERROR, "AIs are not allowed in multiplayer by configuration.");
		IConsolePrint(CC_ERROR, "Switch AI -> AI in multiplayer to True.");
		return true;
	}
	if (!AI::CanStartNew()) {
		IConsolePrint(CC_ERROR, "Can't start a new AI.");
		return true;
	}

	int n = 0;
	/* Find the next free slot */
	for (const Company *c : Company::Iterate()) {
		if (c->index != n) break;
		n++;
	}

	AIConfig *config = AIConfig::GetConfig((CompanyID)n);
	if (argv.size() >= 2) {
		config->Change(argv[1], -1, false);

		/* If the name is not found, and there is a dot in the name,
		 * try again with the assumption everything right of the dot is
		 * the version the user wants to load. */
		if (!config->HasScript()) {
			StringConsumer consumer{std::string_view{argv[1]}};
			auto name = consumer.ReadUntilChar('.', StringConsumer::SKIP_ONE_SEPARATOR);
			if (consumer.AnyBytesLeft()) {
				auto version = consumer.TryReadIntegerBase<uint32_t>(10);
				if (!version.has_value()) {
					IConsolePrint(CC_ERROR, "The version is not a valid number.");
					return true;
				}
				config->Change(name, *version, true);
			}
		}

		if (!config->HasScript()) {
			IConsolePrint(CC_ERROR, "Failed to load the specified AI.");
			return true;
		}
		if (argv.size() == 3) {
			config->StringToSettings(argv[2]);
		}
	}

	/* Start a new AI company */
	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::NewAI, CompanyID::Invalid(), CompanyRemoveReason::None, ClientID::Invalid, {});

	return true;
}

/** Reload/restart an AI. @copydoc IConsoleCmdProc */
static bool ConReloadAI(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Reload an AI. Usage: 'reload_ai <company-id>'.");
		IConsolePrint(CC_HELP, "Reload the AI with the given company id. For company-id's, see the list of companies from the dropdown menu. Company 1 is 1, etc.");
		return true;
	}

	if (_game_mode != GameMode::Normal) {
		IConsolePrint(CC_ERROR, "AIs can only be managed in a game.");
		return true;
	}

	if (_networking && !_network_server) {
		IConsolePrint(CC_ERROR, "Only the server can reload an AI.");
		return true;
	}

	auto company_id = ParseCompanyID(argv[1]);
	if (!company_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	if (!Company::IsValidID(*company_id)) {
		IConsolePrint(CC_ERROR, "Unknown company. Company range is between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	/* In singleplayer mode the player can be in an AI company, after cheating or loading network save with an AI in first slot. */
	if (Company::IsHumanID(*company_id) || *company_id == _local_company) {
		IConsolePrint(CC_ERROR, "Company is not controlled by an AI.");
		return true;
	}

	/* First kill the company of the AI, then start a new one. This should start the current AI again */
	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::Delete, *company_id, CompanyRemoveReason::Manual, ClientID::Invalid, {});
	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::NewAI, *company_id, CompanyRemoveReason::None, ClientID::Invalid, {});
	IConsolePrint(CC_DEFAULT, "AI reloaded.");

	return true;
}

/** Stop a currently running AI. @copydoc IConsoleCmdProc */
static bool ConStopAI(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Stop an AI. Usage: 'stop_ai <company-id>'.");
		IConsolePrint(CC_HELP, "Stop the AI with the given company id. For company-id's, see the list of companies from the dropdown menu. Company 1 is 1, etc.");
		return true;
	}

	if (_game_mode != GameMode::Normal) {
		IConsolePrint(CC_ERROR, "AIs can only be managed in a game.");
		return true;
	}

	if (_networking && !_network_server) {
		IConsolePrint(CC_ERROR, "Only the server can stop an AI.");
		return true;
	}

	auto company_id = ParseCompanyID(argv[1]);
	if (!company_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	if (!Company::IsValidID(*company_id)) {
		IConsolePrint(CC_ERROR, "Unknown company. Company range is between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	/* In singleplayer mode the player can be in an AI company, after cheating or loading network save with an AI in first slot. */
	if (Company::IsHumanID(*company_id) || *company_id == _local_company) {
		IConsolePrint(CC_ERROR, "Company is not controlled by an AI.");
		return true;
	}

	/* Now kill the company of the AI. */
	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::Delete, *company_id, CompanyRemoveReason::Manual, ClientID::Invalid, {});
	IConsolePrint(CC_DEFAULT, "AI stopped, company deleted.");

	return true;
}

/** Rescan the folder structure for new/changed AIs and libraries. @copydoc IConsoleCmdProc */
static bool ConRescanAI(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Rescan the AI dir for scripts. Usage: 'rescan_ai'.");
		return true;
	}

	if (_networking && !_network_server) {
		IConsolePrint(CC_ERROR, "Only the server can rescan the AI dir for scripts.");
		return true;
	}

	AI::Rescan();

	return true;
}

/** Rescan the folder structure for new/changed game scripts and libraries. @copydoc IConsoleCmdProc */
static bool ConRescanGame(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Rescan the Game Script dir for scripts. Usage: 'rescan_game'.");
		return true;
	}

	if (_networking && !_network_server) {
		IConsolePrint(CC_ERROR, "Only the server can rescan the Game Script dir for scripts.");
		return true;
	}

	Game::Rescan();

	return true;
}

/** Rescan the folder structure for new/changed NewGRFs. @copydoc IConsoleCmdProc */
static bool ConRescanNewGRF(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Rescan the data dir for NewGRFs. Usage: 'rescan_newgrf'.");
		return true;
	}

	if (!RequestNewGRFScan()) {
		IConsolePrint(CC_ERROR, "NewGRF scanning is already running. Please wait until completed to run again.");
	}

	return true;
}

/** Get the seed that was used to create this game. @copydoc IConsoleCmdProc */
static bool ConGetSeed(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Returns the seed used to create this game. Usage: 'getseed'.");
		IConsolePrint(CC_HELP, "The seed can be used to reproduce the exact same map as the game started with.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "Generation Seed: {}", _settings_game.game_creation.generation_seed);
	return true;
}

/** Get the current game date. @copydoc IConsoleCmdProc */
static bool ConGetDate(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Returns the current date (year-month-day) of the game. Usage: 'getdate'.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "Date: {:04}-{:02}-{:02}", CalTime::CurYear(), CalTime::CurMonth() + 1, CalTime::CurDay());
	return true;
}

/** Get the current system date. @copydoc IConsoleCmdProc */
static bool ConGetSysDate(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Returns the current date (year-month-day) of your system. Usage: 'getsysdate'.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "System Date: {}", LocalTime::FormatArg("%Y-%m-%d %H:%M:%S"));
	return true;
}

/** Create an alias for a command. @copydoc IConsoleCmdProc */
static bool ConAlias(std::span<std::string_view> argv)
{
	IConsoleAlias *alias;

	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Add a new alias, or redefine the behaviour of an existing alias . Usage: 'alias <name> <command>'.");
		return true;
	}

	if (argv.size() < 3) return false;

	alias = IConsole::AliasGet(std::string(argv[1]));
	if (alias == nullptr) {
		IConsole::AliasRegister(std::string(argv[1]), argv[2]);
	} else {
		alias->cmdline = argv[2];
	}
	return true;
}

/** Make a screenshot. @copydoc IConsoleCmdProc */
static bool ConScreenShot(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Create a screenshot of the game. Usage: 'screenshot [viewport | normal | big | giant | world | heightmap | minimap] [no_con] [size <width> <height>] [<filename>]'.");
		IConsolePrint(CC_HELP, "  'viewport' (default) makes a screenshot of the current viewport (including menus, windows).");
		IConsolePrint(CC_HELP, "  'normal' makes a screenshot of the visible area.");
		IConsolePrint(CC_HELP, "  'big' makes a zoomed-in screenshot of the visible area.");
		IConsolePrint(CC_HELP, "  'giant' makes a screenshot of the whole map using the default zoom level.");
		IConsolePrint(CC_HELP, "  'world' makes a screenshot of the whole map using the current zoom level.");
		IConsolePrint(CC_HELP, "  'heightmap' makes a heightmap screenshot of the map that can be loaded in as heightmap.");
		IConsolePrint(CC_HELP, "  'minimap' makes a top-viewed minimap screenshot of the whole world which represents one tile by one pixel.");
		IConsolePrint(CC_HELP, "  'topography' makes a top-viewed topography screenshot of the whole world which represents one tile by one pixel.");
		IConsolePrint(CC_HELP, "  'industry' makes a top-viewed industries screenshot of the whole world which represents one tile by one pixel.");
		IConsolePrint(CC_HELP, "  'no_con' hides the console to create the screenshot (only useful in combination with 'viewport').");
		IConsolePrint(CC_HELP, "  'size' sets the width and height of the viewport to make a screenshot of (only useful in combination with 'normal' or 'big').");
		IConsolePrint(CC_HELP, "  A filename ending in # will prevent overwriting existing files and will number files counting upwards.");
		return true;
	}

	if (argv.size() > 7) return false;

	ScreenshotType type = SC_VIEWPORT;
	uint32_t width = 0;
	uint32_t height = 0;
	std::string name{};
	uint32_t arg_index = 1;

	if (argv.size() > arg_index) {
		if (argv[arg_index] == "viewport") {
			type = SC_VIEWPORT;
			arg_index += 1;
		} else if (argv[arg_index] == "normal") {
			type = SC_DEFAULTZOOM;
			arg_index += 1;
		} else if (argv[arg_index] == "big") {
			type = SC_ZOOMEDIN;
			arg_index += 1;
		} else if (argv[arg_index] == "giant") {
			type = SC_WORLD;
			arg_index += 1;
		} else if (argv[arg_index] == "world") {
			type = SC_WORLD_ZOOM;
			arg_index += 1;
		} else if (argv[arg_index] == "heightmap") {
			type = SC_HEIGHTMAP;
			arg_index += 1;
		} else if (argv[arg_index] == "minimap") {
			type = SC_MINIMAP;
			arg_index += 1;
		} else if (argv[arg_index] == "topography") {
			type = SC_TOPOGRAPHY;
			arg_index += 1;
		} else if (argv[arg_index] == "industry") {
			type = SC_INDUSTRY;
			arg_index += 1;
		}
	}

	if (argv.size() > arg_index && argv[arg_index] == "no_con") {
		if (type != SC_VIEWPORT) {
			IConsolePrint(CC_ERROR, "'no_con' can only be used in combination with 'viewport'.");
			return true;
		}
		IConsoleClose();
		arg_index += 1;
	}

	if (argv.size() > arg_index + 2 && argv[arg_index] == "size") {
		/* size <width> <height> */
		if (type != SC_DEFAULTZOOM && type != SC_ZOOMEDIN) {
			IConsolePrint(CC_ERROR, "'size' can only be used in combination with 'normal' or 'big'.");
			return true;
		}
		auto t = ParseInteger(argv[arg_index + 1]);
		if (!t.has_value()) {
			IConsolePrint(CC_ERROR, "Invalid width '{}'", argv[arg_index + 1]);
			return true;
		}
		width = *t;

		t = ParseInteger(argv[arg_index + 2]);
		if (!t.has_value()) {
			IConsolePrint(CC_ERROR, "Invalid height '{}'", argv[arg_index + 2]);
			return true;
		}
		height = *t;
		arg_index += 3;
	}

	if (argv.size() > arg_index) {
		/* Last parameter that was not one of the keywords must be the filename. */
		name = argv[arg_index];
		arg_index += 1;
	}

	if (argv.size() > arg_index) {
		/* We have parameters we did not process; means we misunderstood any of the above. */
		return false;
	}

	MakeScreenshot(type, name, width, height);
	return true;
}

static bool ConMinimap(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Create a flat image of the game minimap. Usage: 'minimap [owner] [file name]'");
		IConsolePrint(CC_HELP, "'owner' uses the tile owner to colour the minimap image, this is the only mode at present");
		return true;
	}

	std::string_view name = {};
	if (argv.size() > 1) {
		if (argv[1] != "owner") {
			/* invalid mode */
			return false;
		}
	}
	if (argv.size() > 2) {
		name = argv[2];
	}

	MakeMinimapWorldScreenshot(name);
	return true;
}

/** Get debug information about a command. @copydoc IConsoleCmdProc */
static bool ConInfoCmd(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Print out debugging information about a command. Usage: 'info_cmd <cmd>'.");
		return true;
	}

	if (argv.size() < 2) return false;

	const IConsoleCmd *cmd = IConsole::CmdGet(std::string(argv[1]));
	if (cmd == nullptr) {
		IConsolePrint(CC_ERROR, "The given command was not found.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "Command name: '{}'", cmd->name);

	if (cmd->hook != nullptr) IConsolePrint(CC_DEFAULT, "Command is hooked.");

	return true;
}

/** Change the debug levels of the game. @copydoc IConsoleCmdProc */
static bool ConDebugLevel(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Get/set the default debugging level for the game. Usage: 'debug_level [<level>]'.");
		IConsolePrint(CC_HELP, "Level can be any combination of names, levels. Eg 'net=5 ms=4'. Remember to enclose it in \"'\"s.");
		return true;
	}

	if (argv.size() > 2) return false;

	if (argv.size() == 1) {
		IConsolePrint(CC_DEFAULT, "Current debug-level: '{}'", GetDebugString());
	} else {
		SetDebugString(argv[1], [](std::string_view err) { IConsolePrint(CC_ERROR, std::string{err}); });
	}

	return true;
}

/** Exit the game, i.e. exit the complete application. @copydoc IConsoleCmdProc */
static bool ConExit(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Exit the game. Usage: 'exit'.");
		return true;
	}

	if (_game_mode == GameMode::Normal && _settings_client.gui.autosave_on_exit) DoExitSave();

	_exit_game = true;
	return true;
}

/** Part the game, i.e. go back to the main menu. @copydoc IConsoleCmdProc */
static bool ConPart(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Leave the currently joined/running game (only ingame). Usage: 'part'.");
		return true;
	}

	if (_game_mode != GameMode::Normal) return false;

	if (_network_dedicated) {
		IConsolePrint(CC_ERROR, "A dedicated server can not leave the game.");
		return false;
	}

	_switch_mode = SwitchMode::Menu;
	return true;
}

/** Show generic help and specific help for commands. @copydoc IConsoleCmdProc */
static bool ConHelp(std::span<std::string_view> argv)
{
	if (argv.size() == 2) {
		const IConsoleCmd *cmd;
		const IConsoleAlias *alias;

		cmd = IConsole::CmdGet(std::string(argv[1]));
		if (cmd != nullptr) {
			cmd->proc({});
			return true;
		}

		alias = IConsole::AliasGet(std::string(argv[1]));
		if (alias != nullptr) {
			cmd = IConsole::CmdGet(alias->cmdline);
			if (cmd != nullptr) {
				cmd->proc({});
				return true;
			}
			IConsolePrint(CC_ERROR, "Alias is of special type, please see its execution-line: '{}'.", alias->cmdline);
			return true;
		}

		IConsolePrint(CC_ERROR, "Command not found.");
		return true;
	}

	IConsolePrint(TextColour::LightBlue, " ---- OpenTTD Console Help ---- ");
	IConsolePrint(CC_DEFAULT, " - commands: the command to list all commands is 'list_cmds'.");
	IConsolePrint(CC_DEFAULT, " call commands with '<command> <arg2> <arg3>...'");
	IConsolePrint(CC_DEFAULT, " - to assign strings, or use them as arguments, enclose it within quotes.");
	IConsolePrint(CC_DEFAULT, " like this: '<command> \"string argument with spaces\"'.");
	IConsolePrint(CC_DEFAULT, " - use 'help <command>' to get specific information.");
	IConsolePrint(CC_DEFAULT, " - scroll console output with shift + (up | down | pageup | pagedown).");
	IConsolePrint(CC_DEFAULT, " - scroll console input history with the up or down arrows.");
	IConsolePrint(CC_DEFAULT, "");
	return true;
}

/** List all registered commands that are not hidden. @copydoc IConsoleCmdProc */
static bool ConListCommands(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List all registered commands. Usage: 'list_cmds [<pre-filter>]'.");
		return true;
	}

	for (auto &it : IConsole::Commands()) {
		const IConsoleCmd *cmd = &it.second;
		if (argv.size() <= 1 || cmd->name.find(argv[1]) != std::string::npos) {
			if ((_settings_client.gui.console_show_unlisted || !cmd->unlisted) && (cmd->hook == nullptr || cmd->hook(false) != ConsoleHookResult::Hide)) IConsolePrint(CC_DEFAULT, cmd->name);
		}
	}

	return true;
}

/** List all registered aliases. @copydoc IConsoleCmdProc */
static bool ConListAliases(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List all registered aliases. Usage: 'list_aliases [<pre-filter>]'.");
		return true;
	}

	for (auto &it : IConsole::Aliases()) {
		const IConsoleAlias *alias = &it.second;
		if (argv.size() <= 1 || alias->name.find(argv[1]) != std::string::npos) {
			IConsolePrint(CC_DEFAULT, "{} => {}", alias->name, alias->cmdline);
		}
	}

	return true;
}

/** List all companies. @copydoc IConsoleCmdProc */
static bool ConCompanies(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List the details of all companies in the game. Usage 'companies'.");
		return true;
	}

	for (const Company *c : Company::Iterate()) {
		/* Grab the company name */
		std::string company_name = GetString(STR_COMPANY_NAME, c->index);

		const char *password_state = "";
		if (c->is_ai) {
			password_state = "AI";
		} else if (_network_server) {
			password_state = _network_company_states[c->index].password.empty() ? "unprotected" : "protected";
		}

		std::string colour = GetString(STR_COLOUR_DARK_BLUE + to_underlying(_company_colours[c->index]));
		IConsolePrint(CC_INFO, "#:{}({}) Company Name: '{}'  Year Founded: {}  Age: {}  Money: {}  Loan: {}  Value: {}  (T:{}, R:{}, P:{}, S:{}) {}",
			c->index + 1, colour, company_name,
			c->InauguratedDisplayYear(), c->age_years, (int64_t)c->money, (int64_t)c->current_loan, (int64_t)CalculateCompanyValue(c),
			c->group_all[VehicleType::Train].num_vehicle,
			c->group_all[VehicleType::Road].num_vehicle,
			c->group_all[VehicleType::Aircraft].num_vehicle,
			c->group_all[VehicleType::Ship].num_vehicle,
			password_state);
	}

	return true;
}

/** Say something to all clients in a network game. @copydoc IConsoleCmdProc */
static bool ConSay(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Chat to your fellow players in a multiplayer game. Usage: 'say \"<msg>\"'.");
		return true;
	}

	if (argv.size() != 2) return false;

	if (!_network_server) {
		NetworkClientSendChat(NetworkAction::ChatBroadcast, NetworkChatDestinationType::Broadcast, 0 /* param does not matter */, argv[1]);
	} else {
		bool from_admin = (_redirect_console_to_admin < AdminID::Invalid());
		NetworkServerSendChat(NetworkAction::ChatBroadcast, NetworkChatDestinationType::Broadcast, 0, argv[1], ClientID::Server, from_admin);
	}

	return true;
}

/** Say something to all clients in your company in a network game. @copydoc IConsoleCmdProc */
static bool ConSayCompany(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Chat to a certain company in a multiplayer game. Usage: 'say_company <company-no> \"<msg>\"'.");
		IConsolePrint(CC_HELP, "CompanyNo is the company that plays as company <companyno>, 1 through max_companies.");
		return true;
	}

	if (argv.size() != 3) return false;

	auto company_id = ParseCompanyID(argv[1]);
	if (!company_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given company-id is not a valid number.");
		return true;
	}

	if (!Company::IsValidID(*company_id)) {
		IConsolePrint(CC_DEFAULT, "Unknown company. Company range is between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	if (!_network_server) {
		NetworkClientSendChat(NetworkAction::ChatTeam, NetworkChatDestinationType::Team, company_id->base(), argv[2]);
	} else {
		bool from_admin = (_redirect_console_to_admin < AdminID::Invalid());
		NetworkServerSendChat(NetworkAction::ChatTeam, NetworkChatDestinationType::Team, company_id->base(), argv[2], ClientID::Server, from_admin);
	}

	return true;
}

/** Say something to a specific client in a network game. @copydoc IConsoleCmdProc */
static bool ConSayClient(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Chat to a certain client in a multiplayer game. Usage: 'say_client <client-id> \"<msg>\"'.");
		IConsolePrint(CC_HELP, "For client-id's, see the command 'clients'.");
		return true;
	}

	if (argv.size() != 3) return false;

	auto client_id = ParseType<ClientID>(argv[1]);
	if (!client_id.has_value()) {
		IConsolePrint(CC_ERROR, "The given client-id is not a valid number.");
		return true;
	}

	if (!_network_server) {
		NetworkClientSendChat(NetworkAction::ChatClient, NetworkChatDestinationType::Client, to_underlying(*client_id), argv[2]);
	} else {
		bool from_admin = (_redirect_console_to_admin < AdminID::Invalid());
		NetworkServerSendChat(NetworkAction::ChatClient, NetworkChatDestinationType::Client, to_underlying(*client_id), argv[2], ClientID::Server, from_admin);
	}

	return true;
}

static bool ConCompanyPassword(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		if (_network_dedicated) {
			IConsolePrint(CC_HELP, "Change the password of a company. Usage: 'company_pw <company-no> \"<password>\".");
		} else if (_network_server) {
			IConsolePrint(CC_HELP, "Change the password of your or any other company. Usage: 'company_pw [<company-no>] \"<password>\"'.");
		} else {
			IConsolePrint(CC_HELP, "Change the password of your company. Usage: 'company_pw \"<password>\"'.");
		}

		IConsolePrint(CC_HELP, "Use \"*\" to disable the password.");
		return true;
	}

	CompanyID company_id;
	std::string password;
	const char *errormsg;

	if (argv.size() == 2) {
		company_id = _local_company;
		password = argv[1];
		errormsg = "You have to own a company to make use of this command.";
	} else if (argv.size() == 3 && _network_server) {
		company_id = ParseCompanyID(argv[1]).value_or(CompanyID::Invalid());
		password = argv[2];
		errormsg = "You have to specify the ID of a valid human controlled company.";
	} else {
		return false;
	}

	if (!Company::IsValidHumanID(company_id)) {
		IConsolePrint(CC_ERROR, errormsg);
		return false;
	}

	password = NetworkChangeCompanyPassword(company_id, password);

	if (password.empty()) {
		IConsolePrint(CC_INFO, "Company password cleared.");
	} else {
		IConsolePrint(CC_INFO, "Company password changed to '{}'.", password);
	}

	return true;
}

/** All the known authorized keys with their name. */
static const std::initializer_list<std::pair<std::string_view, NetworkAuthorizedKeys *>> _console_cmd_authorized_keys{
	{ "admin", &_settings_client.network.admin_authorized_keys },
	{ "rcon", &_settings_client.network.rcon_authorized_keys },
	{ "server", &_settings_client.network.server_authorized_keys },
	{ "settings", &_settings_client.network.settings_authorized_keys },
};

/** Actions that can be performed on authorized keys from the console. */
enum class ConNetworkAuthorizedKeyAction : uint8_t {
	List, ///< List all authorized keys.
	Add, ///< Add an authorized key.
	Remove, ///< Remove an authorized key.
};

static void PerformNetworkAuthorizedKeyAction(std::string_view name, NetworkAuthorizedKeys *authorized_keys, ConNetworkAuthorizedKeyAction action, const std::string &authorized_key, CompanyID company = CompanyID::Invalid())
{
	switch (action) {
		case ConNetworkAuthorizedKeyAction::List:
			IConsolePrint(CC_WHITE, "The authorized keys for {} are:", name);
			for (auto &ak : *authorized_keys) IConsolePrint(CC_INFO, "  {}", ak);
			return;

		case ConNetworkAuthorizedKeyAction::Add:
			if (authorized_keys->Contains(authorized_key)) {
				IConsolePrint(CC_WARNING, "Not added {} to {} as it already exists.", authorized_key, name);
				return;
			}

			if (company == CompanyID::Invalid()) {
				authorized_keys->Add(authorized_key);
			} else {
				AutoRestoreBackup backup(_current_company, company);
				Command<Commands::CompanyAllowListControl>::Post(CompanyAllowListCtrlAction::AddKey, authorized_key);
			}
			IConsolePrint(CC_INFO, "Added {} to {}.", authorized_key, name);
			return;

		case ConNetworkAuthorizedKeyAction::Remove:
			if (!authorized_keys->Contains(authorized_key)) {
				IConsolePrint(CC_WARNING, "Not removed {} from {} as it does not exist.", authorized_key, name);
				return;
			}

			if (company == CompanyID::Invalid()) {
				authorized_keys->Remove(authorized_key);
			} else {
				AutoRestoreBackup backup(_current_company, company);
				Command<Commands::CompanyAllowListControl>::Post(CompanyAllowListCtrlAction::RemoveKey, authorized_key);
			}
			IConsolePrint(CC_INFO, "Removed {} from {}.", authorized_key, name);
			return;
	}
}

/** Management of authorized keys. @copydoc IConsoleCmdProc */
static bool ConNetworkAuthorizedKey(std::span<std::string_view> argv)
{
	if (argv.size() <= 2) {
		IConsolePrint(CC_HELP, "List and update authorized keys. Usage: 'authorized_key list [type]|add [type] [key]|remove [type] [key]'.");
		IConsolePrint(CC_HELP, "  list: list all the authorized keys of the given type.");
		IConsolePrint(CC_HELP, "  add: add the given key to the authorized keys of the given type.");
		IConsolePrint(CC_HELP, "  remove: remove the given key from the authorized keys of the given type; use 'all' to remove all authorized keys.");
		IConsolePrint(CC_HELP, "Instead of a key, use 'client:<id>' to add/remove the key of that given client.");

		std::string buffer;
		for (auto [name, _] : _console_cmd_authorized_keys) fmt::format_to(std::back_inserter(buffer), ", {}", name);
		IConsolePrint(CC_HELP, "The supported types are: all{} and company:<id>.", buffer);
		return true;
	}

	ConNetworkAuthorizedKeyAction action;
	std::string_view action_string = argv[1];
	if (StrEqualsIgnoreCase(action_string, "list")) {
		action = ConNetworkAuthorizedKeyAction::List;
	} else if (StrEqualsIgnoreCase(action_string, "add")) {
		action = ConNetworkAuthorizedKeyAction::Add;
	} else if (StrEqualsIgnoreCase(action_string, "remove") || StrEqualsIgnoreCase(action_string, "delete")) {
		action = ConNetworkAuthorizedKeyAction::Remove;
	} else {
		IConsolePrint(CC_WARNING, "No valid action was given.");
		return false;
	}

	std::string authorized_key;
	if (action != ConNetworkAuthorizedKeyAction::List) {
		if (argv.size() <= 3) {
			IConsolePrint(CC_ERROR, "You must enter the key.");
			return false;
		}

		authorized_key = argv[3];
		if (StrStartsWithIgnoreCase(authorized_key, "client:")) {
			auto value = ParseInteger<uint32_t>(authorized_key.substr(7));
			if (value.has_value()) authorized_key = NetworkGetPublicKeyOfClient(static_cast<ClientID>(*value));
			if (!value.has_value() || authorized_key.empty()) {
				IConsolePrint(CC_ERROR, "You must enter a valid client id; see 'clients'.");
				return false;
			}
		}

		if (authorized_key.size() != NETWORK_PUBLIC_KEY_LENGTH - 1) {
			IConsolePrint(CC_ERROR, "You must enter a valid authorized key.");
			return false;
		}
	}

	std::string_view type = argv[2];
	if (StrEqualsIgnoreCase(type, "all")) {
		for (auto [name, authorized_keys] : _console_cmd_authorized_keys) PerformNetworkAuthorizedKeyAction(name, authorized_keys, action, authorized_key);
		for (Company *c : Company::Iterate()) PerformNetworkAuthorizedKeyAction(fmt::format("company:{}", c->index + 1), &c->allow_list, action, authorized_key, c->index);
		return true;
	}

	if (StrStartsWithIgnoreCase(type, "company:")) {
		auto value = ParseInteger<uint32_t>(type.substr(8));
		Company *c = value.has_value() ? Company::GetIfValid(*value - 1) : nullptr;
		if (c == nullptr) {
			IConsolePrint(CC_ERROR, "You must enter a valid company id; see 'companies'.");
			return false;
		}

		PerformNetworkAuthorizedKeyAction(type, &c->allow_list, action, authorized_key, c->index);
		return true;
	}

	for (auto [name, authorized_keys] : _console_cmd_authorized_keys) {
		if (!StrEqualsIgnoreCase(type, name)) continue;

		PerformNetworkAuthorizedKeyAction(name, authorized_keys, action, authorized_key);
		return true;
	}

	IConsolePrint(CC_WARNING, "No valid type was given.");
	return false;
}

static bool ConCompanyPasswordHash(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Change the password hash of a company. Usage: 'company_pw_hash <company-no> \"<password_hash>\"");
		IConsolePrint(CC_HELP, "Use \"*\" to disable the password.");
		return true;
	}

	if (argv.size() != 3) return false;

	CompanyID company_id = ParseCompanyID(argv[1]).value_or(CompanyID::Invalid());
	std::string_view password = argv[2];

	if (!Company::IsValidHumanID(company_id)) {
		IConsolePrint(CC_ERROR, "You have to specify the ID of a valid human controlled company.");
		return false;
	}

	if (password == "*") password = {};

	NetworkServerSetCompanyPassword(company_id, password, true);

	if (password.empty()) {
		IConsolePrint(CC_WARNING, "Company password hash cleared");
	} else {
		IConsolePrint(CC_WARNING, "Company password hash changed to: {}", password);
	}

	return true;
}

static bool ConCompanyPasswordHashes(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List the password hashes of all companies in the game. Usage 'company_pw_hashes'");
		return true;
	}

	for (const Company *c : Company::Iterate()) {
		/* Grab the company name */
		std::string company_name = GetString(STR_COMPANY_NAME, c->index);

		IConsolePrint(CC_INFO, "#:{}({}) Company Name: '{}'  Hash: '{}'",
			c->index + 1, GetStringFmtParam(STR_COLOUR_DARK_BLUE + to_underlying(_company_colours[c->index])), company_name.c_str(), _network_company_states[c->index].password);
	}

	return true;
}

/* Content downloading only is available with ZLIB */
#if defined(WITH_ZLIB)

/**
 * Resolve a string to a content type.
 * @param str The string to resolve.
 * @return The content type, or #ContentType::End when the string is not a content type.
 */
static ContentType StringToContentType(std::string_view str)
{
	static const std::initializer_list<std::pair<std::string_view, ContentType>> content_types = {
		{"base",      ContentType::BaseGraphics},
		{"newgrf",    ContentType::NewGRF},
		{"ai",        ContentType::Ai},
		{"ailib",     ContentType::AiLibrary},
		{"scenario",  ContentType::Scenario},
		{"heightmap", ContentType::Heightmap},
	};
	for (const auto &ct : content_types) {
		if (StrEqualsIgnoreCase(str, ct.first)) return ct.second;
	}
	return ContentType::End;
}

/** Asynchronous callback */
struct ConsoleContentCallback : public ContentCallback {
	void OnConnect(bool success) override
	{
		IConsolePrint(CC_DEFAULT, "Content server connection {}.", success ? "established" : "failed");
	}

	void OnDisconnect() override
	{
		IConsolePrint(CC_DEFAULT, "Content server connection closed.");
	}

	void OnDownloadComplete(ContentID cid) override
	{
		IConsolePrint(CC_DEFAULT, "Completed download of {}.", cid);
	}
};

/**
 * Outputs content state information to console
 * @param ci the content info
 */
static void OutputContentState(const ContentInfo &ci)
{
	static constexpr EnumIndexArray<std::string_view, ContentType, ContentType::End> types{
		"", "Base graphics", "NewGRF", "AI", "AI library", "Scenario", "Heightmap", "Base sound", "Base music", "Game script", "GS library"
	};
	static constexpr EnumIndexArray<std::string_view, ContentInfo::State, ContentInfo::State::End> states{
		"Not selected", "Selected", "Dep Selected", "Installed", "Unknown"
	};
	static constexpr EnumIndexArray<TextColour, ContentInfo::State, ContentInfo::State::End> state_to_colour{
		CC_COMMAND, CC_INFO, CC_INFO, CC_WHITE, CC_ERROR
	};

	IConsolePrint(state_to_colour[ci.state], "{}, {}, {}, {}, {:08X}, {}", ci.id, types[ci.type], states[ci.state], ci.name, ci.unique_id, FormatArrayAsHex(ci.md5sum));
}

/** Downloading of content from the server. @copydoc IConsoleCmdProc */
static bool ConContent(std::span<std::string_view> argv)
{
	static ContentCallback *cb = nullptr;
	if (cb == nullptr) {
		cb = new ConsoleContentCallback();
		_network_content_client.AddCallback(cb);
	}

	if (argv.size() <= 1) {
		IConsolePrint(CC_HELP, "Query, select and download content. Usage: 'content update|upgrade|select [id]|unselect [all|id]|state [filter]|download'.");
		IConsolePrint(CC_HELP, "  update: get a new list of downloadable content; must be run first.");
		IConsolePrint(CC_HELP, "  upgrade: select all items that are upgrades.");
		IConsolePrint(CC_HELP, "  select: select a specific item given by its id. If no parameter is given, all selected content will be listed.");
		IConsolePrint(CC_HELP, "  unselect: unselect a specific item given by its id or 'all' to unselect all.");
		IConsolePrint(CC_HELP, "  state: show the download/select state of all downloadable content. Optionally give a filter string.");
		IConsolePrint(CC_HELP, "  download: download all content you've selected.");
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "update")) {
		_network_content_client.RequestContentList((argv.size() > 2) ? StringToContentType(argv[2]) : ContentType::End);
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "upgrade")) {
		_network_content_client.SelectUpgrade();
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "select")) {
		if (argv.size() <= 2) {
			/* List selected content */
			IConsolePrint(CC_WHITE, "id, type, state, name");
			for (const ContentInfo &ci : _network_content_client.Info()) {
				if (ci.state != ContentInfo::State::Selected && ci.state != ContentInfo::State::Autoselected) continue;
				OutputContentState(ci);
			}
		} else if (StrEqualsIgnoreCase(argv[2], "all")) {
			/* The intention of this function was that you could download
			 * everything after a filter was applied; but this never really
			 * took off. Instead, a select few people used this functionality
			 * to download every available package on BaNaNaS. This is not in
			 * the spirit of this service. Additionally, these few people were
			 * good for 70% of the consumed bandwidth of BaNaNaS. */
			IConsolePrint(CC_ERROR, "'select all' is no longer supported since 1.11.");
		} else if (auto content_id = ParseType<ContentID>(argv[2]); content_id.has_value()) {
			_network_content_client.Select(*content_id);
		} else {
			IConsolePrint(CC_ERROR, "The given content-id is not a number or 'all'");
		}
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "unselect")) {
		if (argv.size() <= 2) {
			IConsolePrint(CC_ERROR, "You must enter the id.");
			return false;
		}
		if (StrEqualsIgnoreCase(argv[2], "all")) {
			_network_content_client.UnselectAll();
		} else if (auto content_id = ParseType<ContentID>(argv[2]); content_id.has_value()) {
			_network_content_client.Unselect(*content_id);
		} else {
			IConsolePrint(CC_ERROR, "The given content-id is not a number or 'all'");
		}
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "state")) {
		IConsolePrint(CC_WHITE, "id, type, state, name");
		for (const ContentInfo &ci : _network_content_client.Info()) {
			if (argv.size() > 2 && !StrContainsIgnoreCase(ci.name, argv[2])) continue;
			OutputContentState(ci);
		}
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "download")) {
		uint files;
		uint bytes;
		_network_content_client.DownloadSelectedContent(files, bytes);
		IConsolePrint(CC_DEFAULT, "Downloading {} file(s) ({} bytes).", files, bytes);
		return true;
	}

	return false;
}
#endif /* defined(WITH_ZLIB) */

/**
 * Get FontSize by name
 * @param name The name to look up.
 * @return The FontSize matching the given name,
 */
static FontSize GetFontSizeByName(std::string_view name)
{
	for (FontSize fs : EnumRange(FontSize::End)) {
		if (StrEqualsIgnoreCase(name, FontSizeToName(fs))) return fs;
	}
	return FontSize::End;
}

/** Managing the font configuration. @copydoc IConsoleCmdProc */
static bool ConFont(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Manage the fonts configuration.");
		IConsolePrint(CC_HELP, "Usage 'font'.");
		IConsolePrint(CC_HELP, "  Print out the fonts configuration.");
		IConsolePrint(CC_HELP, "  The \"Currently active\" configuration is the one actually in effect (after interface scaling and replacing unavailable fonts).");
		IConsolePrint(CC_HELP, "  The \"Requested\" configuration is the one requested via console command or config file.");
		IConsolePrint(CC_HELP, "Usage 'font [medium|small|large|mono] [<font name>] [<size>]'.");
		IConsolePrint(CC_HELP, "  Change the configuration for a font.");
		IConsolePrint(CC_HELP, "  Omitting an argument will keep the current value.");
		IConsolePrint(CC_HELP, "  Set <font name> to \"\" for the default font. Note that <size> has no effect if the default font is in use, and fixed defaults are used instead.");
		IConsolePrint(CC_HELP, "  If the sprite font is enabled in Game Options, it is used instead of the default font.");
		IConsolePrint(CC_HELP, "  The <size> is automatically multiplied by the current interface scaling.");
		return true;
	}

	if (argv.size() > 2) {
		/* First argument must be a FontSize. */
		FontSize argfs = GetFontSizeByName(argv[1]);
		if (argfs == FontSize::End) return false;

		FontCacheSubSetting *setting = GetFontCacheSubSetting(argfs);
		std::string font = setting->font;
		uint size = setting->size;
		uint8_t arg_index = 2;
		/* For <name> we want a string. */

		if (!ParseInteger(argv[arg_index]).has_value()) {
			font = argv[arg_index++];
		}

		if (argv.size() > arg_index) {
			/* For <size> we want a number. */
			auto v = ParseInteger(argv[arg_index]);
			if (v.has_value()) {
				size = *v;
				arg_index++;
			}
		}

		SetFont(argfs, font, size);
	}

	for (FontSize fs : EnumRange(FontSize::End)) {
		FontCache *fc = FontCache::Get(fs);
		FontCacheSubSetting *setting = GetFontCacheSubSetting(fs);
		/* Make sure all non sprite fonts are loaded. */
		if (!setting->font.empty() && !fc->HasParent()) {
			FontCache::LoadFontCaches(fs);
			fc = FontCache::Get(fs);
		}
		IConsolePrint(CC_DEFAULT, "{} font:", FontSizeToName(fs));
		IConsolePrint(CC_DEFAULT, "Currently active: \"{}\", size {}", fc->GetFontName(), fc->GetFontSize());
		IConsolePrint(CC_DEFAULT, "Requested: \"{}\", size {}", setting->font, setting->size);
	}

	FontChanged();

	return true;
}

/** Change settings of the current game. @copydoc IConsoleCmdProc */
static bool ConSetting(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Change setting for all clients. Usage: 'setting <name> [<value>]'.");
		IConsolePrint(CC_HELP, "Omitting <value> will print out the current value of the setting.");
		return true;
	}

	if (argv.size() == 1 || argv.size() > 3) return false;

	if (argv.size() == 2) {
		IConsoleGetSetting(argv[1]);
	} else {
		IConsoleSetSetting(argv[1], argv[2]);
	}

	return true;
}

/** Change settings of for a new game. @copydoc IConsoleCmdProc */
static bool ConSettingNewgame(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Change setting for the next game. Usage: 'setting_newgame <name> [<value>]'.");
		IConsolePrint(CC_HELP, "Omitting <value> will print out the current value of the setting.");
		return true;
	}

	if (argv.size() == 1 || argv.size() > 3) return false;

	if (argv.size() == 2) {
		IConsoleGetSetting(argv[1], true);
	} else {
		IConsoleSetSetting(argv[1], argv[2], true);
	}

	return true;
}

/** List all settings. @copydoc IConsoleCmdProc */
static bool ConListSettings(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List settings. Usage: 'list_settings [<pre-filter>]'.");
		return true;
	}

	if (argv.size() > 2) return false;

	IConsoleListSettings((argv.size() == 2) ? argv[1] : std::string_view{}, false);
	return true;
}

static bool ConListSettingsDefaults(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "List settings and also show default value. Usage: 'list_settings_def [<pre-filter>]'");
		return true;
	}

	if (argv.size() > 2) return false;

	IConsoleListSettings((argv.size() == 2) ? argv[1] : std::string_view{}, true);
	return true;
}

/** Print the gamelog. @copydoc IConsoleCmdProc */
static bool ConGamelogPrint(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Print logged fundamental changes to the game since the start. Usage: 'gamelog'.");
		return true;
	}

	GamelogPrintConsole();
	return true;
}

/** Reload all active NewGRFs. @copydoc IConsoleCmdProc */
static bool ConNewGRFReload(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Reloads all active NewGRFs from disk. Equivalent to reapplying NewGRFs via the settings, but without asking for confirmation. This might crash OpenTTD!");
		return true;
	}

	ReloadNewGRFData();

	extern void PostCheckNewGRFLoadWarnings();
	PostCheckNewGRFLoadWarnings();
	return true;
}

/** List the locations of all of the game's different sub directories. @copydoc IConsoleCmdProc */
static bool ConListDirs(std::span<std::string_view> argv)
{
	struct SubdirNameMap {
		std::string_view name; ///< UI name for the directory
		Subdirectory subdir; ///< Index of subdirectory type
		bool default_only; ///< Whether only the default (first existing) directory for this is interesting
	};
	static const SubdirNameMap subdir_name_map[] = {
		/* Game data directories */
		{ "baseset", Subdirectory::Baseset, false },
		{ "newgrf", Subdirectory::NewGrf, false },
		{ "ai", Subdirectory::Ai, false },
		{ "ailib", Subdirectory::AiLibrary, false },
		{ "gs", Subdirectory::Gs, false },
		{ "gslib", Subdirectory::GsLibrary, false },
		{ "scenario", Subdirectory::Scenario, false },
		{ "heightmap", Subdirectory::Heightmap, false },
		/* Default save locations for user data */
		{ "save", Subdirectory::Save, true },
		{ "autosave", Subdirectory::Autosave, true },
		{ "screenshot", Subdirectory::Screenshot, true },
		{ "social_integration", Subdirectory::SocialIntegration, true },
	};

	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "List all search paths or default directories for various categories.");
		IConsolePrint(CC_HELP, "Usage: list_dirs <category>");
		std::string cats{subdir_name_map[0].name};
		bool first = true;
		for (const SubdirNameMap &sdn : subdir_name_map) {
			if (!first) {
				cats += ", ";
				cats += sdn.name;
			}
			first = false;
		}
		IConsolePrint(CC_HELP, "Valid categories: {}", cats);
		return true;
	}

	btree::btree_set<std::string> seen_dirs;
	for (const SubdirNameMap &sdn : subdir_name_map) {
		if (!StrEqualsIgnoreCase(argv[1], sdn.name))  continue;
		bool found = false;
		for (Searchpath sp : _valid_searchpaths) {
			/* Get the directory */
			std::string path = FioGetDirectory(sp, sdn.subdir);
			/* Check it hasn't already been listed */
			if (seen_dirs.find(path) != seen_dirs.end()) continue;
			seen_dirs.insert(path);
			/* Check if exists and mark found */
			bool exists = FileExists(path);
			found |= exists;
			/* Print */
			if (!sdn.default_only || exists) {
				IConsolePrint(exists ? CC_DEFAULT : CC_INFO, "{} {}", path, exists ? "[ok]" : "[not found]");
				if (sdn.default_only) break;
			}
		}
		if (!found) {
			IConsolePrint(CC_ERROR, "No directories exist for category {}", argv[1]);
		}
		return true;
	}

	IConsolePrint(CC_ERROR, "Invalid category name: {}", argv[1]);
	return false;
}

static bool ConResetBlockedHeliports(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Resets heliports blocked by the improved breakdowns bug, for single-player use only.");
		return true;
	}

	unsigned int count = 0;
	for (Station *st : Station::Iterate()) {
		if (st->airport.tile == INVALID_TILE) continue;
		if (st->airport.HasHangar()) continue;
		if (st->airport.blocks.None()) continue;

		bool occupied = false;
		for (const Aircraft *a : Aircraft::Iterate()) {
			if (a->targetairport == st->index && a->state != FLYING) {
				occupied = true;
				break;
			}
		}
		if (!occupied) {
			st->airport.blocks = {};
			count++;
			IConsolePrint(CC_DEFAULT, "Unblocked: {}", GetString(STR_STATION_NAME, st->index));
		}
	}

	IConsolePrint(CC_DEFAULT, "Unblocked {} heliports", count);
	return true;
}

static bool ConMergeLinkgraphJobsAsap(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Merge linkgraph jobs asap, for single-player use only.");
		return true;
	}

	for (LinkGraphJob *lgj : LinkGraphJob::Iterate()) {
		lgj->SetJoinTick(_scaled_tick_counter);
	}
	return true;
}

static bool ConUnblockBayRoadStops(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Unblock bay road stops blocked by a bug, for single-player use only.");
		return true;
	}

	for (Station *st : Station::Iterate()) {
		for (RoadStopType rs_type : { RoadStopType::Bus, RoadStopType::Truck }) {
			for (RoadStop *rs = st->GetPrimaryRoadStop(rs_type); rs != nullptr; rs = rs->next) {
				if (IsBayRoadStopTile(rs->xy)) {
					rs->DebugClearOccupancy();
				}
			}
		}
	}
	for (const RoadVehicle *rv : RoadVehicle::Iterate()) {
		if (IsInsideMM(rv->state, RVSB_IN_ROAD_STOP, RVSB_IN_ROAD_STOP_END)) {
			RoadStop::GetByTile(rv->tile, GetRoadStopType(rv->tile))->DebugReEnter(rv);
		}
	}
	return true;
}

static bool ConDbgSpecial(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Debug special.");
		return true;
	}

	if (argv.size() == 2) {
		if (argv[1] == "error") {
			FatalErrorI("User triggered");
			return true;
		}
	}

	return false;
}

#ifdef _DEBUG
static bool ConDeleteVehicleID(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Delete vehicle ID, for emergency single-player use only.");
		return true;
	}

	if (argv.size() == 2) {
		auto result = ParseInteger(argv[1], 0);
		if (result.has_value()) {
			extern void ConsoleRemoveVehicle(VehicleID id);
			ConsoleRemoveVehicle(VehicleID{*result});
			return true;
		}
	}

	return false;
}

static bool ConRunTileLoopTile(std::span<std::string_view> argv)
{
	if (argv.empty() || argv.size() > 3) {
		IConsolePrint(CC_HELP, "Run tile loop proc on tile.");
		return true;
	}

	if (argv.size() >= 2) {
		auto tile = ParseInteger(argv[1], 0);
		if (!tile.has_value()) return false;

		if (tile >= Map::Size()) {
			IConsolePrint(CC_ERROR, "Tile does not exist.");
			return true;
		}
		uint32_t count = 1;
		if (argv.size() >= 3) {
			auto val = ParseInteger(argv[2], 0);
			if (!val.has_value()) return false;
			count = *val;
		}
		for (uint32_t i = 0; i < count; i++) {
			_tile_type_procs[GetTileType(TileIndex{*tile})]->tile_loop_proc(TileIndex{*tile});
		}
		return true;
	}

	return false;
}
#endif

static bool ConGetFullDate(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Returns the current full date/tick information of the game. Usage: 'getfulldate'");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "Calendar Date: {:04}-{:02}-{:02} ({}), fract: {}, sub_fract: {}", CalTime::CurYear(), CalTime::CurMonth() + 1, CalTime::CurDay(), CalTime::CurDate(), CalTime::CurDateFract(), CalTime::Detail::now.sub_date_fract);
	IConsolePrint(CC_DEFAULT, "Economy Date: {:04}-{:02}-{:02} ({}), fract: {}, tick skip: {}", EconTime::CurYear(), EconTime::CurMonth() + 1, EconTime::CurDay(), EconTime::CurDate(), EconTime::CurDateFract(), TickSkipCounter());
	IConsolePrint(CC_DEFAULT, "Period display offset: {}", EconTime::Detail::period_display_offset);
	IConsolePrint(CC_DEFAULT, "Elapsed years: {}", EconTime::Detail::years_elapsed);
	IConsolePrint(CC_DEFAULT, "Tick counter: {}", _tick_counter);
	IConsolePrint(CC_DEFAULT, "Tick counter (scaled): {}", _scaled_tick_counter);
	IConsolePrint(CC_DEFAULT, "State ticks: {} (offset: {})", _state_ticks, DateDetail::_state_ticks_offset);
	IConsolePrint(CC_DEFAULT, "Effective economy speed reduction factor: {}", DayLengthFactor());
	if (!CalTime::IsCalendarFrozen()) IConsolePrint(CC_DEFAULT, "Ticks per calendar day: {}", TicksPerCalendarDay());
	if (_settings_time.time_in_minutes) {
		Ticks remainder = _settings_time.GetTickMinutesRemainder(_state_ticks);
		ClockFaceMinutes hhmm = _settings_time.ToTickMinutes(_state_ticks).ToClockFaceMinutes();
		IConsolePrint(CC_DEFAULT, "Timetable time: {:02}:{:02} + {} ticks", hhmm.ClockHour(), hhmm.ClockMinute(), remainder);
	}
	return true;
}

static bool ConDumpCommandLog(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump log of recently executed commands.");
		return true;
	}

	format_buffer buffer;
	DumpCommandLog(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConDumpSpecialEventsLog(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump log of special events.");
		return true;
	}

	format_buffer buffer;
	DumpSpecialEventsLog(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConDumpDesyncMsgLog(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump log of desync messages.");
		return true;
	}

	format_buffer buffer;
	DumpDesyncMsgLog(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConDumpInflation(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump inflation data.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "interest_rate: {}", _economy.interest_rate);
	IConsolePrint(CC_DEFAULT, "infl_amount: {}", _economy.infl_amount);
	IConsolePrint(CC_DEFAULT, "infl_amount_pr: {}", _economy.infl_amount_pr);
	IConsolePrint(CC_DEFAULT, "inflation_prices: {}", _economy.inflation_prices / 65536.0);
	IConsolePrint(CC_DEFAULT, "inflation_payment: {}", _economy.inflation_payment / 65536.0);
	IConsolePrint(CC_DEFAULT, "inflation ratio: {}", (double) _economy.inflation_prices / (double) _economy.inflation_payment);
	return true;
}

static bool ConDumpCpdpStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump cargo packet deferred payment stats.");
		return true;
	}

	extern std::string DumpCargoPacketDeferredPaymentStats();
	PrintLineByLine(DumpCargoPacketDeferredPaymentStats());
	return true;
}

static bool ConVehicleStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump vehicle stats.");
		return true;
	}

	extern void DumpVehicleStats(format_target &buffer);
	format_buffer buffer;
	DumpVehicleStats(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConMapStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump map stats.");
		return true;
	}

	extern void DumpMapStats(format_target &buffer);
	format_buffer buffer;
	DumpMapStats(buffer);
	PrintLineByLine(buffer);

	IConsolePrint(CC_DEFAULT, "");
	IConsolePrint(CC_DEFAULT, "towns: {}", Town::GetNumItems());
	IConsolePrint(CC_DEFAULT, "industries: {}", Industry::GetNumItems());
	IConsolePrint(CC_DEFAULT, "objects: {}", Object::GetNumItems());

	if (_settings_game.game_creation.landscape == LandscapeType::Arctic) {
		IConsolePrint(CC_DEFAULT, "");
		IConsolePrint(CC_DEFAULT, "Snow line: {}, lowest: {}, highest: {}, tree placement: {} - {}",
				GetSnowLine(), LowestSnowLine(), HighestSnowLine(), LowestTreePlacementSnowLine(), HighestTreePlacementSnowLine());
	}

	return true;
}

static bool ConStFlowStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump station flow stats.");
		return true;
	}

	extern void DumpStationFlowStats(format_target &buffer);
	format_buffer buffer;
	DumpStationFlowStats(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConSlotsStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump routing restrictions slots and counter stats.");
		return true;
	}

	extern void DumpTraceRestrictSlotsStats(format_target &buffer);
	format_buffer buffer;
	DumpTraceRestrictSlotsStats(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConDumpGameEvents(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump game events.");
		return true;
	}

	format_buffer buffer;
	DumpGameEventFlags(_game_events_since_load, buffer);
	IConsolePrint(CC_DEFAULT, "Since load: {}", buffer);
	buffer.clear();
	DumpGameEventFlags(_game_events_overall, buffer);
	IConsolePrint(CC_DEFAULT, "Overall: {}", buffer);
	return true;
}

static bool ConDumpLoadDebugLog(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump load debug log.");
		return true;
	}

	std::string dbgl = _loadgame_DBGL_data;
	PrintLineByLine(dbgl.data());
	return true;
}

static bool ConDumpLoadDebugConfig(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump load debug config.");
		return true;
	}

	std::string dbgc = _loadgame_DBGC_data;
	PrintLineByLine(dbgc.data());
	return true;
}


static bool ConDumpLinkgraphJobs(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump link-graph jobs.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "{} link graph jobs", LinkGraphJob::GetNumItems());
	for (const LinkGraphJob *lgj : LinkGraphJob::Iterate()) {
		IConsolePrint(CC_DEFAULT, "  Job: {:5}, graph: {}, cargo: {}, completed: {}, nodes: {}, cost: {}, started: {}, ends in: {}, duration: {}",
				lgj->index, lgj->LinkGraphIndex(), lgj->Cargo(), lgj->IsJobCompleted(), lgj->Graph().Size(), lgj->Graph().CalculateCostEstimate(),
				(int64_t)(lgj->StartTick() - _scaled_tick_counter), (int64_t)(lgj->JoinTick() - _scaled_tick_counter), (lgj->JoinTick() - lgj->StartTick()));
	 }
	for (const LinkGraph *graph : LinkGraph::Iterate()) {
		IConsolePrint(CC_DEFAULT, "  Graph: {}, cargo: {}, nodes: {}, OD_revision: {}", graph->index, graph->Cargo(), graph->Size(), graph->PassengerOdRevision());
	}
	return true;
}

/** List all road types and their configuration. */
static bool ConDumpRoadTypes(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump road/tram types.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "  Flags:");
	IConsolePrint(CC_DEFAULT, "    c = catenary");
	IConsolePrint(CC_DEFAULT, "    l = no level crossings");
	IConsolePrint(CC_DEFAULT, "    X = no houses");
	IConsolePrint(CC_DEFAULT, "    h = hidden");
	IConsolePrint(CC_DEFAULT, "    T = buildable by towns");
	IConsolePrint(CC_DEFAULT, "  Extra flags:");
	IConsolePrint(CC_DEFAULT, "    s = not available to scripts (AI/GS)");
	IConsolePrint(CC_DEFAULT, "    t = not modifiable by towns");
	IConsolePrint(CC_DEFAULT, "    T = disallow tunnels");
	IConsolePrint(CC_DEFAULT, "    c = disallow collisions with trains for vehicles of this type");

	btree::btree_map<GrfID, const GRFFile *> grfs;
	for (RoadType rt : EnumRange(ROADTYPE_END)) {
		const RoadTypeInfo *rti = GetRoadTypeInfo(rt);
		if (rti->label.Empty()) continue;
		GrfID grfid{};
		const GRFFile *grf = rti->grffile[RoadSpriteType::Ground];
		if (grf == nullptr) {
			GrfID str_grfid = GetStringGRFID(rti->strings.name);
			if (!str_grfid.Empty()) {
				extern GRFFile *GetFileByGRFID(GrfID grfid);
				grf = GetFileByGRFID(str_grfid);
			}
		}
		if (grf != nullptr) {
			grfid = grf->grfid;
			grfs.insert(std::pair<GrfID, const GRFFile *>(grfid, grf));
		}
		IConsolePrint(CC_DEFAULT, "  {:2} {} {}, Flags: {}{}{}{}{}, Extra Flags: {}{}{}{}, GRF: {},{}",
				(uint) rt,
				RoadTypeIsTram(rt) ? "Tram" : "Road",
				rti->label,
				rti->flags.Test(RoadTypeFlag::Catenary)        ? 'c' : '-',
				rti->flags.Test(RoadTypeFlag::NoLevelCrossing) ? 'l' : '-',
				rti->flags.Test(RoadTypeFlag::NoHouses)        ? 'X' : '-',
				rti->flags.Test(RoadTypeFlag::Hidden)          ? 'h' : '-',
				rti->flags.Test(RoadTypeFlag::TownBuild)       ? 'T' : '-',
				rti->extra_flags.Test(RoadTypeExtraFlag::NotAvailableAiGs)   ? 's' : '-',
				rti->extra_flags.Test(RoadTypeExtraFlag::NoTownModification) ? 't' : '-',
				rti->extra_flags.Test(RoadTypeExtraFlag::NoTunnels)          ? 'T' : '-',
				rti->extra_flags.Test(RoadTypeExtraFlag::NoTrainCollision)   ? 'c' : '-',
				grfid,
				GetStringFmtParam(rti->strings.name)
		);
	}
	for (const auto &grf : grfs) {
		IConsolePrint(CC_DEFAULT, "  GRF: {} = {}", grf.first, grf.second->filename);
	}
	return true;
}

static bool ConDumpRailTypes(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump rail types.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "  Flags:");
	IConsolePrint(CC_DEFAULT, "    c = catenary");
	IConsolePrint(CC_DEFAULT, "    l = no level crossings");
	IConsolePrint(CC_DEFAULT, "    h = hidden");
	IConsolePrint(CC_DEFAULT, "    s = no sprite combine");
	IConsolePrint(CC_DEFAULT, "    a = allow 90° turns");
	IConsolePrint(CC_DEFAULT, "    d = disallow 90° turns");
	IConsolePrint(CC_DEFAULT, "  Ctrl flags:");
	IConsolePrint(CC_DEFAULT, "    p = signal graphics callback enabled for programmable pre-signals");
	IConsolePrint(CC_DEFAULT, "    r = signal graphics callback restricted signal flag enabled");

	btree::btree_map<GrfID, const GRFFile *> grfs;
	for (RailType rt : EnumRange(RAILTYPE_END)) {
		const RailTypeInfo *rti = GetRailTypeInfo(rt);
		if (rti->label.Empty()) continue;
		GrfID grfid{};
		const GRFFile *grf = rti->grffile[RailSpriteType::Ground];
		if (grf == nullptr) {
			GrfID str_grfid = GetStringGRFID(rti->strings.name);
			if (!str_grfid.Empty()) {
				extern GRFFile *GetFileByGRFID(GrfID grfid);
				grf = GetFileByGRFID(str_grfid);
			}
		}
		if (grf != nullptr) {
			grfid = grf->grfid;
			grfs.insert(std::pair<GrfID, const GRFFile *>(grfid, grf));
		}
		IConsolePrint(CC_DEFAULT, "  {:2} {}, Flags: {}{}{}{}{}{}, Ctrl Flags: {}{}{}{}{}, GRF: {}, {}",
				(uint) rt,
				rti->label,
				rti->flags.Test(RailTypeFlag::Catenary)        ? 'c' : '-',
				rti->flags.Test(RailTypeFlag::NoLevelCrossing) ? 'l' : '-',
				rti->flags.Test(RailTypeFlag::Hidden)          ? 'h' : '-',
				rti->flags.Test(RailTypeFlag::NoSpriteCombine) ? 's' : '-',
				rti->flags.Test(RailTypeFlag::Allow90Deg)      ? 'a' : '-',
				rti->flags.Test(RailTypeFlag::Disallow90Deg)   ? 'd' : '-',
				rti->ctrl_flags.Test(RailTypeCtrlFlag::SigSpriteProgSig)         ? 'p' : '-',
				rti->ctrl_flags.Test(RailTypeCtrlFlag::SigSpriteRestrictedSig)   ? 'r' : '-',
				rti->ctrl_flags.Test(RailTypeCtrlFlag::NoRealisticBraking)       ? 'b' : '-',
				rti->ctrl_flags.Test(RailTypeCtrlFlag::SigSpriteRecolourEnabled) ? 'c' : '-',
				rti->ctrl_flags.Test(RailTypeCtrlFlag::SigSpriteNoEntry)         ? 'n' : '-',
				grfid,
				GetStringFmtParam(rti->strings.name)
		);
	}
	for (const auto &grf : grfs) {
		IConsolePrint(CC_DEFAULT, "  GRF: {} = {}", grf.first, grf.second->filename);
	}
	return true;
}

static bool ConDumpBridgeTypes(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump bridge types.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "  Ctrl flags:");
	IConsolePrint(CC_DEFAULT, "    c = custom pillar flags");
	IConsolePrint(CC_DEFAULT, "    i = invalid pillar flags");
	IConsolePrint(CC_DEFAULT, "    t = not available to towns");
	IConsolePrint(CC_DEFAULT, "    s = not available to scripts (AI/GS)");

	btree::btree_set<GrfID> grfids;
	for (BridgeType bt = 0; bt < MAX_BRIDGES; bt++) {
		const BridgeSpec *spec = GetBridgeSpec(bt);
		GrfID grfid = GetStringGRFID(spec->material);
		if (!grfid.Empty()) grfids.insert(grfid);
		IConsolePrint(CC_DEFAULT, "  {:2} Year: {:7}, Min: {:3}, Max: {:5}, Flags: {:02X}, Ctrl Flags: {}{}{}{}, Pillars: {:02X} {:02X} {:02X} {:02X} {:02X} {:02X} {:02X} {:02X} {:02X} {:02X} {:02X} {:02X}, GRF: {}, {}",
				(uint) bt,
				spec->avail_year,
				spec->min_length,
				spec->max_length,
				spec->flags,
				HasBit(spec->ctrl_flags, BSCF_CUSTOM_PILLAR_FLAGS) ? 'c' : '-',
				HasBit(spec->ctrl_flags, BSCF_INVALID_PILLAR_FLAGS) ? 'i' : '-',
				HasBit(spec->ctrl_flags, BSCF_NOT_AVAILABLE_TOWN) ? 't' : '-',
				HasBit(spec->ctrl_flags, BSCF_NOT_AVAILABLE_AI_GS) ? 's' : '-',
				spec->pillar_flags[0],
				spec->pillar_flags[1],
				spec->pillar_flags[2],
				spec->pillar_flags[3],
				spec->pillar_flags[4],
				spec->pillar_flags[5],
				spec->pillar_flags[6],
				spec->pillar_flags[7],
				spec->pillar_flags[8],
				spec->pillar_flags[9],
				spec->pillar_flags[10],
				spec->pillar_flags[11],
				grfid,
				GetStringFmtParam(spec->material)
		);
	}
	for (GrfID grfid : grfids) {
		extern GRFFile *GetFileByGRFID(GrfID grfid);
		const GRFFile *grffile = GetFileByGRFID(grfid);
		IConsolePrint(CC_DEFAULT, "  GRF: {} = {}", grfid, grffile ? (std::string_view)grffile->filename : "????");
	}
	return true;
}

static bool ConDumpCargoTypes(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump cargo types.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "  Cargo classes:");
	IConsolePrint(CC_DEFAULT, "    p = passenger");
	IConsolePrint(CC_DEFAULT, "    m = mail");
	IConsolePrint(CC_DEFAULT, "    x = express");
	IConsolePrint(CC_DEFAULT, "    a = armoured");
	IConsolePrint(CC_DEFAULT, "    b = bulk");
	IConsolePrint(CC_DEFAULT, "    g = piece goods");
	IConsolePrint(CC_DEFAULT, "    l = liquid");
	IConsolePrint(CC_DEFAULT, "    r = refrigerated");
	IConsolePrint(CC_DEFAULT, "    h = hazardous");
	IConsolePrint(CC_DEFAULT, "    c = covered/sheltered");
	IConsolePrint(CC_DEFAULT, "    o = oversized");
	IConsolePrint(CC_DEFAULT, "    d = powderized");
	IConsolePrint(CC_DEFAULT, "    n = not pourable");
	IConsolePrint(CC_DEFAULT, "    e = potable");
	IConsolePrint(CC_DEFAULT, "    i = non-potable");
	IConsolePrint(CC_DEFAULT, "    S = special");
	IConsolePrint(CC_DEFAULT, "  Town acceptance effect:");
	IConsolePrint(CC_DEFAULT, "    P = passenger");
	IConsolePrint(CC_DEFAULT, "    M = mail");
	IConsolePrint(CC_DEFAULT, "    G = goods");
	IConsolePrint(CC_DEFAULT, "    W = water");
	IConsolePrint(CC_DEFAULT, "    F = food");

	static constexpr EnumIndexArray<char, TownAcceptanceEffect, TownAcceptanceEffect::End> tae_char{ '-', 'P', 'M', 'G', 'W', 'F' };

	btree::btree_map<GrfID, const GRFFile *> grfs;
	for (CargoType i{}; i < NUM_CARGO; i++) {
		const CargoSpec *spec = CargoSpec::Get(i);
		GrfID grfid{};
		const GRFFile *grf = spec->grffile;
		if (grf == nullptr) {
			GrfID str_grfid = GetStringGRFID(spec->name);
			if (!str_grfid.Empty()) {
				extern GRFFile *GetFileByGRFID(GrfID grfid);
				grf = GetFileByGRFID(str_grfid);
			}
		}
		if (grf != nullptr) {
			grfid = grf->grfid;
			grfs.insert(std::pair<GrfID, const GRFFile *>(grfid, grf));
		}
		IConsolePrint(CC_DEFAULT, "  {:2} Bit: {:2}, Label: {}, Callback mask: 0x{:02X}, Cargo class: {}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}, Town: {}, GRF: {}, {}",
				(uint) i,
				spec->bitnum,
				spec->label,
				spec->callback_mask,
				spec->classes.Test(CargoClass::Passengers)   ? 'p' : '-',
				spec->classes.Test(CargoClass::Mail)         ? 'm' : '-',
				spec->classes.Test(CargoClass::Express)      ? 'x' : '-',
				spec->classes.Test(CargoClass::Armoured)     ? 'a' : '-',
				spec->classes.Test(CargoClass::Bulk)         ? 'b' : '-',
				spec->classes.Test(CargoClass::PieceGoods)   ? 'g' : '-',
				spec->classes.Test(CargoClass::Liquid)       ? 'l' : '-',
				spec->classes.Test(CargoClass::Refrigerated) ? 'r' : '-',
				spec->classes.Test(CargoClass::Hazardous)    ? 'h' : '-',
				spec->classes.Test(CargoClass::Covered)      ? 'c' : '-',
				spec->classes.Test(CargoClass::Oversized)    ? 'o' : '-',
				spec->classes.Test(CargoClass::Powderized)   ? 'd' : '-',
				spec->classes.Test(CargoClass::NotPourable)  ? 'n' : '-',
				spec->classes.Test(CargoClass::Potable)      ? 'e' : '-',
				spec->classes.Test(CargoClass::NonPotable)   ? 'i' : '-',
				spec->classes.Test(CargoClass::Special)      ? 'S' : '-',
				tae_char[spec->town_acceptance_effect],
				grfid,
				GetStringFmtParam(spec->name)
		);
	}
	for (const auto &grf : grfs) {
		IConsolePrint(CC_DEFAULT, "  GRF: {} = {}", grf.first, grf.second->filename);
	}
	return true;
}

static bool ConDumpVehicle(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Show vehicle information.  Usage: 'dump_vehicle <vehicle-id>'");
		return true;
	}

	const Vehicle *v = Vehicle::GetIfValid(ParseType<VehicleID>(argv[1]).value_or(VehicleID::Invalid()));
	if (v != nullptr) {
		IConsolePrint(CC_DEFAULT, "{}", VehicleInfoDumper(v));
	} else {
		IConsolePrint(CC_DEFAULT, "No such vehicle");
	}

	return true;
}

/**
 * Dump the state of a tile on the map.
 * param x tile number or tile x coordinate.
 * param y optional y coordinate.
 * @note When only one argument is given it is interpreted as the tile number.
 *       When two arguments are given, they are interpreted as the tile's x
 *       and y coordinates.
 * @return True when either console help was shown or a proper amount of parameters given.
 */
static bool ConDumpTile(std::span<std::string_view> argv)
{
	switch (argv.size()) {
		case 0:
			IConsolePrint(CC_HELP, "Dump the map state of a given tile.");
			IConsolePrint(CC_HELP, "Usage: 'dump_tile <tile>' or 'dump_tile <x> <y>'");
			IConsolePrint(CC_HELP, "Numbers can be either decimal (34161) or hexadecimal (0x4a5B).");
			return true;

		case 2: {
			auto result = ParseInteger(argv[1]);
			if (result.has_value()) {
				if (*result >= Map::Size()) {
					IConsolePrint(CC_ERROR, "Tile does not exist.");
					return true;
				}
				format_buffer buffer;
				buffer.append("  ");
				DumpTileInfo(buffer, (TileIndex)*result);
				IConsolePrint(CC_DEFAULT, buffer.to_string());
				return true;
			}
			break;
		}

		case 3: {
			auto x = ParseInteger(argv[1]);
			auto y = ParseInteger(argv[2]);
			if (x.has_value() && y.has_value()) {
				if (*x >= Map::SizeX() || *y >= Map::SizeY()) {
					IConsolePrint(CC_ERROR, "Tile does not exist.");
					return true;
				}
				format_buffer buffer;
				buffer.append("  ");
				DumpTileInfo(buffer, TileXY(*x, *y));
				IConsolePrint(CC_DEFAULT, buffer.to_string());
				return true;
			}
			break;
		}
	}

	return false;
}

static bool ConDumpGrfCargoTables(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump GRF cargo translation tables.");
		return true;
	}

	const std::span<const GRFFile> files = GetAllGRFFiles();

	format_buffer buffer;

	for (const GRFFile &grf : files) {
		if (grf.cargo_list.empty()) continue;

		IConsolePrint(CC_DEFAULT, "[{}] {}: {} cargoes", grf.grfid, grf.filename, grf.cargo_list.size());

		uint i = 0;
		for (const CargoLabel &cl : grf.cargo_list) {
			buffer.clear();
			for (const CargoSpec *cs : CargoSpec::Iterate()) {
				if (grf.cargo_map[cs->Index()] == i) {
					buffer.format("{}{:02}[{}]", buffer.size() == 0 ? ": " : ", ", cs->Index(), cs->label);
				}
			}
			IConsolePrint(CC_DEFAULT, "  {}{}", cl, buffer);
			i++;
		}
	}

	return true;
}

static bool ConDumpSignalStyles(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump custom signal styles.");
		return true;
	}

	IConsolePrint(CC_DEFAULT, "  Flags:");
	IConsolePrint(CC_DEFAULT, "    n = no aspect increment");
	IConsolePrint(CC_DEFAULT, "    a = always reserve through");
	IConsolePrint(CC_DEFAULT, "    l = lookahead aspects set");
	IConsolePrint(CC_DEFAULT, "    o = opposite side");
	IConsolePrint(CC_DEFAULT, "    s = lookahead single signal");
	IConsolePrint(CC_DEFAULT, "    c = combined normal and shunt");
	IConsolePrint(CC_DEFAULT, "    r = realistic braking only");
	IConsolePrint(CC_DEFAULT, "    b = both sides");
	IConsolePrint(CC_DEFAULT, "  Extra aspects: {}", _extra_aspects);
	IConsolePrint(CC_DEFAULT, "  Default style extra aspects: {}", _default_signal_style_lookahead_extra_aspects);

	btree::btree_map<GrfID, const GRFFile *> grfs;
	for (uint8_t i = 0; i < _num_new_signal_styles; i++) {
		const NewSignalStyle &style = _new_signal_styles[i];

		GrfID grfid{};
		if (style.grffile != nullptr) {
			grfid = style.grffile->grfid;
			grfs.insert(std::pair<GrfID, const GRFFile *>(grfid, style.grffile));
		}
		IConsolePrint(CC_DEFAULT, "  {:2}: GRF: {}, Local: {:2}, Extra aspects: {:3}, Flags: {}{}{}{}{}{}{}{}, {}",
				(uint) (i + 1),
				grfid,
				style.grf_local_id,
				style.lookahead_extra_aspects,
				HasBit(style.style_flags, NSSF_NO_ASPECT_INC)           ? 'n' : '-',
				HasBit(style.style_flags, NSSF_ALWAYS_RESERVE_THROUGH)  ? 'a' : '-',
				HasBit(style.style_flags, NSSF_LOOKAHEAD_ASPECTS_SET)   ? 'l' : '-',
				HasBit(style.style_flags, NSSF_OPPOSITE_SIDE)           ? 'o' : '-',
				HasBit(style.style_flags, NSSF_LOOKAHEAD_SINGLE_SIGNAL) ? 's' : '-',
				HasBit(style.style_flags, NSSF_COMBINED_NORMAL_SHUNT)   ? 'c' : '-',
				HasBit(style.style_flags, NSSF_REALISTIC_BRAKING_ONLY)  ? 'r' : '-',
				HasBit(style.style_flags, NSSF_BOTH_SIDES)              ? 'b' : '-',
				GetStringFmtParam(style.name)
		);
	}
	for (const auto &grf : grfs) {
		IConsolePrint(CC_DEFAULT, "  GRF: {} = {}", grf.first, grf.second->filename);
	}

	return true;
}

static bool ConSpriteCacheStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump sprite cache stats.");
		return true;
	}

	extern void DumpSpriteCacheStats(format_target &buffer);
	format_buffer buffer;
	DumpSpriteCacheStats(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConDumpVersion(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Dump version info");
		return true;
	}

	format_buffer buffer;
	CrashLog::VersionInfoLog(buffer);
	PrintLineByLine(buffer);
	return true;
}

static bool ConCheckCaches(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Debug: Check caches. Usage: 'check_caches [<broadcast>]'");
		return true;
	}

	if (argv.size() > 2) return false;

	bool broadcast = (argv.size() == 2 && ParseInteger(argv[1]).value_or(0) > 0 && (!_networking || _network_server));
	if (broadcast) {
		Command<Commands::DesyncCheck>::Post();
	} else {
		auto logger = [&](std::string_view str) {
			IConsolePrint(CC_WARNING, std::string{str});
		};
		CheckCaches(true, logger, CHECK_CACHE_ALL | CHECK_CACHE_EMIT_LOG);
	}

	return true;
}

static bool ConShowTownWindow(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Show town window.  Usage: 'show_town_window <town-id>'");
		return true;
	}

	if (_game_mode != GameMode::Normal && _game_mode != GameMode::Editor) {
		return true;
	}

	TownID town_id = ParseType<TownID>(argv[1]).value_or(TownID::Invalid());
	if (!Town::IsValidID(town_id)) {
		return true;
	}

	ShowTownViewWindow(town_id);

	return true;
}

static bool ConShowStationWindow(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Show station window.  Usage: 'show_station_window <station-id>'");
		return true;
	}

	if (_game_mode != GameMode::Normal && _game_mode != GameMode::Editor) {
		return true;
	}

	const BaseStation *bst = BaseStation::GetIfValid(ParseType<StationID>(argv[1]).value_or(StationID::Invalid()));
	if (bst == nullptr) return true;
	if (bst->facilities.Test(StationFacility::Waypoint)) {
		ShowWaypointWindow(Waypoint::From(bst));
	} else {
		ShowStationViewWindow(bst->index);
	}

	return true;
}

static bool ConShowIndustryWindow(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Show industry window.  Usage: 'show_industry_window <industry-id>'");
		return true;
	}

	if (_game_mode != GameMode::Normal && _game_mode != GameMode::Editor) {
		return true;
	}

	IndustryID ind_id = ParseType<IndustryID>(argv[1]).value_or(IndustryID::Invalid());
	if (!Industry::IsValidID(ind_id)) {
		return true;
	}

	extern void ShowIndustryViewWindow(IndustryID industry);
	ShowIndustryViewWindow(ind_id);

	return true;
}

static bool ConViewportDebug(std::span<std::string_view> argv)
{
	if (argv.size() < 1 || argv.size() > 2) {
		IConsolePrint(CC_HELP, "Debug: viewports flags.  Usage: 'viewport_debug [<flags>]'");
		IConsolePrint(CC_HELP, "   1: VDF_DIRTY_BLOCK_PER_DRAW");
		IConsolePrint(CC_HELP, "   2: VDF_DIRTY_WHOLE_VIEWPORT");
		IConsolePrint(CC_HELP, "   4: VDF_DIRTY_BLOCK_PER_SPLIT");
		IConsolePrint(CC_HELP, "   8: VDF_DISABLE_DRAW_SPLIT");
		IConsolePrint(CC_HELP, "  10: VDF_SHOW_NO_LANDSCAPE_MAP_DRAW");
		IConsolePrint(CC_HELP, "  20: VDF_DISABLE_LANDSCAPE_CACHE");
		IConsolePrint(CC_HELP, "  40: VDF_DISABLE_THREAD");
		return true;
	}

	extern uint32_t _viewport_debug_flags;
	if (argv.size() == 1) {
		IConsolePrint(CC_DEFAULT, "Viewport debug flags: {:X}", _viewport_debug_flags);
	} else {
		auto val = ParseInteger(argv[1], 16);
		if (val.has_value()) {
			_viewport_debug_flags = *val;
		} else {
			IConsolePrint(CC_ERROR, "Unable to parse: {}", argv[1]);
		}
	}

	return true;
}

static bool ConViewportMarkDirty(std::span<std::string_view> argv)
{
	if (argv.size() < 3 || argv.size() > 5) {
		IConsolePrint(CC_HELP, "Debug: Mark main viewport dirty.  Usage: 'viewport_mark_dirty <x> <y> [<w> <h>]'");
		return true;
	}

	Viewport *vp = FindWindowByClass(WindowClass::MainWindow)->viewport;
	uint l = ParseInteger(argv[1], 0).value_or(0);
	uint t = ParseInteger(argv[2], 0).value_or(0);
	uint r = std::min<uint>(l + ((argv.size() > 3) ? ParseInteger(argv[3], 0).value_or(0) : 1), vp->dirty_blocks_per_row);
	uint b = std::min<uint>(t + ((argv.size() > 4) ? ParseInteger(argv[4], 0).value_or(0) : 1), vp->dirty_blocks_per_column);
	for (uint x = l; x < r; x++) {
		for (uint y = t; y < b; y++) {
			SetBit(vp->dirty_blocks[(x * vp->dirty_blocks_column_pitch) + (y / VP_BLOCK_BITS)], y % VP_BLOCK_BITS);
		}
	}
	vp->is_dirty = true;

	return true;
}


static bool ConViewportMarkStationOverlayDirty(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Mark main viewport link graph overlay station links.  Usage: 'viewport_mark_dirty_st_overlay <station-id>'");
		return true;
	}

	if (_game_mode != GameMode::Normal && _game_mode != GameMode::Editor) {
		return true;
	}

	const Station *st = Station::GetIfValid(ParseType<StationID>(argv[1]).value_or(StationID::Invalid()));
	if (st == nullptr) return true;
	MarkAllViewportOverlayStationLinksDirty(st);

	return true;
}

static bool ConGfxDebug(std::span<std::string_view> argv)
{
	if (argv.size() < 1 || argv.size() > 2) {
		IConsolePrint(CC_HELP, "Debug: gfx flags.  Usage: 'gfx_debug [<flags>]'");
		IConsolePrint(CC_HELP, "  1: GDF_SHOW_WINDOW_DIRTY");
		IConsolePrint(CC_HELP, "  2: GDF_SHOW_WIDGET_DIRTY");
		IConsolePrint(CC_HELP, "  4: GDF_SHOW_RECT_DIRTY");
		return true;
	}

	extern uint32_t _gfx_debug_flags;
	if (argv.size() == 1) {
		IConsolePrint(CC_DEFAULT, "Gfx debug flags: {:X}", _gfx_debug_flags);
	} else {
		_gfx_debug_flags = ParseInteger(argv[1], 16).value_or(0);
	}

	return true;
}

static bool ConCSleep(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Sleep.  Usage: 'csleep <milliseconds>'");
		return true;
	}

	CSleep(ParseInteger(argv[1]).value_or(0));

	return true;
}

static bool ConRecalculateRoadCachedOneWayStates(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Debug: Recalculate road cached one way states");
		return true;
	}

	extern void RecalculateRoadCachedOneWayStates();
	RecalculateRoadCachedOneWayStates();

	return true;
}

static bool ConMiscDebug(std::span<std::string_view> argv)
{
	if (argv.size() < 1 || argv.size() > 2) {
		IConsolePrint(CC_HELP, "Debug: misc flags.  Usage: 'misc_debug [<flags>]'");
		IConsolePrint(CC_HELP, "  1: MDF_OVERHEAT_BREAKDOWN_OPEN_WIN");
		IConsolePrint(CC_HELP, "  2: MDF_ZONING_DEBUG_MODES");
		IConsolePrint(CC_HELP, "  4: MDF_LANDINFO_TILE_DUMP");
		IConsolePrint(CC_HELP, " 10: MDF_NEWGRF_SG_SAVE_RAW");
		IConsolePrint(CC_HELP, " 20: MDF_SPECIAL_CMDS");
		return true;
	}

	if (argv.size() == 1) {
		IConsolePrint(CC_DEFAULT, "Misc debug flags: {:X}", _misc_debug_flags);
	} else {
		_misc_debug_flags = ParseInteger(argv[1], 16).value_or(0);
	}

	return true;
}

static bool ConSetNewGRFOptimiserFlags(std::span<std::string_view> argv)
{
	if (argv.size() < 1 || argv.size() > 2) {
		IConsolePrint(CC_HELP, "Debug: misc set_newgrf_optimiser_flags.  Usage: 'set_newgrf_optimiser_flags [<flags>]'");
		return true;
	}

	if (argv.size() == 1) {
		IConsolePrint(CC_DEFAULT, "NewGRF optimiser flags: {:X}", _settings_game.debug.newgrf_optimiser_flags);
	} else {
		if (_game_mode == GameMode::Menu || (_networking && !_network_server)) {
			IConsolePrint(CC_ERROR, "This command is only available in-game and in the editor, and not as a network client.");
			return true;
		}
		extern uint NetworkClientCount();
		if (_networking && NetworkClientCount() > 1) {
			IConsolePrint(CC_ERROR, "This command is not available when network clients are connected.");
			return true;
		}

		auto value = ParseInteger(argv[1], 16);
		if (!value.has_value()) {
			IConsolePrint(CC_ERROR, "Failed to parse: {}", argv[1]);
			return true;
		}
		if (_settings_game.debug.newgrf_optimiser_flags == *value) return true;
		_settings_game.debug.newgrf_optimiser_flags = *value;

		ReloadNewGRFData();

		extern void PostCheckNewGRFLoadWarnings();
		PostCheckNewGRFLoadWarnings();
	}

	return true;
}

static bool ConDoDisaster(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Debug: Do disaster");
		return true;
	}

	extern void DoDisaster();
	DoDisaster();

	return true;
}

static bool ConBankruptCompany(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Mark company as bankrupt.  Usage: 'bankrupt_company <company-id>'");
		return true;
	}

	if (_game_mode != GameMode::Normal) {
		IConsolePrint(CC_ERROR, "Companies can only be managed in a game.");
		return true;
	}

	CompanyID company_id = ParseCompanyID(argv[1]).value_or(CompanyID::Invalid());
	if (!Company::IsValidID(company_id)) {
		IConsolePrint(CC_DEFAULT, "Unknown company. Company range is between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	Company *c = Company::Get(company_id);
	c->bankrupt_value = 42;
	c->bankrupt_asked = CompanyMask{}.Set(c->index); // Don't ask the owner
	c->bankrupt_timeout = 0;
	c->money = INT64_MIN / 2;
	IConsolePrint(CC_DEFAULT, "Company marked as bankrupt.");

	return true;
}

static bool ConDeleteCompany(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Delete company.  Usage: 'delete_company <company-id>'");
		return true;
	}

	if (_game_mode != GameMode::Normal) {
		IConsolePrint(CC_ERROR, "Companies can only be managed in a game.");
		return true;
	}

	CompanyID company_id = ParseCompanyID(argv[1]).value_or(CompanyID::Invalid());
	if (!Company::IsValidID(company_id)) {
		IConsolePrint(CC_DEFAULT, "Unknown company. Company range is between 1 and {}.", MAX_COMPANIES);
		return true;
	}

	if (company_id == _local_company) {
		IConsolePrint(CC_ERROR, "Cannot delete current company.");
		return true;
	}

	Command<Commands::CompanyControl>::Post(CompanyCtrlAction::Delete, company_id, CompanyRemoveReason::Manual, ClientID::Invalid, {});
	IConsolePrint(CC_DEFAULT, "Company deleted.");

	return true;
}

/** Management of NewGRF profiling. @copydoc IConsoleCmdProc */
static bool ConNewGRFProfile(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Collect performance data about NewGRF sprite requests and callbacks. Sub-commands can be abbreviated.");
		IConsolePrint(CC_HELP, "Usage: 'newgrf_profile [list]':");
		IConsolePrint(CC_HELP, "  List all NewGRFs that can be profiled, and their status.");
		IConsolePrint(CC_HELP, "Usage: 'newgrf_profile select <grf-num>...':");
		IConsolePrint(CC_HELP, "  Select one or more GRFs for profiling.");
		IConsolePrint(CC_HELP, "Usage: 'newgrf_profile unselect <grf-num>...':");
		IConsolePrint(CC_HELP, "  Unselect one or more GRFs from profiling. Use the keyword \"all\" instead of a GRF number to unselect all. Removing an active profiler aborts data collection.");
		IConsolePrint(CC_HELP, "Usage: 'newgrf_profile start [<num-ticks>]':");
		IConsolePrint(CC_HELP, "  Begin profiling all selected GRFs. If a number of ticks is provided, profiling stops after that many game ticks. There are 74 ticks in a calendar day.");
		IConsolePrint(CC_HELP, "Usage: 'newgrf_profile stop':");
		IConsolePrint(CC_HELP, "  End profiling and write the collected data to CSV files.");
		IConsolePrint(CC_HELP, "Usage: 'newgrf_profile abort':");
		IConsolePrint(CC_HELP, "  End profiling and discard all collected data.");
		return true;
	}

	std::span<const GRFFile> files = GetAllGRFFiles();

	/* "list" sub-command */
	if (argv.size() == 1 || StrStartsWithIgnoreCase(argv[1], "lis")) {
		IConsolePrint(CC_INFO, "Loaded GRF files:");
		int i = 1;
		for (const auto &grf : files) {
			auto profiler = std::ranges::find(_newgrf_profilers, &grf, &NewGRFProfiler::grffile);
			bool selected = profiler != _newgrf_profilers.end();
			bool active = selected && profiler->active;
			TextColour tc = active ? TextColour::LightBlue : selected ? TextColour::Green : CC_INFO;
			std::string_view statustext = active ? " (active)" : selected ? " (selected)" : "";
			IConsolePrint(tc, "{}: [{}] {}{}", i, FormatArrayAsHex(grf.grfid), grf.filename, statustext);
			i++;
		}
		return true;
	}

	/* "select" sub-command */
	if (StrStartsWithIgnoreCase(argv[1], "sel") && argv.size() >= 3) {
		for (size_t argnum = 2; argnum < argv.size(); ++argnum) {
			auto grfnum = ParseInteger(argv[argnum]);
			if (!grfnum.has_value() || *grfnum < 1 || static_cast<size_t>(*grfnum) > files.size()) {
				IConsolePrint(CC_WARNING, "GRF number {} out of range, not added.", *grfnum);
				continue;
			}
			const GRFFile *grf = &files[*grfnum - 1];
			if (std::any_of(_newgrf_profilers.begin(), _newgrf_profilers.end(), [&](NewGRFProfiler &pr) { return pr.grffile == grf; })) {
				IConsolePrint(CC_WARNING, "GRF number {} [{}] is already selected for profiling.", *grfnum, FormatArrayAsHex(grf->grfid));
				continue;
			}
			_newgrf_profilers.emplace_back(grf);
		}
		return true;
	}

	/* "unselect" sub-command */
	if (StrStartsWithIgnoreCase(argv[1], "uns") && argv.size() >= 3) {
		for (size_t argnum = 2; argnum < argv.size(); ++argnum) {
			if (StrEqualsIgnoreCase(argv[argnum], "all")) {
				_newgrf_profilers.clear();
				break;
			}
			auto grfnum = ParseInteger(argv[argnum]);
			if (!grfnum.has_value() || *grfnum < 1 || static_cast<size_t>(*grfnum) > files.size()) {
				IConsolePrint(CC_WARNING, "GRF number {} out of range, not removing.", *grfnum);
				continue;
			}
			const GRFFile *grf = &files[*grfnum - 1];
			_newgrf_profilers.erase(std::ranges::find(_newgrf_profilers, grf, &NewGRFProfiler::grffile));
		}
		return true;
	}

	/* "start" sub-command */
	if (StrStartsWithIgnoreCase(argv[1], "sta")) {
		format_buffer grfids;
		size_t started = 0;
		for (NewGRFProfiler &pr : _newgrf_profilers) {
			if (!pr.active) {
				pr.Start();
				started++;

				if (!grfids.empty()) grfids.append(", ");
				grfids.format("[{}]", pr.grffile->grfid);
			}
		}
		if (started > 0) {
			IConsolePrint(CC_DEBUG, "Started profiling for GRFID{} {}.", (started > 1) ? "s" : "", grfids);

			if (argv.size() >= 3) {
				auto ticks = StringConsumer{argv[2]}.TryReadIntegerBase<uint64_t>(0);
				if (!ticks.has_value()) {
					IConsolePrint(CC_ERROR, "No valid amount of ticks was given, profiling will not stop automatically.");
				} else {
					NewGRFProfiler::StartTimer(*ticks);
					IConsolePrint(CC_DEBUG, "Profiling will automatically stop after {} ticks.", *ticks);
				}
			}
		} else if (_newgrf_profilers.empty()) {
			IConsolePrint(CC_ERROR, "No GRFs selected for profiling, did not start.");
		} else {
			IConsolePrint(CC_ERROR, "Did not start profiling for any GRFs, all selected GRFs are already profiling.");
		}
		return true;
	}

	/* "stop" sub-command */
	if (StrStartsWithIgnoreCase(argv[1], "sto")) {
		NewGRFProfiler::FinishAll();
		return true;
	}

	/* "abort" sub-command */
	if (StrStartsWithIgnoreCase(argv[1], "abo")) {
		for (NewGRFProfiler &pr : _newgrf_profilers) {
			pr.Abort();
		}
		NewGRFProfiler::AbortTimer();
		return true;
	}

	return false;
}

static bool ConRoadTypeFlagCtl(std::span<std::string_view> argv)
{
	if (argv.size() != 3) {
		IConsolePrint(CC_HELP, "Debug: Road/tram type flag control.");
		return true;
	}

	RoadType rt = ParseType<RoadType>(argv[1]).value_or(ROADTYPE_END);
	auto flag = ParseInteger(argv[2]);
	if (!flag.has_value()) {
		IConsolePrint(CC_ERROR, "Failed to parse: {}", argv[2]);
		return true;
	}

	if (rt >= ROADTYPE_END) return true;
	extern RoadTypeInfo _roadtypes[ROADTYPE_END];

	if (*flag >= 100) {
		ToggleBit(_roadtypes[rt].extra_flags.edit_base(), *flag - 100);
	} else {
		ToggleBit(_roadtypes[rt].flags.edit_base(), *flag);
	}

	return true;
}

static bool ConRailTypeMapColourCtl(std::span<std::string_view> argv)
{
	if (argv.size() != 3) {
		IConsolePrint(CC_HELP, "Debug: Rail type map colour control.");
		return true;
	}

	RailType rt = ParseType<RailType>(argv[1]).value_or(RAILTYPE_END);
	auto map_colour = ParseInteger<uint8_t>(argv[2]);
	if (!map_colour.has_value()) {
		IConsolePrint(CC_ERROR, "Failed to parse: {}", argv[2]);
		return true;
	}

	if (rt >= RAILTYPE_END) return true;
	extern RailTypeInfo _railtypes[RAILTYPE_END];

	_railtypes[rt].map_colour = PixelColour{*map_colour};
	MarkAllViewportMapLandscapesDirty();

	return true;
}

static bool ConSwitchBaseset(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Debug: Try to switch baseset and reload NewGRFs. Usage: 'switch_baseset <baseset-name>'");
		return true;
	}

	for (int i = 0; i < BaseGraphics::GetNumSets(); i++) {
		const GraphicsSet *basegfx = BaseGraphics::GetSet(i);
		if (argv[1] == basegfx->name) {
			extern std::string _switch_baseset;
			_switch_baseset = basegfx->name;
			_check_special_modes = true;
			return true;
		}
	}

	IConsolePrint(CC_WARNING, "No such baseset: {}.", argv[1]);
	return 1;
}

static bool ConConditionalCommon(std::span<std::string_view> argv, int value, const char *value_name, const char *name)
{
	if (argv.size() < 4) {
		IConsolePrint(CC_WARNING, "- Execute command if {} is within the specified range. Usage: '{} <minimum> <maximum> <command...>'", value_name, name);
		return true;
	}

	auto min_value = StringConsumer{argv[1]}.TryReadIntegerBase<int>(10);
	auto max_value = StringConsumer{argv[2]}.TryReadIntegerBase<int>(10);
	if (!min_value.has_value() || !max_value.has_value()) {
		IConsolePrint(CC_ERROR, "Failed to parse values.");
		return true;
	}

	if (value >= *min_value && value <= *max_value) IConsoleCmdExecTokens(argv.subspan(3));

	return true;
}

static bool ConIfYear(std::span<std::string_view> argv)
{
	return ConConditionalCommon(argv, CalTime::CurYear().base(), "the current year (in game)", "if_year");
}

static bool ConIfMonth(std::span<std::string_view> argv)
{
	return ConConditionalCommon(argv, CalTime::CurMonth() + 1, "the current month (in game)", "if_month");
}

static bool ConIfDay(std::span<std::string_view> argv)
{
	return ConConditionalCommon(argv, CalTime::CurDay(), "the current day of the month (in game)", "if_day");
}

static bool ConIfHour(std::span<std::string_view> argv)
{
	TickMinutes minutes = _settings_time.NowInTickMinutes();
	return ConConditionalCommon(argv, minutes.ClockHour(), "the current hour (in game, assuming time is in minutes)", "if_hour");
}

static bool ConIfMinute(std::span<std::string_view> argv)
{
	TickMinutes minutes = _settings_time.NowInTickMinutes();
	return ConConditionalCommon(argv, minutes.ClockMinute(), "the current minute (in game, assuming time is in minutes)", "if_minute");
}

static bool ConIfHourMinute(std::span<std::string_view> argv)
{
	TickMinutes minutes = _settings_time.NowInTickMinutes();
	return ConConditionalCommon(argv, minutes.ClockHHMM(), "the current hour and minute 0000 - 2359 (in game, assuming time is in minutes)", "if_hour_minute");
}

#ifdef _DEBUG
/******************
 *  debug commands
 ******************/

static void IConsoleDebugLibRegister()
{
	IConsole::CmdRegister("resettile",        ConResetTile);
	IConsole::AliasRegister("dbg_echo",       "echo %A; echo %B");
	IConsole::AliasRegister("dbg_echo2",      "echo %!");
}
#endif

/** Show the current framerate statistics. @copydoc IConsoleCmdProc */
static bool ConFramerate(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Show frame rate and game speed information.");
		return true;
	}

	ConPrintFramerate();
	return true;
}

/** Show the framerate statistics window. @copydoc IConsoleCmdProc */
static bool ConFramerateWindow(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Open the frame rate window.");
		return true;
	}

	if (_network_dedicated) {
		IConsolePrint(CC_ERROR, "Can not open frame rate window on a dedicated server.");
		return false;
	}

	ShowFramerateWindow();
	return true;
}

static bool ConFindNonRealisticBrakingSignal(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Find the next signal tile which prevents enabling of realistic braking");
		return true;
	}

	for (TileIndex t(0); t < Map::Size(); t++) {
		if (IsTileType(t, TileType::Railway) && GetRailTileType(t) == RailTileType::Signals) {
			uint signals = GetPresentSignals(t);
			if ((signals & 0x3) & ((signals & 0x3) - 1) || (signals & 0xC) & ((signals & 0xC) - 1)) {
				/* Signals in both directions */
				ScrollMainWindowToTile(t);
				SetRedErrorSquare(t);
				return true;
			}
			if (((signals & 0x3) && IsSignalTypeUnsuitableForRealisticBraking(GetSignalType(t, TRACK_LOWER))) ||
					((signals & 0xC) && IsSignalTypeUnsuitableForRealisticBraking(GetSignalType(t, TRACK_UPPER)))) {
				/* Banned signal types present */
				ScrollMainWindowToTile(t);
				SetRedErrorSquare(t);
				return true;
			}
		}
	}

	return true;
}

static bool ConFindMissingObject(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Find the next object tile where the spec is missing");
		return true;
	}

	extern TileIndex FindMissingObjectTile();
	TileIndex t = FindMissingObjectTile();
	if (t != INVALID_TILE) {
		ScrollMainWindowToTile(t);
		SetRedErrorSquare(t);
	}

	return true;
}

/** Dump information about some NewGRF types. @copydoc IConsoleCmdProc */
static bool ConDumpInfo(std::span<std::string_view> argv)
{
	if (argv.size() != 2) {
		IConsolePrint(CC_HELP, "Dump debugging information.");
		IConsolePrint(CC_HELP, "Usage: 'dump_info roadtypes|railtypes|cargotypes'.");
		IConsolePrint(CC_HELP, "  Show information about road/tram types, rail types or cargo types.");
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "roadtypes")) {
		ConDumpRoadTypes(argv);
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "railtypes")) {
		ConDumpRailTypes(argv);
		return true;
	}

	if (StrEqualsIgnoreCase(argv[1], "cargotypes")) {
		ConDumpCargoTypes(argv);
		return true;
	}

	return false;
}

void CcCreateTown(const CommandCost &result, TileIndex tile)
{
	if (result.Succeeded()) {
		auto town_id = result.GetResultData<TownID>();
		if (town_id.has_value()) {
			IConsolePrint(TextColour::Green, "Successfully created town '{}' at {:#x}(X: {}, Y: {})", Town::Get(*town_id)->name.c_str(), tile.base(), TileX(tile), TileY(tile));
		}
		return;
	}
	StringID error = result.GetErrorMessage();
	if (error == INVALID_STRING_ID) {
		IConsolePrint(CC_ERROR, "ERROR: Command execution failed");
	} else if (error == STR_ERROR_NAME_MUST_BE_UNIQUE || error == STR_ERROR_TOO_MANY_TOWNS) {
		IConsolePrint(CC_ERROR, "ERROR: Couldn't create a town: {}", GetString(error));
	} else {
		IConsolePrint(CC_ERROR, "ERROR: Couldn't place a town at {:#x}(X: {}, Y: {}): {}", tile.base(), TileX(tile), TileY(tile), GetString(error));
	}
	SetRedErrorSquare(tile);
}

static bool ConCreateTown(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "Create a town");
		IConsolePrint(CC_HELP, "Usage: create_town x y name");
		return true;
	}
	if (argv.size() != 4) return false;

	auto x = ParseInteger<uint32_t>(argv[1], 0);
	auto y = ParseInteger<uint32_t>(argv[2], 0);
	if (x.has_value() && y.has_value()) {
		if (*x >= Map::SizeX() || *y >= Map::SizeY()) {
			IConsolePrint(CC_ERROR, "Tile does not exist");
			return true;
		}

		TileIndex tile = TileXY(*x, *y);
		ScrollMainWindowToTile(tile);

		Command<Commands::FoundTown>::Post(CommandCallback::CreateTown, tile,
				TownSize::Medium, false, TownLayout::BetterRoads, false, 0, std::string(argv[3]));
		return true;
	}

	return false;
}

/** Read-only live order, compiled-cycle and vehicle prediction diagnostics. */
static bool ConPassengerServiceInspect(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "passenger_service_inspect <vehicle>|depots: read-only order/progress/prediction diagnostics");
		return true;
	}
	if (argv.size() != 2) return false;
	if (argv[1] == "depots") {
		for (const OrderList *list : OrderList::Iterate()) {
			const auto &orders = list->GetOrderVector();
			if (std::none_of(orders.begin(), orders.end(), [](const Order &order) { return order.IsType(OT_GOTO_DEPOT); })) continue;
			const Vehicle *first = list->GetFirstSharedVehicle();
			if (first == nullptr) continue;
			size_t passenger_vehicles = 0;
			for (const Vehicle *vehicle = first; vehicle != nullptr; vehicle = vehicle->NextShared()) {
				if (!IsPassengerServiceVehicle(vehicle)) continue;
				for (const Vehicle *part = vehicle; part != nullptr; part = part->Next()) {
					if (part->cargo_type < NUM_CARGO && part->cargo_cap > 0 && IsCargoInClass(part->cargo_type, CargoClass::Passengers)) { ++passenger_vehicles; break; }
				}
			}
			const auto *published = GetPassengerServiceDatabase().Get(list->index);
			auto live = PassengerPeriodicTimetable::Compile(orders);
			IConsolePrint(CC_DEFAULT, "Depot service {}: vehicle={}; type={}; passenger_vehicles={}; published={}; published_period={}; live_period={}",
					list->index, first->index, to_underlying(first->type), passenger_vehicles, published != nullptr,
					published == nullptr ? 0 : published->timetable.period, live.period);
			VehicleOrderID index = 0;
			for (const Order &order : orders) {
				IConsolePrint(CC_DEFAULT, "Depot audit order {}: type={}; destination={}; nonstop={}; travel={}/{}; wait={}/{}; pax_load={}; pax_unload={}; refit={}; dispatch={}",
						index++, GetOrderTypeName(order.GetType()), order.GetDestination().value, order.GetNonStopType(), order.GetTravelTime(), order.IsTravelTimetabled(),
						order.GetWaitTime(), order.IsWaitTimetabled(), to_underlying(order.GetCargoLoadType(CargoType{0})), to_underlying(order.GetCargoUnloadType(CargoType{0})),
						order.IsRefit(), order.GetDispatchScheduleIndex());
				if (order.IsType(OT_GOTO_DEPOT)) IConsolePrint(CC_DEFAULT, "Depot flags: regular={}; service_only={}; breakdown={}; action={}; traversal={}",
						order.GetDepotOrderType().Test(OrderDepotTypeFlag::PartOfOrders), order.GetDepotOrderType().Test(OrderDepotTypeFlag::Service),
						order.GetDepotOrderType().Test(OrderDepotTypeFlag::Breakdown), to_underlying(order.GetDepotActionType()), to_underlying(ClassifyPassengerDepot(order)));
			}
		}
		return true;
	}
	auto id = ParseInteger<uint32_t>(argv[1]);
	if (!id) return false;
	const Vehicle *vehicle = Vehicle::GetIfValid(VehicleID{*id});
	if (vehicle == nullptr || vehicle->orders == nullptr) return false;
	IConsolePrint(CC_DEFAULT, "Service {} vehicle {}: type={}; tile={}; current_type={}; real_order={}; implicit_order={}; timetable_order={}; elapsed={}; lateness={}; last_station={}",
			vehicle->orders->index, vehicle->index, to_underlying(vehicle->type), vehicle->tile.base(), GetOrderTypeName(vehicle->current_order.GetType()),
			vehicle->cur_real_order_index, vehicle->cur_implicit_order_index, vehicle->cur_timetable_order_index, vehicle->current_order_time, vehicle->lateness_counter, vehicle->last_station_visited);
	VehicleOrderID index = 0;
	for (const Order &order : vehicle->orders->GetOrderVector()) {
		IConsolePrint(CC_DEFAULT, "Order {}: type={}; destination={}; nonstop={}; travel={}/{}; wait={}/{}; load={}; unload={}; refit={}; leave={}; pax_load={}; dispatch={}",
				index++, GetOrderTypeName(order.GetType()), order.GetDestination().value, order.GetNonStopType(), order.GetTravelTime(), order.IsTravelTimetabled(),
				order.GetWaitTime(), order.IsWaitTimetabled(), to_underlying(order.GetLoadType()), to_underlying(order.GetUnloadType()), order.IsRefit(),
				order.GetLeaveType(), to_underlying(order.GetCargoLoadType(CargoType{0})), order.GetDispatchScheduleIndex());
	}
	size_t work = 1048576;
	PassengerPredictionReason reason{};
	auto state = GetPassengerRouteState(vehicle, &work, &reason);
	if (!state) {
		IConsolePrint(CC_DEFAULT, "Route state unavailable: reason={}", to_underlying(reason));
		return true;
	}
	for (auto timing : {PassengerTimingPolicy::Conservative, PassengerTimingPolicy::AssumeTimetable}) for (bool prefix : {false, true}) {
		size_t prediction_work = 65536;
		auto prediction = PredictPassengerVisits(*state, CargoType{0}, _state_ticks, _state_ticks + 4096, 4096, 4096, prediction_work, {}, prefix, timing);
		IConsolePrint(CC_DEFAULT, "Prediction timing={} prefix_only={}: status={}; stop={}; stopped_order={}; first_unknown_order={}; first_unknown_reason={}; cursor={}; certified_until={}; visits={}",
				to_underlying(timing), prefix, to_underlying(prediction.status), to_underlying(prediction.stop), prediction.stopped_order, prediction.uncertain_order,
				to_underlying(prediction.uncertain_reason), prediction.stopped_at.base(), prediction.complete_until.base(), prediction.visits.size());
	}
	return true;
}

/** Paired, simulation-thread measurements on the currently loaded map, without moving cargo. */
static bool ConPassengerServiceCaptureBenchmark(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "passenger_service_capture_benchmark <cargo> <origin> [OD count=100]: paired Trip-cache measurements, preprocessing cached on both sides");
		return true;
	}
	if (argv.size() < 3 || argv.size() > 4) return false;
	auto cargo = ParseInteger<uint32_t>(argv[1]), origin = ParseInteger<uint32_t>(argv[2]);
	auto count = argv.size() == 4 ? ParseInteger<uint32_t>(argv[3]) : std::optional<uint32_t>{100};
	if (!cargo || *cargo >= NUM_CARGO || !origin || *origin >= StationID::Invalid().base() || !Station::IsValidID(StationID{static_cast<uint16_t>(*origin)}) || !count || *count == 0 || *count > 100) return false;
	PassengerServiceCapture capture;
	PassengerServiceCapture prediction_disabled(PassengerServiceCapture::MAXIMUM_BYTES, 0);
	PassengerGraphPhaseTimes cold_phases{}, warm_phases{};
	uint64_t cold_us = 0, warm_us = 0;
	size_t builds = 0, discovery_hits = 0, service_hits = 0, service_requests = 0, work = 0, maximum_memory = 0, maximum_allocation = 0, maximum_visits = 0, mismatches = 0;
	struct PredictionObservation { size_t requests = 0, executions = 0, hits = 0, visits = 0, work = 0; uint64_t nanoseconds = 0; };
	std::map<std::tuple<VehicleID, CargoType, StateTicks>, PredictionObservation> observations;
	size_t cold_predictions = 0, warm_predictions = 0, prediction_hits = 0, prediction_requests = 0, prediction_work = 0;
	for (const Station *station : Station::Iterate()) {
		if (station->index.base() == *origin) continue;
		const PassengerServiceScope scope{StationID{static_cast<uint16_t>(*origin)}, station->index};
		auto limits = ActivePassengerServiceGraphLimits();
		PassengerServiceGraph a, b;
		if (builds % 2 == 0) {
			a = PassengerServiceGraph::Build(static_cast<CargoType>(*cargo), _state_ticks, limits, scope, &prediction_disabled);
			b = PassengerServiceGraph::Build(static_cast<CargoType>(*cargo), _state_ticks, limits, scope, &capture);
		} else {
			b = PassengerServiceGraph::Build(static_cast<CargoType>(*cargo), _state_ticks, limits, scope, &capture);
			a = PassengerServiceGraph::Build(static_cast<CargoType>(*cargo), _state_ticks, limits, scope, &prediction_disabled);
		}
		bool same = a.GetWork() == b.GetWork() && a.GetMemoryBound() == b.GetMemoryBound() && a.GetQueryStatus(scope.origin, scope.destination) == b.GetQueryStatus(scope.origin, scope.destination) &&
				a.GetServices().size() == b.GetServices().size() && a.GetTrips().size() == b.GetTrips().size();
		if (same) for (size_t i = 0; i < a.GetTrips().size(); ++i) {
			const auto &p = a.GetTrips()[i], &q = b.GetTrips()[i];
			same &= std::tuple(p.vehicle, p.service, p.capacity, p.occupants, p.current_order, p.implicit_order, p.timetable_order, p.elapsed, p.lateness, p.prediction_reason) ==
					std::tuple(q.vehicle, q.service, q.capacity, q.occupants, q.current_order, q.implicit_order, q.timetable_order, q.elapsed, q.lateness, q.prediction_reason);
			same &= p.prediction == q.prediction;
		}
		mismatches += !same;
		cold_predictions += a.GetDiagnostic().prediction_executions; warm_predictions += b.GetDiagnostic().prediction_executions;
		prediction_hits += b.GetDiagnostic().prediction_cache_hits; prediction_requests += b.GetDiagnostic().predicted; prediction_work += b.GetDiagnostic().prediction_work;
		for (const auto &trip : b.GetTrips()) if (trip.prediction_executed || trip.prediction_cache_hit) {
			auto &o = observations[std::tuple(trip.vehicle, b.GetCargo(), b.GetStart())];
			++o.requests; o.executions += trip.prediction_executed; o.hits += trip.prediction_cache_hit;
			o.visits += trip.prediction.visits.size(); o.work += trip.prediction_work; o.nanoseconds += trip.prediction_nanoseconds;
		}
		cold_us += a.GetDiagnostic().build_microseconds; warm_us += b.GetDiagnostic().build_microseconds;
		discovery_hits += b.GetDiagnostic().capture_discovery_hit; service_hits += b.GetDiagnostic().capture_service_hits; work += b.GetWork();
		service_requests += b.GetServices().size();
		maximum_memory = std::max(maximum_memory, b.GetMemoryBound()); maximum_allocation = std::max(maximum_allocation, b.GetDiagnostic().allocation_bytes);
		maximum_visits = std::max(maximum_visits, b.GetDiagnostic().visits);
		for (size_t i = 0; i < cold_phases.size(); ++i) { cold_phases[i] += a.GetDiagnostic().phase_microseconds[i]; warm_phases[i] += b.GetDiagnostic().phase_microseconds[i]; }
		if (++builds == *count) break;
	}
	IConsolePrint(CC_DEFAULT, "Capture benchmark: OD={}; uncached_us={}; captured_us={}; mismatches={}; discovery_hits={}; service_hits={}; service_requests={}; work={}; graph_bound={}; graph_estimate={}; capture_estimate={}; maximum_visits={}",
			builds, cold_us, warm_us, mismatches, discovery_hits, service_hits, service_requests, work, maximum_memory, maximum_allocation, capture.GetAllocationBytes(), maximum_visits);
	for (size_t i = 0; i < cold_phases.size(); ++i) IConsolePrint(CC_DEFAULT, "Capture phase {}: uncached_us={}; captured_us={}", i, cold_phases[i], warm_phases[i]);
	size_t repeated = 0;
	for (const auto &[key, o] : observations) {
		repeated += o.requests - 1;
		IConsolePrint(CC_DEFAULT, "Trip prediction vehicle={} cargo={} at={}: occurrences={}; executions={}; hits={}; visits={}; logical_work={}; predictor_ns={}",
				std::get<0>(key), std::get<1>(key), std::get<2>(key).base(), o.requests, o.executions, o.hits, o.visits, o.work, o.nanoseconds);
	}
	IConsolePrint(CC_DEFAULT, "Trip cache: disabled_executions={}; enabled_executions={}; requests={}; hits={}; hit_percent={:.2f}; repeated_vehicle_cargo_start={}; repeated_percent={:.2f}; logical_work={}; bytes={}",
			cold_predictions, warm_predictions, prediction_requests, prediction_hits, prediction_requests ? 100.0 * prediction_hits / prediction_requests : 0.0,
			repeated, prediction_requests ? 100.0 * repeated / prediction_requests : 0.0, prediction_work, capture.GetPredictionBytes());
	return true;
}

#ifdef WITH_PASSENGER_BENCHMARK
/** Test setup on an isolated no-NewGRF map, before clients connect. */
static bool ConPassengerPeriodicFixture(std::span<std::string_view> argv)
{
	if (argv.size() != 1 && (argv.size() != 2 || argv[1] != "estimated")) return false;
	if (_networking) for (const NetworkClientInfo *client : NetworkClientInfo::Iterate()) if (client->client_id != ClientID::Server) return false;
	Company *fixture_company = DoStartupNewCompany(DSNC_NONE);
	if (fixture_company == nullptr || Map::SizeX() < 64 || Map::SizeY() < 64) return false;
	{
		AutoRestoreBackup company{_current_company, fixture_company->index};
		RoadType road{0};
		TileIndex start = INVALID_TILE;
		for (uint y = 20; y + 20 < Map::SizeY() && start == INVALID_TILE; ++y) for (uint x = 20; x + 20 < Map::SizeX() && start == INVALID_TILE; ++x) {
			bool clear = true;
			for (uint dx = 0; dx <= 10 && clear; ++dx) for (uint dy = 0; dy < 2; ++dy) {
				TileIndex tile = TileXY(x + dx, y + dy);
				if (!IsTileType(tile, TileType::Clear) || GetTileSlope(tile) != SLOPE_FLAT) { clear = false; break; }
			}
			if (clear) start = TileXY(x, y);
		}
		if (start == INVALID_TILE) { IConsolePrint(CC_ERROR, "Periodic fixture: no flat construction strip"); return false; }
		uint roads = 0, stops = 0;
		for (uint dx = 0; dx <= 10; ++dx) {
			RoadBits bits = ROAD_X;
			if (dx == 0 || dx == 2 || dx == 8) bits.Set(RoadBit::SE);
			roads += CmdBuildRoad({DoCommandFlag::Execute}, TileXY(TileX(start) + dx, TileY(start)), bits, road, DRD_NONE, TownID::Invalid(), BuildRoadFlags::None).Succeeded();
		}
		bool depot = CmdBuildRoadDepot({DoCommandFlag::Execute}, TileXY(TileX(start), TileY(start) + 1), road, DiagDirection::NW).Succeeded();
		for (uint dx : {2, 8}) stops += CmdBuildRoadStop({DoCommandFlag::Execute}, TileXY(TileX(start) + dx, TileY(start) + 1), 1, 1, RoadStopType::Bus, false,
				DiagDirection::NW, road, RoadStopClassID{0}, 0, NEW_STATION, false).Succeeded();
		IConsolePrint(CC_DEFAULT, "Periodic test infrastructure: roads={}; depot={}; stops={}", roads, depot, stops);
		if (roads != 11 || !depot || stops != 2) return false;
	}
	/* Use a real base-set bus, existing road depot and two owned bus stations.
	 * The regression map otherwise contains mostly freight vehicles. */
	bool built_bus = false;
	uint depots = 0, pax_engines = 0, buildable_engines = 0;
	for (TileIndex tile{0}; tile < Map::Size() && !built_bus; ++tile) {
		if (!IsTileType(tile, TileType::Road) || !IsRoadDepotTile(tile) || !Company::IsValidID(GetTileOwner(tile))) continue;
		CompanyID owner = GetTileOwner(tile);
		++depots;
		std::vector<std::pair<uint, StationID>> stops;
		for (const Station *station : Station::Iterate()) if (station->owner == owner && station->bus_stops != nullptr) {
			uint distance = abs(int(TileX(tile)) - int(TileX(station->bus_stops->xy))) + abs(int(TileY(tile)) - int(TileY(station->bus_stops->xy)));
			stops.emplace_back(distance, station->index);
		}
		if (stops.size() < 2) continue;
		std::sort(stops.begin(), stops.end());
		AutoRestoreBackup company{_current_company, owner};
		for (const Engine *engine : Engine::Iterate()) {
			CargoType cargo = engine->GetDefaultCargoType();
			if (engine->type != VehicleType::Road || cargo >= NUM_CARGO || !IsCargoInClass(cargo, CargoClass::Passengers)) continue;
			++pax_engines;
			if (!IsEngineBuildable(engine->index, VehicleType::Road, owner)) continue;
			++buildable_engines;
			auto result = CmdBuildVehicle({DoCommandFlag::Execute}, tile, engine->index, false, cargo, ClientID::Invalid);
			auto vehicle = result.GetResultData<VehicleID>();
			if (result.Failed() || !vehicle) { if (buildable_engines < 5) IConsolePrint(CC_DEFAULT, "Periodic bus build: engine={}; failed={}; result={}", engine->index, result.Failed(), vehicle.has_value()); continue; }
			for (uint i = 0; i < 2; ++i) {
				Order order; order.MakeGoToStation(stops[i].second);
				order.SetStopLocation(OrderStopLocation::FarEnd);
				order.SetNonStopType(ONSF_NO_STOP_AT_INTERMEDIATE_STATIONS);
				auto inserted = CmdInsertOrder({DoCommandFlag::Execute}, InsertOrderCmdData{*vehicle, static_cast<VehicleOrderID>(i), order});
				IConsolePrint(CC_DEFAULT, "Periodic bus order: inserted={}; orders={}; capacity={}; primary={}", inserted.Succeeded(), Vehicle::Get(*vehicle)->GetNumOrders(), Vehicle::Get(*vehicle)->cargo_cap, Vehicle::Get(*vehicle)->IsPrimaryVehicle());
			}
			built_bus = true; break;
		}
	}
	IConsolePrint(CC_DEFAULT, "Periodic bus setup: depots={}; pax_engines={}; buildable_engines={}; built={}", depots, pax_engines, buildable_engines, built_bus);
	std::set<OrderListID> prepared;
	uint services = 0, passengers = 0;
	for (Vehicle *v : Vehicle::Iterate()) {
		if (!IsPassengerServiceVehicle(v) || v->orders == nullptr || prepared.contains(v->orders->index) || v->vehstatus.Test(VehState::Crashed)) continue;
		CargoType cargo = INVALID_CARGO;
		for (const Vehicle *part = v; part != nullptr; part = part->Next()) if (part->cargo_cap && part->cargo_type < NUM_CARGO && IsCargoInClass(part->cargo_type, CargoClass::Passengers)) { cargo = part->cargo_type; break; }
		if (cargo == INVALID_CARGO || !Company::IsValidID(v->owner)) continue;
		uint stations = 0;
		for (const Order *order : v->Orders()) stations += order->IsType(OT_GOTO_STATION);
		if (stations < 2) continue;
		prepared.insert(v->orders->index);
		AutoRestoreBackup company{_current_company, v->owner};
		for (VehicleOrderID i = v->GetNumOrders(); i > 0; --i) {
			const Order *order = v->GetOrder(i - 1);
			if (!order->IsType(OT_GOTO_STATION) && !order->IsType(OT_GOTO_WAYPOINT)) CmdDeleteOrder({DoCommandFlag::Execute}, v->index, i - 1);
		}
		std::vector<StationID> stops;
		for (VehicleOrderID i = 0; i < v->GetNumOrders(); ++i) {
			CmdChangeTimetable({DoCommandFlag::Execute}, v->index, i, MTF_TRAVEL_TIME, 100, {});
			if (v->GetOrder(i)->IsType(OT_GOTO_STATION)) {
				CmdChangeTimetable({DoCommandFlag::Execute}, v->index, i, MTF_WAIT_TIME, 25, {});
				stops.push_back(v->GetOrder(i)->GetDestination().ToStationID());
			}
		}
		if (stops.size() < 2 || stops.front() == stops.back()) continue;
		Station *origin = Station::GetIfValid(stops.front());
		if (origin == nullptr) continue;
		for (StationID stop : stops) if (Station *station = Station::GetIfValid(stop)) station->always_accepted.Set(cargo);
		auto *packet = CargoPacket::Create(50, 0, origin->index, origin->xy, Money{0});
		if (!packet->SetPassengerDestination(cargo, stops.back())) { delete packet; continue; }
		origin->goods[cargo].CreateData().cargo.Append(packet, StationID::Invalid());
		if (v->vehstatus.Test(VehState::Stopped)) CmdStartStopVehicle({DoCommandFlag::Execute}, v->index, false);
		if (argv.size() == 2) {
			/* Dispatch enabled without assigned slots keeps the phase uncertified;
			 * real orders/loaders still run normally. Controlled loopback only. */
			v->vehicle_flags.Set(VehicleFlag::ScheduledDispatch); v->current_order.Free();
		}
		++services; passengers += 50;
	}
	IConsolePrint(CC_DEFAULT, "Periodic test fixture: services={}; injected_passengers={}", services, passengers);
	return true;
}
#endif

static bool ConPassengerPeriodicCompare(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "passenger_periodic_compare <cargo> <origin> <destination> | sample <count 1..256>: read-only paired planners at the current StateTicks; explicit diagnostic only");
		return true;
	}
	auto parse = [](uint32_t *out, std::string_view arg) { auto value = ParseInteger<uint32_t>(arg); if (!value) return false; *out = *value; return true; };
	static constexpr std::array reasons{"Found", "Invalid", "OriginMissing", "DestinationMissing", "NoAlighting", "Unreachable", "NoCandidate", "UnknownPhase", "Evaluation", "Candidates", "Labels", "Work", "Memory", "Transfers"};
	static constexpr std::array phases{"Known", "NoTimetable", "VehicleState", "OrderProgress", "Facilities", "Work", "Unbunching", "DispatchCompetition", "DispatchUnsupported", "Overflow", "ElapsedTravel", "AwaitCapture"};
	static constexpr std::array compilations{"None", "Control", "Refit", "Travel", "Wait", "Overflow", "ZeroPeriod", "TooFewStops"};
	static constexpr std::array publications{"Published", "TimingDirty", "Dirty", "SweepPending", "Unpublished"};
	using OD = std::tuple<CargoType, StationID, StationID>;
	std::set<OD> queries;
	if (argv.size() == 3 && argv[1] == "sample") {
		uint32_t count;
		if (!parse(&count, argv[2]) || count == 0 || count > 256) return false;
		size_t work = 0;
		for (const Station *station : Station::Iterate()) {
			for (CargoType cargo : EnumRange(NUM_CARGO)) {
				if (!IsCargoInClass(cargo, CargoClass::Passengers)) continue;
				const auto &list = station->goods[cargo].ConstCargoList();
				for (StationCargoList::ConstIterator it(list.Packets()->begin()); it != list.Packets()->end(); ++it) {
					if (++work > 1048576) break;
					StationID destination = (*it)->GetPassengerDestination();
					if (Station::IsValidID(destination) && destination != station->index) queries.emplace(cargo, station->index, destination);
					if (queries.size() >= count) break;
				}
				if (queries.size() >= count || work > 1048576) break;
			}
			if (queries.size() >= count || work > 1048576) break;
		}
	} else if (argv.size() == 4) {
		uint32_t cargo, origin, destination;
		if (!parse(&cargo, argv[1]) || !parse(&origin, argv[2]) || !parse(&destination, argv[3]) ||
				cargo >= NUM_CARGO || origin >= StationID::Invalid().base() || destination >= StationID::Invalid().base()) return false;
		queries.emplace(static_cast<CargoType>(cargo), StationID{static_cast<uint16_t>(origin)}, StationID{static_cast<uint16_t>(destination)});
	} else return false;
	PassengerJourneyLimits limits; limits.work = 65536; limits.labels = 8192; limits.memory_bytes = 8 * 1024 * 1024;
	PassengerJourneyEvaluation evaluation; evaluation.minimum_transfer = evaluation.transfer_penalty = _settings_game.linkgraph.passenger_transfer_penalty;
	const auto &db = GetPassengerServiceDatabase();
	size_t old_only = 0, new_only = 0, both = 0, neither = 0, provisional = 0;
	static constexpr std::array state_names{"Unavailable", "Certified", "Provisional", "Deferred", "NoRoute"};
	static_assert(state_names.size() == static_cast<size_t>(PassengerPeriodicPlan::State::End));
	for (const auto &[cargo, origin, destination] : queries) {
		auto paired = ComparePassengerPlanners(db, cargo, origin, destination, _state_ticks, limits, evaluation);
		bool old_found = paired.legacy_found, new_found = paired.periodic.state == PassengerPeriodicPlan::State::Certified;
		provisional += paired.periodic.state == PassengerPeriodicPlan::State::Provisional;
		old_only += old_found && !new_found; new_only += new_found && !old_found; both += old_found && new_found; neither += !old_found && !new_found;
		IConsolePrint(CC_DEFAULT, "Periodic paired OD: cargo={}; origin={}; destination={}; tick={}; old_found={}; new_found={}; old_arrival={}; new_arrival={}; old_cost={}; new_cost={}; new_reason={}; deferred={}; labels={}; candidates={}; new_work={}; new_memory={}; old_stop={}; old_status={}; old_graph_work={}; old_search_work={}; horizon={}",
				cargo, origin, destination, _state_ticks.base(), old_found, new_found, paired.legacy_arrival.base(), paired.periodic.arrival.base(),
				paired.legacy_cost, paired.periodic.cost, reasons[static_cast<size_t>(paired.periodic.reason)], paired.periodic.deferred, paired.periodic.labels,
				paired.periodic.candidates, paired.periodic.work, paired.periodic.memory, to_underlying(paired.legacy_stop), to_underlying(paired.legacy_status),
				paired.legacy_graph_work, paired.legacy_search_work, paired.horizon);
		IConsolePrint(CC_DEFAULT, "Periodic paired availability: available={}; state={}; new_found_means_certified=true",
			paired.periodic.ride.has_value(), state_names[static_cast<size_t>(paired.periodic.state)]);
		for (size_t i = 0; i < paired.periodic.observations.size(); ++i) if (paired.periodic.observations[i]) IConsolePrint(CC_DEFAULT, "Periodic paired observation: reason={}", reasons[i]);
		auto print_route = [&](const char *backend, const auto &route) {
			for (const auto &leg : route) {
				const auto *service = db.Get(leg.service);
				IConsolePrint(CC_DEFAULT, "Periodic paired leg: backend={}; service={}; vehicle={}; board={}/{}; alight={}/{}; departure={}; arrival={}; published={}; generation={}; period={}",
						backend, leg.service, leg.vehicle, leg.boarding, leg.boarding_order, leg.alighting, leg.alighting_order, leg.departure.base(), leg.arrival.base(),
						service != nullptr, service == nullptr ? 0 : service->generation, service == nullptr ? 0 : service->timetable.period);
				const OrderList *list = OrderList::GetIfValid(leg.service);
				if (list == nullptr) continue;
				PassengerPeriodicTimetable::Failure failure;
				auto table = PassengerPeriodicTimetable::Compile(list->GetOrderVector(), &failure);
				PassengerPeriodicService live; live.timetable = std::move(table);
				IConsolePrint(CC_DEFAULT, "Periodic paired publication: service={}; live_compile_reason={}; publication_state={}", leg.service, compilations[static_cast<size_t>(failure)], publications[static_cast<size_t>(db.GetPublication(leg.service))]);
				for (const Vehicle *v = list->GetFirstSharedVehicle(); v != nullptr; v = v->NextShared()) {
					bool known = service != nullptr && std::any_of(service->vehicles.begin(), service->vehicles.end(), [&](const auto &phase) { return phase.id == v->index && phase.phase_known; });
					IConsolePrint(CC_DEFAULT, "Periodic paired phase: service={}; vehicle={}; known={}; live_unknown_reason={}; real_order={}; implicit_order={}; timetable_order={}; elapsed={}; lateness={}; dispatch={}",
							leg.service, v->index, known, phases[known ? 0 : static_cast<size_t>(db.ExplainPhase(v, service == nullptr ? live : *service))], v->cur_real_order_index,
							v->cur_implicit_order_index, v->cur_timetable_order_index, v->current_order_time, v->lateness_counter, v->vehicle_flags.Test(VehicleFlag::ScheduledDispatch));
				}
			}
		};
		print_route("snapshot", paired.legacy_route); print_route("periodic", paired.periodic.route);
	}
	IConsolePrint(CC_DEFAULT, "Periodic paired totals (unique OD calls, same live state, no simulation advanced; found means certified): calls={}; old_only={}; new_only={}; both={}; neither={}; provisional={}", queries.size(), old_only, new_only, both, neither, provisional);
	return true;
}
#include "C:/Users/bebe/.codex/worktrees/8621/OpenTTD-patches/build-wpr-f7c44f0d/save-integrity/wpr_gate.h"
static bool ConPassengerJourneyStats(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "passenger_journey_stats [total|tick|inventory|hyperpath_memory|reset|cache_on|cache_off|departures_on|departures_off|scratch_on|scratch_off|fallback_cache_on|fallback_cache_off|fallback_validate_on|fallback_validate_off|hyperpath_filter_on|hyperpath_filter_off|hyperpath_filter_alternate]: local diagnostics and derived cache preferences");
		return true;
	}
	if (argv.size() > 2) return false;
	auto operation = argv.size() == 1 ? std::string_view("total") : argv[1];
    if (operation == "wpr_begin") {
        if (!PassengerWpr::Gate("wpr-ready.txt", "wpr-go.txt")) { _exit_game = true; return false; }
        return true;
    }
	if (operation == "scratch_on" || operation == "scratch_off") {
		GetPassengerServiceDatabase().SetTimedSearchScratchEnabled(operation == "scratch_on");
		IConsolePrint(CC_DEFAULT, "Timed search scratch: {}; logical query work unchanged", operation == "scratch_on" ? "enabled" : "disabled");
		return true;
	}
	if (operation == "departures_on" || operation == "departures_off") {
		GetPassengerServiceDatabase().SetDepartureIndexEnabled(operation == "departures_on");
		IConsolePrint(CC_DEFAULT, "Periodic departure index: {}; logical query work unchanged", operation == "departures_on" ? "enabled" : "disabled");
		return true;
	}
	if (operation == "fallback_cache_on" || operation == "fallback_cache_off") {
		SetPassengerOdFallbackCacheEnabled(operation == "fallback_cache_on");
		IConsolePrint(CC_DEFAULT, "OD fallback residency: {}; logical work unchanged", operation == "fallback_cache_on" ? "enabled" : "disabled");
		return true;
	}
	if (operation == "hyperpath_filter_on" || operation == "hyperpath_filter_off" || operation == "hyperpath_filter_alternate") {
		using Mode = PassengerServiceDatabase::HyperpathFilterMode;
		const Mode mode = operation == "hyperpath_filter_on" ? Mode::On : operation == "hyperpath_filter_off" ? Mode::Off : Mode::Alternate;
		GetPassengerServiceDatabase().SetHyperpathBoardingFilterMode(mode);
		IConsolePrint(CC_DEFAULT, "Hyperpath boarding destination filter: {}; boarding decisions unchanged",
				mode == Mode::On ? "enabled" : mode == Mode::Off ? "disabled" : "alternating per loading context");
		return true;
	}
	if (operation == "fallback_validate_on" || operation == "fallback_validate_off") {
		SetPassengerOdFallbackBindingValidation(operation == "fallback_validate_on");
		IConsolePrint(CC_DEFAULT, "OD fallback physical binding validation: {}", operation == "fallback_validate_on" ? "enabled" : "disabled");
		return true;
	}
	if (operation == "cache_on" || operation == "cache_off") {
		GetPassengerServiceDatabase().SetPolicyCacheEnabled(operation == "cache_on");
		IConsolePrint(CC_DEFAULT, "Periodic policy residency: {}; logical query work unchanged", operation == "cache_on" ? "enabled" : "disabled");
		return true;
	}
	if (operation == "hyperpath_memory") {
		for (CargoType cargo : EnumRange(NUM_CARGO)) if (IsCargoInClass(cargo, CargoClass::Passengers)) for (bool retained : {false, true}) {
			auto m = GetPassengerServiceDatabase().InspectPrecomputedMemory(cargo, retained);
			IConsolePrint(CC_DEFAULT, "Hyperpath memory: cargo={}; retained={}; reported={}; graph={}; labels={}; indices={}; policy_headers={}; candidate_arrays={}; local={}; differences={}; additions={}; maximum_additions={}; multi_addition_differences={}; unexpected_removals={}; overlay_bytes={}",
					cargo, retained, m.reported, m.graph, m.labels, m.indices, m.policy_headers, m.candidate_arrays, m.local, m.differences, m.additions, m.maximum_additions, m.multi_addition_differences, m.unexpected_removals, m.overlay_bytes);
		}
		return true;
	}
	if (operation == "save_integrity") { SaveIntegrity::Dump(_sl_xv_feature_versions[XSLFI_PASSENGER_JOURNEY_ROUTING], _state_ticks.base()); return true; }

    if (operation == "wait_background_ready") {
        if (GetPassengerServiceDatabase().GetLoadState() != PassengerServiceDatabase::LoadState::Ready) {
            IConsolePrint(CC_ERROR, "Background wait requires completed passenger save replay.");
            return false;
        }
        const int64_t background_tick = _state_ticks.base();
        const auto background_started = std::chrono::steady_clock::now();
        uint32_t initial = 0, total = 0;
        for (const LinkGraphJob *job : LinkGraphJob::Iterate()) { ++total; initial += !job->IsJobCompleted(); }
        bool complete = initial == 0;
        while (!complete) {
            complete = true;
            for (const LinkGraphJob *job : LinkGraphJob::Iterate()) complete &= job->IsJobCompleted();
            if (complete || std::chrono::steady_clock::now() - background_started > std::chrono::seconds(600)) break;
            CSleep(10);
        }
        IConsolePrint(CC_DEFAULT, "Background jobs ready: completed={}; initial={}; total={}; elapsed_us={}; tick_before={}; tick_after={}",
            complete, initial, total, std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - background_started).count(),
            background_tick, _state_ticks.base());
        return complete && background_tick == _state_ticks.base();
    }

    if (operation == "fixture_estimated") {
        /* Synthetic MP fixture only; never used for the real-map comparison. */
        for (OrderList *list : OrderList::Iterate()) {
            for (VehicleOrderID i = 0; i < list->GetNumOrders(); ++i) {
                Order *order = list->GetOrderAt(i);
                if (order->GetTravelTime() == 0) order->SetTravelTime(128);
                if (order->GetWaitTime() == 0) order->SetWaitTime(32);
                order->SetTravelTimetabled(false); order->SetWaitTimetabled(false);
            }
            list->RecalculateTimetableDuration();
        }
        GetPassengerServiceDatabase().Reset();
        InvalidatePassengerServiceDatabase();
        return true;
    }
    if (operation == "fixture_estimated_od") {
        uint64_t assigned = 0;
        auto &db = GetPassengerServiceDatabase();
        for (Station *station : Station::Iterate()) for (CargoType cargo : EnumRange(NUM_CARGO)) {
            if (!IsCargoInClass(cargo, CargoClass::Passengers) || station->goods[cargo].data == nullptr) continue;
            StationID target = StationID::Invalid();
            for (auto span : db.PrecomputedReachableDestinations(cargo, station->index)) for (auto destination : span) {
                if (destination != station->index && Station::IsValidID(destination)) { target = destination; break; }
            }
            if (target == StationID::Invalid()) continue;
            auto &list = station->goods[cargo].data->cargo;
            for (const auto &[via, packets] : *list.Packets()) for (CargoPacket *packet : packets) {
                if (packet->SetPassengerDestination(cargo, target)) assigned += packet->Count();
            }
            list.ClearWaitingIndex(); list.RebuildWaitingIndex();
        }
        IConsolePrint(CC_DEFAULT, "Estimated MP fixture: assigned_units={}", assigned);
        return assigned > 0;
    }
    if (operation == "quality_probe") {
        auto &db = GetPassengerServiceDatabase();
        for (uint16_t id : {302, 300, 160, 524, 525}) {
            const auto *s = db.Get(OrderListID{id});
            if (s == nullptr) { IConsolePrint(CC_DEFAULT, "Quality service: id={}; absent=true", id); continue; }
            IConsolePrint(CC_DEFAULT, "Quality service: id={}; certainty={}; period={}; estimate={}; stops={}; fleet={}; incarnation={}; generation={}",
                id, to_underlying(s->timetable.GetCertainty()), s->timetable.period, s->timetable.estimated_period,
                s->timetable.stops.size(), s->vehicles.size(), s->incarnation, s->generation);
            for (const auto &stop : s->timetable.stops) IConsolePrint(CC_DEFAULT,
                "Quality occurrence: id={}; station={}; order={}; arrival={}; departure={}; board={}; alight={}; forced={}; continues={}; quality={}",
                id, stop.station, stop.order, stop.arrival, stop.departure, stop.board, stop.alight, stop.forced, stop.continues, stop.travel_quality);
        }
        for (auto [origin, destination] : {std::pair{3222, 400}, std::pair{3221, 400}, std::pair{971, 916}, std::pair{387, 916}, std::pair{385, 916}, std::pair{3393, 3394}}) {
            StationID station{uint16_t(origin)}; OrderListID previous = OrderListID::Invalid();
            for (int leg = 0; leg < 16 && station != StationID{uint16_t(destination)}; ++leg) {
                auto p = db.PlanPrecomputed(CargoType{0}, station, StationID{uint16_t(destination)}, _state_ticks, previous, UINT32_MAX);
                if (!p.ride) { IConsolePrint(CC_DEFAULT, "Quality plan: origin={}; destination={}; station={}; leg={}; state={}; no_ride=true", origin, destination, station, leg, to_underlying(p.state)); break; }
                IConsolePrint(CC_DEFAULT, "Quality plan: origin={}; destination={}; station={}; leg={}; service={}; board_order={}; alight={}; alight_order={}; estimated={}; cost={}; riding={}; waiting={}; first_wait={}; transfers={}",
                    origin, destination, station, leg, p.ride->service, p.ride->boarding_order, p.ride->alighting, p.ride->alighting_order,
                    p.estimated_service, p.cost, p.riding, p.waiting, p.ride->estimated_wait, p.transfers);
                station = p.ride->alighting; previous = p.ride->service;
            }
        }
        return true;
    }
    if (operation == "partial_precomputed") {
        auto &db = GetPassengerServiceDatabase();
        if (db.GetLoadState() != PassengerServiceDatabase::LoadState::Ready) {
            IConsolePrint(CC_ERROR, "Partial build probe requires completed passenger save replay.");
            return false;
        }
        db.TickPrecomputed(64 * 1024 * 1024);
        return true;
    }
    if (operation == "fixture_timetable") {
        for (OrderList *list : OrderList::Iterate()) {
            for (VehicleOrderID i = 0; i < list->GetNumOrders(); ++i) {
                Order *order = list->GetOrderAt(i);
                order->SetTravelTime(128); order->SetTravelTimetabled(true);
                order->SetWaitTime(32); order->SetWaitTimetabled(true);
            }
            list->RecalculateTimetableDuration();
        }
        InvalidatePassengerServiceDatabase();
        auto &db = GetPassengerServiceDatabase();
        for (uint i = 0; i < 10000 && !db.PreparePrecomputed(); ++i) {}
        return db.PrecomputedFinished();
    }
    if (operation == "build_precomputed") {
        auto &db = GetPassengerServiceDatabase();
        if (db.GetLoadState() != PassengerServiceDatabase::LoadState::Ready) {
            IConsolePrint(CC_ERROR, "Warm build probe requires completed passenger save replay.");
            return false;
        }
        bool ready = false;
        const auto started = std::chrono::steady_clock::now();
        while (!db.PreparePrecomputed()) {}
        for (int i = 0; i < 4096; ++i) {
            db.TickPrecomputed(16 * 1024 * 1024);
            if (db.HasRejectedPrecomputedMemory()) break;
            ready = true;
            for (CargoType cargo : EnumRange(NUM_CARGO)) if (IsCargoInClass(cargo, CargoClass::Passengers)) {
                const auto p = db.GetPrecomputedDiagnostic(cargo);
                if (p.destinations != p.stations) ready = false;
            }
            if (ready) break;
        }
        IConsolePrint(CC_DEFAULT, "Precomputed warm: ready={}; elapsed_us={}", ready,
            std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - started).count());
        return ready;
    }
	if (operation == "inventory") {

        uint64_t company_deliveries = 0;
        for (const Company *company : Company::Iterate()) for (CargoType cargo : EnumRange(NUM_CARGO)) {
            if (IsCargoInClass(cargo, CargoClass::Passengers)) company_deliveries += company->cur_economy.delivered_cargo[cargo];
        }
        IConsolePrint(CC_DEFAULT, "All passenger company deliveries: current_economy_delivered={}", company_deliveries);
		/* Explicit read-only census. Reserved station cargo is held in vehicle
		 * lists, so count each packet there exactly once for the global rates. */
		std::array<uint64_t, 3> people{}, packets{}, known{};
		std::array<uint64_t, 3> waiting_modes{};
		uint64_t available = 0, reserved = 0, deferred = 0, schedule_people = 0, schedule_packets = 0, schedule_waiting = 0;
		uint64_t known_waiting = 0, aged_waiting = 0, long_intent_waiting = 0;
		size_t work = 0;
		bool complete = true;
		auto inspect_waiting = [&](const CargoPacket *packet, uint count) {
			if (packet->GetPassengerDestination() == StationID::Invalid()) return;
			known_waiting += count;
			if (packet->GetPeriodsInTransit() >= 256) aged_waiting += count;
			if (packet->GetPassengerRoutingMode() == PassengerRoutingMode::Journey && IsPassengerScheduleIntentAged(packet->GetPassengerJourney(), _state_ticks, 4096)) long_intent_waiting += count;
		};
		auto inspect = [&](const CargoPacket *packet) {
			if (++work > 16777216) { complete = false; return false; }
			size_t mode = to_underlying(packet->GetPassengerRoutingMode());
			people[mode] += packet->Count();
			++packets[mode];
			if (packet->GetPassengerDestination() != StationID::Invalid()) known[mode] += packet->Count();
			if (packet->IsPassengerJourneyDeferred()) deferred += packet->Count();
			if (packet->GetPassengerRoutingMode() == PassengerRoutingMode::Journey && IsEstimatedPassengerRide(packet->GetPassengerJourney().kind)) { schedule_people += packet->Count(); ++schedule_packets; }
			return true;
		};
		for (const Station *station : Station::Iterate()) {
			if (++work > 16777216) { complete = false; break; }
			for (CargoType cargo{}; cargo < NUM_CARGO && complete; ++cargo) {
				if (!IsCargoInClass(cargo, CargoClass::Passengers)) continue;
				const auto &list = station->goods[cargo].ConstCargoList();
				available += list.AvailableCount();
				reserved += list.ReservedCount();
				const auto available_modes = CountPassengerRoutingModes(list);
				const auto reserved_modes = CountReservedPassengerRoutingModes(*station, cargo);
				for (size_t mode = 0; mode < waiting_modes.size(); ++mode) waiting_modes[mode] += available_modes[mode] + reserved_modes[mode];
				for (StationCargoList::ConstIterator it(list.Packets()->begin()); it != list.Packets()->end(); ++it) {
					inspect_waiting(*it, (*it)->Count());
					if ((*it)->GetPassengerRoutingMode() == PassengerRoutingMode::Journey && IsEstimatedPassengerRide((*it)->GetPassengerJourney().kind)) schedule_waiting += (*it)->Count();
					if (!inspect(*it)) break;
				}
			}
			if (!complete) break;
		}
		if (complete) for (const Vehicle *vehicle : Vehicle::Iterate()) {
			if (++work > 16777216) { complete = false; break; }
			if (vehicle->cargo_type >= NUM_CARGO || !IsCargoInClass(vehicle->cargo_type, CargoClass::Passengers)) continue;
			for (const CargoPacket *packet : *vehicle->cargo.Packets()) if (!inspect(packet)) break;
			uint skip = vehicle->cargo.TotalCount() - vehicle->cargo.ReservedCount();
			for (const CargoPacket *packet : *vehicle->cargo.Packets()) {
				uint n = std::min<uint>(skip, packet->Count()); skip -= n;
				inspect_waiting(packet, packet->Count() - n);
				if (packet->GetPassengerRoutingMode() == PassengerRoutingMode::Journey && IsEstimatedPassengerRide(packet->GetPassengerJourney().kind)) schedule_waiting += packet->Count() - n;
			}
			if (!complete) break;
		}
		IConsolePrint(CC_DEFAULT, "Passenger inventory: {}; waiting={} people (available={}, reserved={}); deferred={} people; state_ticks={}; scaled_ticks={}",
				complete ? "complete" : "truncated", available + reserved, available, reserved, deferred, _state_ticks.base(), _scaled_tick_counter);
		static constexpr std::array modes{"Legacy", "Journey", "Fallback"};
		for (size_t mode = 0; mode < modes.size(); ++mode) IConsolePrint(CC_DEFAULT, "Inventory {}: {} people/{} packets; known_OD={} people", modes[mode], people[mode], packets[mode], known[mode]);
		uint64_t timed_waiting = waiting_modes[1] > schedule_waiting ? waiting_modes[1] - schedule_waiting : 0;
		IConsolePrint(CC_DEFAULT, "Waiting routing: timed={}; schedule={}; CargoDist_or_deferred={}; OD_fallback_or_waiting={} people", timed_waiting, schedule_waiting, waiting_modes[0], waiting_modes[2]);
		IConsolePrint(CC_DEFAULT, "Schedule inventory: people={}; packets={}; waiting={}; timed_waiting={} people", schedule_people, schedule_packets, schedule_waiting, timed_waiting);
		IConsolePrint(CC_DEFAULT, "Waiting age sample: known_OD_waiting={}; transit_age_ge_256={}; schedule_intent_age_ge_4096={} people (transit age includes travel; Schedule-aware only; intent age resets on replan; Timed waiting age unavailable)", known_waiting, aged_waiting, long_intent_waiting);
		return true;
	}
	if (operation == "reset") { ResetPassengerJourneyDiagnostic(); return true; }
	if (operation != "total" && operation != "tick") return false;
	const auto stats = operation == "tick" ? GetPassengerJourneyTickDiagnostic() : GetPassengerJourneyTotalDiagnostic();
	static constexpr std::array graph_reasons{"None", "Work", "Memory", "Services", "Trips", "TotalVisits", "Index", "Opaque"};
	static constexpr std::array prediction_stops{"None", "Work", "Memory", "Visits", "Steps", "Timing", "Conditional", "Refit", "Implicit", "Unsupported", "Dispatch", "Facilities", "VehicleState", "OrderProgress"};
	static constexpr std::array graph_stages{"Discovery", "Structure", "Orders", "Schedules", "Pattern", "Trips", "Prediction", "Indices"};
	static_assert(graph_reasons.size() == static_cast<size_t>(PassengerGraphFailure::End));
	static_assert(prediction_stops.size() == static_cast<size_t>(PassengerPredictionStop::End));
	IConsolePrint(CC_DEFAULT, "Graph coverage: complete={}; eligible_services={}; selected_services={}; selected_trips={}; largest_block_services={}; admitted_visits={}; max_unpredicted_ticks={}",
			stats.complete_graphs, stats.eligible_services, stats.selected_services, stats.selected_trips, stats.largest_block_services, stats.admitted_visits, stats.maximum_unpredicted_ticks);
	for (size_t i = 0; i < graph_reasons.size(); ++i) IConsolePrint(CC_DEFAULT, "Graph failure {}: {} builds", graph_reasons[i], stats.graph_failures[i]);
	for (size_t i = 0; i < prediction_stops.size(); ++i) IConsolePrint(CC_DEFAULT, "Trip stop {}: {} predictions", prediction_stops[i], stats.prediction_stops[i]);
	const auto &first = stats.first_graph_failure;
	IConsolePrint(CC_DEFAULT, "First graph failure: reason={}; stage={}; work={}; memory={}; trips={}; visits={}",
			graph_reasons[static_cast<size_t>(first.reason)], graph_stages[static_cast<size_t>(first.stage)], first.work, first.memory, first.trips, first.visits);
	const auto &prediction = stats.first_prediction_failure;
	IConsolePrint(CC_DEFAULT, "First opaque scope: service={}; vehicle={}", stats.opaque_service, stats.opaque_vehicle);
	IConsolePrint(CC_DEFAULT, "First trip failure: reason={}; stage=Prediction; vehicle={}; work={}; memory={}; trips={}; visits={}; cursor={}; certified_until={}; required_until={}",
			prediction_stops[static_cast<size_t>(prediction.reason)], prediction.vehicle, prediction.work, prediction.memory, prediction.trips, prediction.visits,
			prediction.stopped_at.base(), prediction.complete_until.base(), prediction.required_until.base());
	IConsolePrint(CC_DEFAULT, "Uncertainty: timing={} trips; path={} trips; OD_resolved={} searches; first_order={}; first_unknown_order={}; first_unknown_reason={}; tile={}; current_order={}",
			stats.timing_uncertainty, stats.path_uncertainty, stats.uncertainty_resolved, prediction.stopped_order, prediction.uncertain_order,
			prediction_stops[static_cast<size_t>(prediction.uncertain_reason)], prediction.tile.base(), prediction.current_order);
	IConsolePrint(CC_DEFAULT, "Simulation tick time: completed_ticks={}; total_us={}; mean_us={}; max_us={}", stats.simulation_ticks,
			stats.simulation_microseconds, stats.simulation_ticks == 0 ? 0 : stats.simulation_microseconds / stats.simulation_ticks, stats.maximum_simulation_microseconds);
	auto quantile = [](const auto &histogram, uint percentile) {
		uint64_t count = 0; for (uint64_t n : histogram) count += n;
		uint64_t rank = (count * percentile + 99) / 100, cumulative = 0;
		for (size_t i = 0; i < histogram.size(); ++i) { cumulative += histogram[i]; if (cumulative >= rank) return (i + 1) * 1000; }
		return size_t{0};
	};
	IConsolePrint(CC_DEFAULT, "Tick histogram (1ms upper bounds): simulation_p95_us={}; simulation_p99_us={}; journey_mean_us={}; journey_p95_us={}; journey_p99_us={}; journey_max_us={}",
			quantile(stats.simulation_histogram, 95), quantile(stats.simulation_histogram, 99), stats.simulation_ticks == 0 ? 0 : stats.journey_microseconds / stats.simulation_ticks,
			quantile(stats.journey_histogram, 95), quantile(stats.journey_histogram, 99), stats.maximum_journey_microseconds);
	const auto periodic = GetPassengerServiceDatabase().GetDiagnostic();
	const auto events = GetPassengerWaitingEventDiagnostic();
	IConsolePrint(CC_DEFAULT, "Passenger events: pending={}; overdue={}; oldest_ticks={}; maximum_station_backlog={}; on_time={}; packets={}; groups={}; scheduler_us={}; arrival_candidates={}; arrival_passengers={}; unresolved_missed_estimate={}",
			events.pending, events.overdue, events.oldest_ticks, events.maximum_station_backlog, events.on_time, events.packets, events.groups,
			events.scheduler_microseconds, events.arrival_candidates, events.arrival_passengers, events.unresolved_missed);
	for (size_t cause = 0; cause < static_cast<size_t>(PassengerWaitingCause::End); ++cause) {
		static constexpr std::array names{"new", "expiry", "failure", "migration", "generation"};
		IConsolePrint(CC_DEFAULT, "Passenger scheduler cause: cause={}; packets={}; microseconds={}", names[cause], events.cause_packets[cause], events.cause_nanoseconds[cause] / 1000);
	}
	IConsolePrint(CC_DEFAULT, "Passenger capacity records: packets={}; passengers={}; microseconds={}", events.capacity_missed_packets, events.capacity_missed_passengers, events.capacity_record_nanoseconds / 1000);
	IConsolePrint(CC_DEFAULT, "Passenger unchanged generation: packets={}", events.unchanged_generation_packets);
	{
		static constexpr std::array filter_modes{"off", "on", "alternate"};
		const auto mode = GetPassengerServiceDatabase().GetHyperpathBoardingFilterMode();
		IConsolePrint(CC_DEFAULT, "Passenger hyperpath boarding filter: enabled={}; mode={}; filtered_walks={}; unfiltered_walks={}; groups_checked={}; groups_skipped={}; groups_admitted={}",
				mode == PassengerServiceDatabase::HyperpathFilterMode::On ? "true" : "false", filter_modes[static_cast<size_t>(mode)], events.hyperpath_filtered_walks, events.hyperpath_unfiltered_walks,
				events.hyperpath_groups_checked, events.hyperpath_groups_skipped, events.hyperpath_groups_admitted);
		IConsolePrint(CC_DEFAULT, "Passenger hyperpath walk time: filtered_us={}; filtered_groups={}; unfiltered_us={}; unfiltered_groups={}",
				events.hyperpath_walk_nanoseconds[1] / 1000, events.hyperpath_walk_groups[1], events.hyperpath_walk_nanoseconds[0] / 1000, events.hyperpath_walk_groups[0]);
	}
	for (CargoType cargo : EnumRange(NUM_CARGO)) if (IsCargoInClass(cargo, CargoClass::Passengers)) {
		const auto p = GetPassengerServiceDatabase().GetPrecomputedDiagnostic(cargo);
		IConsolePrint(CC_DEFAULT, "Precomputed passenger routes: cargo={}; patterns={}; stations={}; states={}; edges={}; destinations={}; bytes={}; envelope={}; build_ns={}; operations={}; queries={}; query_ns={}; hits={}; missing={}; no_route={}",
			cargo, p.patterns, p.stations, p.states, p.edges, p.destinations, p.bytes, p.envelope, p.build_nanoseconds, p.operations, p.queries, p.query_nanoseconds, p.hits, p.missing, p.no_route);
		IConsolePrint(CC_DEFAULT, "Precomputed common sections: cargo={}; sections={}; concrete_rides={}", cargo, p.shared_sections, p.section_rides);
		IConsolePrint(CC_DEFAULT, "Precomputed timetable certainty: cargo={}; certified_patterns={}; estimated_patterns={}", cargo, p.certified_patterns, p.estimated_patterns);
		IConsolePrint(CC_DEFAULT, "Precomputed retained routes: cargo={}; destinations={}; bytes={}; envelope={}",
				cargo, p.retained_destinations, p.retained_bytes, p.retained_envelope);
	}
	IConsolePrint(CC_DEFAULT, "Precomputed memory admission: rejected={}; shared_limit={}", GetPassengerServiceDatabase().HasRejectedPrecomputedMemory(), PassengerPrecomputedTable::MAX_BYTES);
	IConsolePrint(CC_DEFAULT, "Precomputed initial preparation: pending={}; elapsed_ns={}; simulation_advanced=false",
			GetPassengerServiceDatabase().IsPreparingPrecomputed(), GetPassengerServiceDatabase().GetPrecomputedPreparationNanoseconds());
	IConsolePrint(CC_DEFAULT, "Journey inclusive scopes: waiting_us={}; fallback_distance_us={}; boarding_us={}", stats.waiting_microseconds, stats.fallback_distance_microseconds, stats.boarding_microseconds);
	IConsolePrint(CC_DEFAULT, "Periodic pending age: ticks={}", periodic.maximum_pending_ticks);
	IConsolePrint(CC_DEFAULT, "OD fallback cache: hits={}; bytes={}; work={}; searches={}", stats.od_fallback_cache_hits, stats.od_fallback_cache_bytes, stats.od_fallback_work, stats.od_fallback_searches);
	IConsolePrint(CC_DEFAULT, "OD fallback bindings: hits={}; builds={}; validation_nodes={}; validation_ns={}; build_ns={}; reverse_hits={}; reverse_builds={}; reverse_build_ns={}",
			stats.od_fallback_binding_hits, stats.od_fallback_binding_builds, stats.od_fallback_binding_nodes, stats.od_fallback_binding_validation_nanoseconds,
			stats.od_fallback_binding_build_nanoseconds, stats.od_fallback_reverse_hits, stats.od_fallback_reverse_builds, stats.od_fallback_reverse_build_nanoseconds);
	IConsolePrint(CC_DEFAULT, "Periodic database: services={}; timed={}; vehicles={}; bytes={}; policies_bytes={}; pending={}; builds={}; work={}; build_us={}; searches={}; query_us={}; next_departures={}; policy_hits={}; policy_misses={}; invalidations={}; rejected_work={}; rejected_memory={}",
			periodic.services, periodic.timed_services, periodic.vehicles, periodic.bytes, periodic.policy_bytes, periodic.pending, periodic.builds, periodic.build_work,
			periodic.build_microseconds, periodic.searches, periodic.query_microseconds, periodic.next_departures, periodic.policy_hits, periodic.policy_misses,
			periodic.invalidations, periodic.rejected_work, periodic.rejected_memory);
	IConsolePrint(CC_DEFAULT, "Periodic departures: logical_vehicles={}; logical_departures={}; physical_calculations={}; hits={}; fallbacks={}; builds={}; build_ns={}; bytes={}; peak_bytes={}; forward_us={}; search_work={}",
			periodic.vehicle_candidates, periodic.next_departures, periodic.departure_calculations, periodic.departure_index_hits, periodic.departure_index_fallbacks,
			periodic.departure_index_builds, periodic.departure_index_build_nanoseconds, periodic.departure_index_bytes, periodic.departure_index_peak_bytes, periodic.forward_microseconds, periodic.search_work);
	IConsolePrint(CC_DEFAULT, "Periodic global invalidations: {}", periodic.global_invalidations);
	IConsolePrint(CC_DEFAULT, "Timed search storage: labels={}; frontier_lookups={}; queue_pushes={}; queue_pops={}; scratch_bytes={}; scratch_peak_bytes={}",
		periodic.timed_labels, periodic.frontier_lookups, periodic.queue_pushes, periodic.queue_pops, periodic.search_scratch_bytes, periodic.search_scratch_peak_bytes);
	IConsolePrint(CC_DEFAULT, "Timed Work destination geometry: with_destination_label={}", periodic.work_with_destination_label);
	IConsolePrint(CC_DEFAULT, "Timed Work completion: with_complete={}; without_complete={}; with_queued={}; with_popped={}; improvement_possible={}; reverse_work={}; forward_work={}",
		periodic.work_with_complete, periodic.work_without_complete, periodic.work_with_queued_complete, periodic.work_with_popped_complete,
		periodic.work_with_improvement, periodic.work_reverse, periodic.work_forward);
	IConsolePrint(CC_DEFAULT, "Timed result states: unavailable={}; certified={}; provisional={}; deferred={}; no_route={}; rescued_unpopped={}",
		periodic.result_states[0], periodic.result_states[1], periodic.result_states[2], periodic.result_states[3], periodic.result_states[4], periodic.rescued_unpopped);
	IConsolePrint(CC_DEFAULT, "Timed plan adoption: certified_packets={}; provisional_packets={}; provisional_passengers={}",
		stats.timed_certified_packets, stats.timed_provisional_packets, stats.timed_provisional_passengers);
	static constexpr std::array work_stop_names{"None", "Admission", "Queue", "Service", "Vehicle", "Dispatch", "Departure", "Alighting", "Dominance"};
	static_assert(work_stop_names.size() == static_cast<size_t>(PassengerPeriodicPlan::WorkStop::End));
	for (size_t i = 0; i < work_stop_names.size(); ++i) IConsolePrint(CC_DEFAULT, "Timed Work stop {}: calls={}; observations={}", work_stop_names[i], periodic.work_stop_calls[i], periodic.work_stop_observations[i]);
	for (size_t i = 0; i < periodic.work_sample_count; ++i) {
		const auto &sample = periodic.work_samples[i];
		IConsolePrint(CC_DEFAULT, "Timed Work sample {}: complete={}; queued={}; popped={}; cost={}; arrival={}; lower={}; reverse={}; forward={}; first_stop={}",
			i, sample.complete_labels, sample.queued_complete, sample.popped_complete, sample.best_complete_cost.value_or(-1), sample.best_complete_arrival.base(),
			sample.remaining_lower_bound, sample.reverse_work, sample.forward_work, work_stop_names[static_cast<size_t>(sample.first_work_stop)]);
	}
	for (size_t i = 0; i < periodic.search_work_histogram.size(); ++i) IConsolePrint(CC_DEFAULT, "Timed Work histogram: upper={}; count={}", i * 1024, periodic.search_work_histogram[i]);
	IConsolePrint(CC_DEFAULT, "Periodic service pruning: bound_checks={}; bound_stops={}; pruned_services={}; skipped_vehicle_visits={}",
			periodic.service_bound_checks, periodic.service_bound_stops, periodic.pruned_services, periodic.pruned_vehicle_visits);
	IConsolePrint(CC_DEFAULT, "Periodic residency: entries={}; revision={}; publications={}; staged={}; staged_bytes={}; additions={}; removals={}; updates={}; timetable_notifications={}",
			periodic.policy_entries, periodic.published_revision, periodic.publications, periodic.staged, periodic.staged_bytes,
			periodic.service_additions, periodic.service_removals, periodic.service_updates, periodic.timetable_notifications);
	IConsolePrint(CC_DEFAULT, "Periodic cache cost: clears={}; lost={}; maximum_lost={}; explicit={}; reset={}; global={}; stale={}; evictions={}; rebuilds={}; compile_us={}; validation_us={}; eviction_us={}",
			periodic.policy_clears, periodic.policies_cleared, periodic.maximum_policies_cleared, periodic.clear_reasons[0], periodic.clear_reasons[1], periodic.clear_reasons[2],
			periodic.policy_stale, periodic.policy_evictions, periodic.policy_rebuilds, periodic.policy_compile_microseconds, periodic.policy_validation_microseconds, periodic.policy_eviction_microseconds);
	IConsolePrint(CC_DEFAULT, "Periodic publication cost: publication_us={}; wait_ticks={}; wait_samples={}", periodic.publication_microseconds, periodic.published_wait_ticks, periodic.published_wait_samples);
	IConsolePrint(CC_DEFAULT, "Periodic known vehicle phases: {}", periodic.known_phase_vehicles);
	IConsolePrint(CC_DEFAULT, "Periodic operating events: physical_passenger_occurrences={}; exchange_passenger_occurrences={}; depot_timed={}; depot_untimed={}; depot_blocked={}",
			periodic.physical_passenger_occurrences, periodic.exchange_passenger_occurrences, periodic.depot_timed, periodic.depot_untimed, periodic.depot_blocked);
	const auto schedule = GetPassengerServiceDatabase().GetScheduleDiagnostic();
	IConsolePrint(CC_DEFAULT, "Schedule policy compilation: compile_us={}; residency_shared=true", schedule.compile_microseconds);
	static constexpr std::array schedule_reasons{"ServiceMissing", "Incarnation", "Generation", "Station", "Disabled", "VehicleDeleted", "LiveRide", "ForcedUnload", "WaitingExpired"};
	static_assert(schedule_reasons.size() == static_cast<size_t>(PassengerScheduleInvalidation::End));
	for (size_t i = 0; i < schedule_reasons.size(); ++i) IConsolePrint(CC_DEFAULT, "Schedule invalidation {}: {} packets", schedule_reasons[i], stats.schedule_invalidations[i]);
	IConsolePrint(CC_DEFAULT, "Schedule routing: packets={}; passengers={}; timed_deferred={}; hits={}; misses={}; bytes={}; work={}; query_us={}; stale={}; expired={}",
			stats.schedule_packets, stats.schedule_passengers, stats.schedule_deferred_packets, schedule.hits, schedule.misses, schedule.bytes, schedule.work, schedule.query_microseconds, stats.schedule_stale, stats.schedule_expired);
	IConsolePrint(CC_DEFAULT, "Schedule transport: boarded={}; transferred={}; delivered={} people; expected_wait_person_ticks={}; actual_wait_person_ticks={}; wait_people={}",
			stats.schedule_boarded_passengers, stats.schedule_transferred_passengers, stats.schedule_delivered_passengers, stats.schedule_expected_wait, stats.schedule_actual_wait, stats.schedule_wait_samples);
	IConsolePrint(CC_DEFAULT, "Completed interchanges: from_schedule={}; from_timed={} people (next vehicle actually loaded)", stats.schedule_connected_passengers, stats.timed_connected_passengers);
	IConsolePrint(CC_DEFAULT, "Schedule-assisted final OD: delivered={} people (any real schedule leg; overlaps final-carrier delivery counts)", stats.schedule_assisted_delivered_passengers);
	IConsolePrint(CC_DEFAULT, "Periodic passenger census (live OrderLists, cargo-only excluded): total={}; passenger={}; complete_cycles={}; compile_success={}; compile_failure={}; unpublished={}; dirty={}; unknown_vehicles={}",
			periodic.orderlists, periodic.passenger_orderlists, periodic.complete_timetables, periodic.compile_success, periodic.compile_failure,
			periodic.unpublished, periodic.dirty_services, periodic.unknown_phase_vehicles);
	IConsolePrint(CC_DEFAULT, "Periodic passenger pending census: {} lists; compilation observations={} attempts/{} successes (rebuilds overlap)", periodic.pending_passenger, periodic.compilation_attempts, periodic.compilation_successes);
	IConsolePrint(CC_DEFAULT, "Periodic phase work stops: {} vehicle capture observations (retries overlap)", periodic.phase_capture_work);
	IConsolePrint(CC_DEFAULT, "Periodic passenger eligibility: declared_complete={}; live_compiled_cycles={}; published_lists={}; published_cycles={}; phase_known_lists={}; denominator={}",
			periodic.declared_complete_timetables, periodic.complete_timetables, periodic.published_passenger, periodic.published_cycles, periodic.timed_services, periodic.passenger_orderlists);
	static constexpr std::array compile_names{"None", "Control", "Refit", "Travel", "Wait", "Overflow", "ZeroPeriod", "TooFewStops"};
	static constexpr std::array phase_names{"Known", "NoTimetable", "VehicleState", "OrderProgress", "Facilities", "Work", "Unbunching", "DispatchCompetition", "DispatchUnsupported", "Overflow", "ElapsedTravel", "AwaitCapture"};
	static constexpr std::array query_names{"Found", "Invalid", "OriginMissing", "DestinationMissing", "NoAlighting", "Unreachable", "NoCandidate", "UnknownPhase", "Evaluation", "Candidates", "Labels", "Work", "Memory", "Transfers"};
	for (size_t i = 0; i < periodic.compile_failures.size(); ++i) IConsolePrint(CC_DEFAULT, "Periodic live compilation: {}={}", compile_names[i], periodic.compile_failures[i]);
	for (size_t i = 0; i < periodic.compilation_stops.size(); ++i) IConsolePrint(CC_DEFAULT, "Periodic compilation observations: {}={}", compile_names[i], periodic.compilation_stops[i]);
	for (size_t i = 0; i < periodic.phases.size(); ++i) IConsolePrint(CC_DEFAULT, "Periodic passenger vehicle phase census: {}={}", phase_names[i], periodic.phases[i]);
	for (size_t i = 0; i < periodic.outcomes.size(); ++i) IConsolePrint(CC_DEFAULT, "Periodic OD calls: {} outcomes={}; overlapping_observations={}", query_names[i], periodic.outcomes[i], periodic.observations[i]);
	IConsolePrint(CC_DEFAULT, "Periodic execution observations: expired={} packets/{} passengers; failed_same_service_boarding_checks={}; retries_overlap=true",
			periodic.expired_packets, periodic.expired_passengers, periodic.boarding_failures);
	for (size_t i = 0; i < stats.query_sample_count; ++i) {
		const auto &sample = stats.query_samples[i];
		IConsolePrint(CC_DEFAULT, "OD proof sample: origin={}; destination={}; tick={}; status={}; stop={}; candidates={}; best_score={}; unknown_arrival_bound={}; unknown_service={}",
				sample.origin, sample.destination, sample.at.base(), to_underlying(sample.status), to_underlying(sample.stop), sample.candidates,
				sample.score ? sample.score->base() : -1, sample.unknown_arrival_bound ? sample.unknown_arrival_bound->base() : -1, sample.unknown_service);
	}
	IConsolePrint(CC_DEFAULT, "Active journey {}: applied={} packets/{} passengers; builds={}; static_hits={}; searches={}; OD_hits={}",
			operation, stats.journeys, stats.passengers, stats.builds, stats.static_cache_hits, stats.queries, stats.query_cache_hits);
	const auto &admission = stats.admission;
	IConsolePrint(CC_DEFAULT, "Periodic admission: accepted={}; rejected={}; reserved={}; used={}; returned={}; max_tick_queries={}; max_tick_work={}",
			admission.accepted, admission.rejected, admission.reserved, admission.used, admission.returned, admission.maximum_tick_queries, admission.maximum_tick_work);
	static constexpr std::array admission_reasons{"None", "EventQueries", "TickQueries", "EventWork", "GlobalWork", "FairWork", "FairQueries"};
	static_assert(admission_reasons.size() == static_cast<size_t>(PassengerQueryAdmission::Rejection::End));
	for (size_t i = 1; i < admission_reasons.size(); ++i) IConsolePrint(CC_DEFAULT, "Admission rejected {}: {}", admission_reasons[i], admission.rejections[i]);
	IConsolePrint(CC_DEFAULT, "Periodic allocation: timed={}; schedule={}; timed_used={}; schedule_used={}",
			admission.timed_allocated, admission.schedule_allocated, admission.timed_used, admission.schedule_used);
	IConsolePrint(CC_DEFAULT, "Periodic Work outcomes: stopped={}; no_route={}; schedule_rescued={}; complete_unproved={}; incomplete_work={}; stop_percent={:.3f}; no_route_percent={:.3f}",
			admission.work_stopped, admission.work_no_route, admission.schedule_rescued, admission.complete_unproved, admission.incomplete_work,
			admission.accepted == 0 ? 0.0 : 100.0 * admission.work_stopped / admission.accepted,
			admission.accepted == 0 ? 0.0 : 100.0 * admission.work_no_route / admission.accepted);
	IConsolePrint(CC_DEFAULT, "Periodic missing: published={}; building={}; retries={}; max_od_attempts={}; tracking_evictions={}",
			admission.missing_published, admission.missing_building, admission.retries, admission.maximum_od_attempts, admission.retry_tracking_evictions);
	for (size_t i = 0; i < admission.retry_sample_count; ++i) {
		const auto &sample = admission.retry_samples[i];
		IConsolePrint(CC_DEFAULT, "Periodic OD retry: cargo={}; origin={}; destination={}; attempts={}", sample.cargo, sample.origin, sample.destination, sample.attempts);
	}
	for (size_t i = 0; i < admission.tick_queries.size(); ++i) if (admission.tick_queries[i] != 0) IConsolePrint(CC_DEFAULT, "Periodic tick searches {}: {}", i, admission.tick_queries[i]);
	for (size_t i = 0; i < admission.tick_work.size(); ++i) if (admission.tick_work[i] != 0) IConsolePrint(CC_DEFAULT, "Periodic tick Work upper {}: {}", i * 16384, admission.tick_work[i]);
	IConsolePrint(CC_DEFAULT, "Train observations={}; cargo_capable={}; possible_refit={}; predicted={}; inactive={}; excluded_cargo={}; excluded_scope={}; visits={}; omitted_trains_at_least={}; truncated_predictions={} (uncaptured visit count unknown)",
			stats.trains, stats.cargo_capable, stats.possible_refit, stats.predicted, stats.inactive, stats.excluded_cargo, stats.excluded_scope, stats.visits, stats.omitted_trains, stats.truncated_predictions);
	IConsolePrint(CC_DEFAULT, "Trip prediction: executions={}; hits={}; logical_work={}; executed_visits={}; predictor_ns={}; cache_bytes={}",
			stats.prediction_executions, stats.prediction_cache_hits, stats.prediction_work, stats.prediction_executed_visits, stats.prediction_nanoseconds, stats.prediction_cache_bytes);
	IConsolePrint(CC_DEFAULT, "Graph work={}; mean={}; max={}; cached_index_allowance_avoided={}; query_allowance={}; build_us={}; mean_us={}; max_us={}; search_us={}; max_tick_graph_search_us={}",
			stats.graph_work, stats.builds == 0 ? 0 : stats.graph_work / stats.builds, stats.maximum_graph_work, stats.reused_graph_work, stats.query_work,
			stats.build_microseconds, stats.builds == 0 ? 0 : stats.build_microseconds / stats.builds, stats.maximum_build_microseconds, stats.query_microseconds,
			std::max(stats.maximum_tick_microseconds, operation == "tick" ? stats.build_microseconds + stats.query_microseconds : uint64_t{0}));
	IConsolePrint(CC_DEFAULT, "Peak graph retained_estimate={}; static retained_estimate={}; conservative_graph_envelope_including_index={}; query_scratch={}; query_cache={}",
			stats.graph_allocation_bytes, stats.static_allocation_bytes, stats.graph_memory_bound, stats.query_scratch_bytes, stats.query_cache_bytes);
	IConsolePrint(CC_DEFAULT, "Graph phase_us: discovery={}; capacity={}; selection={}; orders_dispatch={}; pattern={}; prediction={}; departures={}",
			stats.graph_phase_microseconds[0], stats.graph_phase_microseconds[1], stats.graph_phase_microseconds[2], stats.graph_phase_microseconds[3],
			stats.graph_phase_microseconds[4], stats.graph_phase_microseconds[5], stats.graph_phase_microseconds[6]);
	IConsolePrint(CC_DEFAULT, "Event capture: discovery_hits={}; service_hits={}; logical_work_replayed={}; retained_estimate_including_shared_patterns={}",
			stats.capture_discovery_hits, stats.capture_service_hits, stats.capture_reused_work, stats.capture_allocation_bytes);
	static constexpr std::array reasons{"GraphWork", "GraphMemory", "SnapshotLimit", "QueryWork", "QueryLimit", "QueryMemory", "PredictionIncomplete", "PredictionHorizon", "NoJourney", "InvalidLeg", "StaleLeg", "Disabled", "VehicleDeleted"};
	static_assert(reasons.size() == static_cast<size_t>(PassengerJourneyFallbackReason::End));
	IConsolePrint(CC_DEFAULT, "Fair waiting shares: claims={}; releases={}; admission_scan_work={}; retained_rides={}",
			stats.fair_share_claims, stats.fair_share_releases, stats.fair_share_work, stats.retained_rides);
	IConsolePrint(CC_DEFAULT, "OD fallback: work={}; path_searches={}", stats.od_fallback_work, stats.od_fallback_searches);
	IConsolePrint(CC_DEFAULT, "Journey transport: boarded={}; transferred={}; delivered={} people", stats.boarded_passengers, stats.transferred_passengers, stats.delivered_passengers);
	IConsolePrint(CC_DEFAULT, "Timed depot transport: service_boarded={}; service_delivered={}; crossing_boarded={}; crossing_delivered={} people",
			stats.depot_service_boarded_passengers, stats.depot_service_delivered_passengers, stats.depot_crossing_boarded_passengers, stats.depot_crossing_delivered_passengers);
	IConsolePrint(CC_DEFAULT, "Pragmatic routing: timed={} packets; timed_ignoring_unknown={}; timed_budget_deferred={}; untimed={} live routes; untimed_no_route={}; untimed_budget_deferred={}",
			stats.journeys, stats.timed_routes_ignoring_unknown, stats.timed_budget_deferred, stats.untimed_routes, stats.untimed_no_route, stats.untimed_budget_deferred);
	IConsolePrint(CC_DEFAULT, "Untimed transport: boarded={}; transferred={}; delivered={} people", stats.untimed_boarded_passengers, stats.untimed_transferred_passengers, stats.untimed_delivered_passengers);
	for (size_t i = 0; i < reasons.size(); ++i) IConsolePrint(CC_DEFAULT, "Fallback {}: {} packets; deferred={} packets", reasons[i], stats.fallbacks[i], stats.deferred[i]);
	return true;
}

static bool ConPassengerJourneyShadow(std::span<std::string_view> argv)
{
	if (argv.empty()) {
		IConsolePrint(CC_HELP, "passenger_journey_shadow [on|off|stats|reset|details|inventory]: local read-only train journey diagnostics (default off)");
		return true;
	}
	if (argv.size() > 2) return false;
	std::string_view operation = argv.size() == 1 ? "stats" : argv[1];
	if (operation == "on" || operation == "off") {
		SetPassengerJourneyShadowEnabled(operation == "on");
		IConsolePrint(CC_DEFAULT, "Passenger journey shadow: {}", IsPassengerJourneyShadowEnabled() ? "on" : "off");
		return true;
	}
	if (operation == "reset") { ResetPassengerJourneyShadowStats(); return true; }
	if (operation == "inventory") {
		/* Explicit, bounded inspection explains low coverage without advancing or
		 * generating OD/cargo. These are current packet holdings, not arrival stats. */
		std::array<PassengerShadowCount, 4> known{}, automatic{};
		size_t work = 0;
		bool complete = true;
		for (const Vehicle *v : Vehicle::Iterate()) {
			if (++work > 1048576) { complete = false; break; }
			size_t mode = to_underlying(v->type);
			if (mode >= known.size() || v->cargo_type >= NUM_CARGO || !IsCargoInClass(v->cargo_type, CargoClass::Passengers)) continue;
			for (const CargoPacket *packet : *v->cargo.Packets()) {
				if (++work > 1048576) { complete = false; break; }
				if (packet->GetPassengerDestination() == StationID::Invalid()) continue;
				known[mode].Add(packet->Count());
				if (_settings_game.linkgraph.GetDistributionType(v->cargo_type) != DistributionType::Manual) automatic[mode].Add(packet->Count());
			}
			if (!complete) break;
		}
		static constexpr std::array modes{ "train", "road", "ship", "aircraft" };
		IConsolePrint(CC_DEFAULT, "Current known-OD passenger packet inventory ({}; at most 1048576 vehicle/packet inspections):", complete ? "complete" : "truncated");
		for (size_t mode = 0; mode < modes.size(); ++mode) IConsolePrint(CC_DEFAULT, "{}: known={} people/{} packets; non-Manual={} people/{} packets",
				modes[mode], known[mode].passengers, known[mode].packets, automatic[mode].passengers, automatic[mode].packets);
		return true;
	}
	if (operation == "details") {
		static constexpr std::array decisions{ "Stay", "Transfer", "Arrived", "Unknown", "Unreachable" };
		static constexpr std::array statuses{ "Complete", "Unknown", "LimitReached", "BudgetExhausted" };
		for (const auto &detail : GetPassengerJourneyShadowDetails()) {
			const char *legacy = detail.legacy == VehicleCargoList::MoveToAction::Keep ? "Keep" :
					detail.legacy == VehicleCargoList::MoveToAction::Transfer ? "Transfer" : "Deliver";
			IConsolePrint(CC_DEFAULT, "station={} vehicle={} OD={}->{} via={} people={} legacy={} planner={} status={} category={} arrival={} transfers={} generalized_ticks={}",
					detail.station, detail.vehicle, detail.origin, detail.destination, detail.via, detail.count, legacy,
					decisions[to_underlying(detail.planner)], statuses[to_underlying(detail.status)], PassengerShadowCategoryName(detail.category),
					detail.arrival.base(), detail.transfers, detail.generalized_time.base());
		}
		return true;
	}
	if (operation != "stats") return false;
	const auto &stats = GetPassengerJourneyShadowStats();
	auto percent = [](uint64_t numerator, uint64_t denominator) { return denominator == 0 ? std::string("n/a") : fmt::format("{:.2f}%", 100.0 * numerator / denominator); };
	IConsolePrint(CC_DEFAULT, "Passenger journey shadow: {}; observations={} people/{} packets; known OD={} people/{} packets; evaluated={} people/{} packets ({} of known OD)",
			IsPassengerJourneyShadowEnabled() ? "on" : "off", stats.observed.passengers, stats.observed.packets,
			stats.known_od.passengers, stats.known_od.packets, stats.evaluated.passengers, stats.evaluated.packets,
			percent(stats.evaluated.passengers, stats.known_od.passengers));
	IConsolePrint(CC_DEFAULT, "Eligible passenger OD={} people/{} packets; evaluated={} of eligible; excluded unsupported OD={} people/{} packets; manual OD={} people/{} packets; eligible without snapshot={} people/{} packets",
			stats.eligible_od.passengers, stats.eligible_od.packets, percent(stats.evaluated.passengers, stats.eligible_od.passengers),
			stats.unsupported_od.passengers, stats.unsupported_od.packets, stats.manual_od.passengers, stats.manual_od.packets,
			stats.uncaptured_od.passengers, stats.uncaptured_od.packets);
	uint64_t matches = 0, comparable = 0;
	static constexpr std::array modes{"train", "road", "ship", "aircraft"};
	for (size_t i = 0; i < stats.modes.size(); ++i) {
		const auto &mode = stats.modes[i];
		IConsolePrint(CC_DEFAULT, "{}: evaluated={} journeys={} fallback={} mixed_transfers={}; predictions: complete={} state={} progress={} facilities={} order/timing={} budget={}",
				modes[i], mode.evaluated.packets, mode.journeys.packets, mode.fallback.packets, mode.mixed_transfers,
				mode.prediction_reasons[0], mode.prediction_reasons[1], mode.prediction_reasons[2], mode.prediction_reasons[3], mode.prediction_reasons[4], mode.prediction_reasons[5]);
	}
	for (size_t index = 0; index < stats.categories.size(); ++index) {
		const auto &count = stats.categories[index];
		IConsolePrint(CC_DEFAULT, "{}: {} people / {} packets", PassengerShadowCategoryName(static_cast<PassengerShadowCategory>(index)), count.passengers, count.packets);
		if (index < 4) comparable += count.passengers;
		if (index < 2) matches += count.passengers;
	}
	IConsolePrint(CC_DEFAULT, "Complete decisions={} of known OD; Stay/Transfer agreement={}; Unknown={}; PredictionUnknown={}; BudgetExhausted={}; LimitReached={} (evaluated people)",
			percent(stats.decidable.passengers, stats.known_od.passengers), percent(matches, comparable), percent(stats.unknown.passengers, stats.evaluated.passengers), percent(stats.horizon_incomplete.passengers, stats.evaluated.passengers),
			percent(stats.budget_exhausted.passengers, stats.evaluated.passengers), percent(stats.limit_reached.passengers, stats.evaluated.passengers));
	IConsolePrint(CC_DEFAULT, "builds={} graph_us={} query_calls={} search_us={} cache_hits={} ({}) mean_work={:.1f} max_work={} scratch_peak={} graph_memory_bound={} cache_peak={} additional_cpu_us={}",
			stats.builds, stats.graph_us, stats.queries, stats.search_us, stats.cache_hits, percent(stats.cache_hits, stats.queries),
			stats.queries == stats.cache_hits ? 0.0 : double(stats.work) / (stats.queries - stats.cache_hits), stats.max_work,
			stats.scratch_peak, stats.graph_memory_bound, stats.cache_peak, stats.cpu_ns / 1000);
	IConsolePrint(CC_DEFAULT, "Hard quota / 64 state ticks: 1 graph (1048576 work, 1 GiB conservative envelope), 32 cache misses, 512 observations, 2097152 combined work; query 65536 work / 8 MiB scratch; 1 MiB cache; 64 detail records. Horizon/range absence is not global unreachability.");
	return true;
}

void IConsoleStdLibRegister()
{
	IConsole::CmdRegister("debug_level",             ConDebugLevel);
	IConsole::CmdRegister("echo",                    ConEcho);
	IConsole::CmdRegister("echoc",                   ConEchoC);
	IConsole::CmdRegister("exec",                    ConExec);
	IConsole::CmdRegister("schedule",                ConSchedule);
	IConsole::CmdRegister("exit",                    ConExit);
	IConsole::CmdRegister("part",                    ConPart);
	IConsole::CmdRegister("help",                    ConHelp);
	IConsole::CmdRegister("info_cmd",                ConInfoCmd);
	IConsole::CmdRegister("list_cmds",               ConListCommands);
	IConsole::CmdRegister("list_aliases",            ConListAliases);
	IConsole::CmdRegister("newgame",                 ConNewGame);
	IConsole::CmdRegister("restart",                 ConRestart);
	IConsole::CmdRegister("reload",                  ConReload);
	IConsole::CmdRegister("getseed",                 ConGetSeed);
	IConsole::CmdRegister("getdate",                 ConGetDate);
	IConsole::CmdRegister("getsysdate",              ConGetSysDate);
	IConsole::CmdRegister("quit",                    ConExit);
	IConsole::CmdRegister("resetengines",            ConResetEngines,     ConHookNoNetwork);
	IConsole::CmdRegister("reset_enginepool",        ConResetEnginePool,  ConHookNoNetwork);
	IConsole::CmdRegister("return",                  ConReturn);
	IConsole::CmdRegister("screenshot",              ConScreenShot);
	IConsole::CmdRegister("minimap",                 ConMinimap);
	IConsole::CmdRegister("script",                  ConScript);
	IConsole::CmdRegister("zoomto",                  ConZoomToLevel);
	IConsole::CmdRegister("scrollto",                ConScrollToTile);
	IConsole::CmdRegister("highlight_tile",          ConHighlightTile);
	IConsole::AliasRegister("scrollto_highlight",    "scrollto %+; highlight_tile %+");
	IConsole::CmdRegister("alias",                   ConAlias);
	IConsole::CmdRegister("load",                    ConLoad);
	IConsole::CmdRegister("load_save",               ConLoad);
	IConsole::CmdRegister("load_scenario",           ConLoadScenario);
	IConsole::CmdRegister("load_heightmap",          ConLoadHeightmap);
	IConsole::CmdRegister("rm",                      ConRemove);
	IConsole::CmdRegister("save",                    ConSave);
	IConsole::CmdRegister("saveconfig",              ConSaveConfig);
	IConsole::CmdRegister("ls",                      ConListFiles);
	IConsole::CmdRegister("list_saves",              ConListFiles);
	IConsole::CmdRegister("list_scenarios",          ConListScenarios);
	IConsole::CmdRegister("list_heightmaps",         ConListHeightmaps);
	IConsole::CmdRegister("cd",                      ConChangeDirectory);
	IConsole::CmdRegister("pwd",                     ConPrintWorkingDirectory);
	IConsole::CmdRegister("clear",                   ConClearBuffer);
	IConsole::CmdRegister("font",                    ConFont);
	IConsole::CmdRegister("setting",                 ConSetting);
	IConsole::CmdRegister("setting_newgame",         ConSettingNewgame);
	IConsole::CmdRegister("list_settings",           ConListSettings);
	IConsole::CmdRegister("list_settings_def",       ConListSettingsDefaults);
	IConsole::CmdRegister("gamelog",                 ConGamelogPrint);
	IConsole::CmdRegister("rescan_newgrf",           ConRescanNewGRF);
	IConsole::CmdRegister("list_dirs",               ConListDirs);

	IConsole::AliasRegister("dir",                   "ls");
	IConsole::AliasRegister("del",                   "rm %+");
	IConsole::AliasRegister("newmap",                "newgame");
	IConsole::AliasRegister("patch",                 "setting %+");
	IConsole::AliasRegister("set",                   "setting %+");
	IConsole::AliasRegister("set_newgame",           "setting_newgame %+");
	IConsole::AliasRegister("list_patches",          "list_settings %+");
	IConsole::AliasRegister("developer",             "setting developer %+");

	IConsole::CmdRegister("list_ai_libs",            ConListAILibs);
	IConsole::CmdRegister("list_ai",                 ConListAI);
	IConsole::CmdRegister("reload_ai",               ConReloadAI);
	IConsole::CmdRegister("rescan_ai",               ConRescanAI);
	IConsole::CmdRegister("start_ai",                ConStartAI);
	IConsole::CmdRegister("stop_ai",                 ConStopAI);

	IConsole::CmdRegister("list_game",               ConListGame);
	IConsole::CmdRegister("list_game_libs",          ConListGameLibs);
	IConsole::CmdRegister("rescan_game",             ConRescanGame);

	IConsole::CmdRegister("companies",               ConCompanies);
	IConsole::AliasRegister("players",               "companies");

	/* networking functions */

/* Content downloading is only available with ZLIB */
#if defined(WITH_ZLIB)
	IConsole::CmdRegister("content",                 ConContent);
#endif /* defined(WITH_ZLIB) */

	/*** Networking commands ***/
	IConsole::CmdRegister("say",                     ConSay,              ConHookNeedNetwork);
	IConsole::CmdRegister("say_company",             ConSayCompany,       ConHookNeedNetwork);
	IConsole::AliasRegister("say_player",            "say_company %+");
	IConsole::CmdRegister("say_client",              ConSayClient,        ConHookNeedNetwork);

	IConsole::CmdRegister("connect",                 ConNetworkConnect,   ConHookClientOnly);
	IConsole::CmdRegister("clients",                 ConNetworkClients,   ConHookNeedNetwork);
	IConsole::CmdRegister("status",                  ConStatus,           ConHookServerOnly);
	IConsole::CmdRegister("server_info",             ConServerInfo,       ConHookServerOnly);
	IConsole::AliasRegister("info",                  "server_info");
	IConsole::CmdRegister("reconnect",               ConNetworkReconnect, ConHookClientOnly);
	IConsole::CmdRegister("rcon",                    ConRcon,             ConHookNeedNetwork);
	IConsole::CmdRegister("settings_access",         ConSettingsAccess,   ConHookNeedNetwork);

	IConsole::CmdRegister("join",                    ConJoinCompany,      ConHookNeedNonDedicatedOrNoNetwork);
	IConsole::AliasRegister("spectate",              "join 255");
	IConsole::CmdRegister("move",                    ConMoveClient,       ConHookServerOnly);
	IConsole::CmdRegister("reset_company",           ConResetCompany,     ConHookServerOnly);
	IConsole::AliasRegister("clean_company",         "reset_company %A");
	IConsole::CmdRegister("offer_company_sale",      ConOfferCompanySale, ConHookServerOrNoNetwork);
	IConsole::CmdRegister("merge_companies",         ConMergeCompanies,   ConHookServerOrNoNetwork);
	IConsole::CmdRegister("client_name",             ConClientNickChange, ConHookServerOnly);
	IConsole::CmdRegister("kick",                    ConKick,             ConHookServerOnly);
	IConsole::CmdRegister("ban",                     ConBan,              ConHookServerOnly);
	IConsole::CmdRegister("unban",                   ConUnBan,            ConHookServerOnly);
	IConsole::CmdRegister("banlist",                 ConBanList,          ConHookServerOnly);

	IConsole::CmdRegister("pause",                   ConPauseGame,        ConHookServerOrNoNetwork);
	IConsole::CmdRegister("unpause",                 ConUnpauseGame,      ConHookServerOrNoNetwork);
	IConsole::CmdRegister("step",                    ConStepGame,         ConHookNoNetwork);

	IConsole::CmdRegister("authorized_key",          ConNetworkAuthorizedKey, ConHookServerOnly);
	IConsole::AliasRegister("ak", "authorized_key %+");

	IConsole::CmdRegister("company_pw",              ConCompanyPassword,  ConHookNeedNetwork);
	IConsole::AliasRegister("company_password",      "company_pw %+");
	IConsole::CmdRegister("company_pw_hash",         ConCompanyPasswordHash, ConHookServerOnly);
	IConsole::AliasRegister("company_password_hash", "company_pw %+");
	IConsole::CmdRegister("company_pw_hashes",       ConCompanyPasswordHashes, ConHookServerOnly);
	IConsole::AliasRegister("company_password_hashes", "company_pw_hashes");

	IConsole::AliasRegister("net_frame_freq",        "setting frame_freq %+");
	IConsole::AliasRegister("net_sync_freq",         "setting sync_freq %+");
	IConsole::AliasRegister("server_pw",             "setting server_password %+");
	IConsole::AliasRegister("server_password",       "setting server_password %+");
	IConsole::AliasRegister("rcon_pw",               "setting rcon_password %+");
	IConsole::AliasRegister("rcon_password",         "setting rcon_password %+");
	IConsole::AliasRegister("settings_pw",           "setting settings_password %+");
	IConsole::AliasRegister("settings_password",     "setting settings_password %+");
	IConsole::AliasRegister("name",                  "setting client_name %+");
	IConsole::AliasRegister("server_name",           "setting server_name %+");
	IConsole::AliasRegister("server_port",           "setting server_port %+");
	IConsole::AliasRegister("max_clients",           "setting max_clients %+");
	IConsole::AliasRegister("max_companies",         "setting max_companies %+");
	IConsole::AliasRegister("max_join_time",         "setting max_join_time %+");
	IConsole::AliasRegister("pause_on_join",         "setting pause_on_join %+");
	IConsole::AliasRegister("autoclean_companies",   "setting autoclean_companies %+");
	IConsole::AliasRegister("autoclean_protected",   "setting autoclean_protected %+");
	IConsole::AliasRegister("autoclean_unprotected", "setting autoclean_unprotected %+");
	IConsole::AliasRegister("restart_game_year",     "setting restart_game_year %+");
	IConsole::AliasRegister("min_players",           "setting min_active_clients %+");
	IConsole::AliasRegister("reload_cfg",            "setting reload_cfg %+");

	/* conditionals */
	IConsole::CmdRegister("if_year",                 ConIfYear);
	IConsole::CmdRegister("if_month",                ConIfMonth);
	IConsole::CmdRegister("if_day",                  ConIfDay);
	IConsole::CmdRegister("if_hour",                 ConIfHour);
	IConsole::CmdRegister("if_minute",               ConIfMinute);
	IConsole::CmdRegister("if_hour_minute",          ConIfHourMinute);

	/* debugging stuff */
#ifdef _DEBUG
	IConsoleDebugLibRegister();
#endif
	IConsole::CmdRegister("fps",                     ConFramerate);
	IConsole::CmdRegister("passenger_journey_shadow", ConPassengerJourneyShadow);
	IConsole::CmdRegister("passenger_journey_stats", ConPassengerJourneyStats);
	IConsole::CmdRegister("passenger_periodic_compare", ConPassengerPeriodicCompare);
#ifdef WITH_PASSENGER_BENCHMARK
	IConsole::CmdRegister("passenger_periodic_fixture", ConPassengerPeriodicFixture, ConHookServerOrNoNetwork);
#endif
	IConsole::CmdRegister("passenger_service_inspect", ConPassengerServiceInspect);
	IConsole::CmdRegister("passenger_service_capture_benchmark", ConPassengerServiceCaptureBenchmark);
	IConsole::CmdRegister("fps_wnd",                 ConFramerateWindow);

	IConsole::CmdRegister("find_non_realistic_braking_signal", ConFindNonRealisticBrakingSignal);
	IConsole::CmdRegister("find_missing_object",     ConFindMissingObject);
	IConsole::CmdRegister("create_town", ConCreateTown);

	IConsole::CmdRegister("getfulldate",             ConGetFullDate,      nullptr, true);
	IConsole::CmdRegister("dump_command_log",        ConDumpCommandLog,   nullptr, true);
	IConsole::CmdRegister("dump_special_events_log", ConDumpSpecialEventsLog, nullptr, true);
	IConsole::CmdRegister("dump_desync_msgs",        ConDumpDesyncMsgLog, nullptr, true);
	IConsole::CmdRegister("dump_inflation",          ConDumpInflation,    nullptr, true);
	IConsole::CmdRegister("dump_cpdp_stats",         ConDumpCpdpStats,    nullptr, true);
	IConsole::CmdRegister("dump_veh_stats",          ConVehicleStats,     nullptr, true);
	IConsole::CmdRegister("dump_map_stats",          ConMapStats,         nullptr, true);
	IConsole::CmdRegister("dump_st_flow_stats",      ConStFlowStats,      nullptr, true);
	IConsole::CmdRegister("dump_slot_stats",         ConSlotsStats,       nullptr, true);
	IConsole::CmdRegister("dump_game_events",        ConDumpGameEvents,   nullptr, true);
	IConsole::CmdRegister("dump_load_debug_log",     ConDumpLoadDebugLog, nullptr, true);
	IConsole::CmdRegister("dump_load_debug_config",  ConDumpLoadDebugConfig, nullptr, true);
	IConsole::CmdRegister("dump_linkgraph_jobs",     ConDumpLinkgraphJobs, nullptr, true);
	IConsole::CmdRegister("dump_road_types",         ConDumpRoadTypes,    nullptr, true);
	IConsole::CmdRegister("dump_rail_types",         ConDumpRailTypes,    nullptr, true);
	IConsole::CmdRegister("dump_bridge_types",       ConDumpBridgeTypes,  nullptr, true);
	IConsole::CmdRegister("dump_cargo_types",        ConDumpCargoTypes,   nullptr, true);
	IConsole::CmdRegister("dump_vehicle",            ConDumpVehicle,      nullptr, true);
	IConsole::CmdRegister("dump_tile",               ConDumpTile,         nullptr, true);
	IConsole::CmdRegister("dump_grf_cargo_tables",   ConDumpGrfCargoTables, nullptr, true);
	IConsole::CmdRegister("dump_signal_styles",      ConDumpSignalStyles, nullptr, true);
	IConsole::CmdRegister("dump_sprite_cache_stats", ConSpriteCacheStats, nullptr, true);
	IConsole::CmdRegister("dump_version",            ConDumpVersion,      nullptr, true);
	IConsole::CmdRegister("check_caches",            ConCheckCaches,      nullptr, true);
	IConsole::CmdRegister("show_town_window",        ConShowTownWindow,   nullptr, true);
	IConsole::CmdRegister("show_station_window",     ConShowStationWindow, nullptr, true);
	IConsole::CmdRegister("show_industry_window",    ConShowIndustryWindow, nullptr, true);
	IConsole::CmdRegister("viewport_debug",          ConViewportDebug,    nullptr, true);
	IConsole::CmdRegister("viewport_mark_dirty",     ConViewportMarkDirty, nullptr, true);
	IConsole::CmdRegister("viewport_mark_dirty_st_overlay", ConViewportMarkStationOverlayDirty, nullptr, true);
	IConsole::CmdRegister("gfx_debug",               ConGfxDebug,         nullptr, true);
	IConsole::CmdRegister("csleep",                  ConCSleep,           nullptr, true);
	IConsole::CmdRegister("recalculate_road_cached_one_way_states", ConRecalculateRoadCachedOneWayStates, ConHookNoNetwork, true);
	IConsole::CmdRegister("misc_debug",              ConMiscDebug,        nullptr, true);
	IConsole::CmdRegister("set_newgrf_optimiser_flags", ConSetNewGRFOptimiserFlags, nullptr, true);

	/* NewGRF development stuff */
	IConsole::CmdRegister("reload_newgrfs",          ConNewGRFReload,     ConHookNewGRFDeveloperTool);
	IConsole::CmdRegister("newgrf_profile",          ConNewGRFProfile,    ConHookNewGRFDeveloperTool);
	IConsole::CmdRegister("dump_info",               ConDumpInfo);
	IConsole::CmdRegister("do_disaster",             ConDoDisaster,       ConHookNewGRFDeveloperTool, true);
	IConsole::CmdRegister("bankrupt_company",        ConBankruptCompany,  ConHookNewGRFDeveloperTool, true);
	IConsole::CmdRegister("delete_company",          ConDeleteCompany,    ConHookNewGRFDeveloperTool, true);
	IConsole::CmdRegister("road_type_flag_ctl",      ConRoadTypeFlagCtl,  ConHookNewGRFDeveloperTool, true);
	IConsole::CmdRegister("rail_type_map_colour_ctl", ConRailTypeMapColourCtl, ConHookNewGRFDeveloperTool, true);
	IConsole::CmdRegister("switch_baseset",          ConSwitchBaseset,    ConHookNewGRFDeveloperTool, true);

	/* Bug workarounds */
	IConsole::CmdRegister("jgrpp_bug_workaround_unblock_heliports", ConResetBlockedHeliports, ConHookNoNetwork, true);
	IConsole::CmdRegister("merge_linkgraph_jobs_asap", ConMergeLinkgraphJobsAsap, ConHookNoNetwork, true);
	IConsole::CmdRegister("unblock_bay_road_stops",  ConUnblockBayRoadStops,  ConHookNoNetwork, true);

	IConsole::CmdRegister("dbgspecial",              ConDbgSpecial,       ConHookSpecialCmd, true);

#ifdef _DEBUG
	IConsole::CmdRegister("delete_vehicle_id",       ConDeleteVehicleID,  ConHookNoNetwork, true);
	IConsole::CmdRegister("run_tile_loop_tile",      ConRunTileLoopTile,  ConHookNoNetwork, true);
#endif
}
