/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file null_v.cpp The video driver that doesn't blit. */

#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/stdafx.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/gfx_func.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/blitter/factory.hpp"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/sl/saveload_func.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/window_func.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/thread.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/video/null_v.h"
#ifdef WITH_PASSENGER_BENCHMARK
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/console_func.h"
#endif

#include <atomic>
#include <fstream>
#include <cstdio>
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/openttd.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/date_func.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/passenger_service_database.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/network/network.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/network/network_internal.h"
#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/console_func.h"


#include "C:/Users/bebe/.codex/worktrees/dae2/OpenTTD-patches/src/safeguards.h"

/** Factory for the null video driver. */
static FVideoDriver_Null iFVideoDriver_Null;

extern std::atomic<bool> _exit_game;

const char *VideoDriver_Null::Start(const StringList &parm)
{
#ifdef _MSC_VER
	/* Disable the MSVC assertion message box. */
	_set_error_mode(_OUT_TO_STDERR);
	_CrtSetReportMode(_CRT_ASSERT, _CRTDBG_MODE_FILE);
	_CrtSetReportFile(_CRT_ASSERT, _CRTDBG_FILE_STDERR);
#endif

	this->UpdateAutoResolution();

	this->ticks = GetDriverParamInt(parm, "ticks", 1000);
	this->until_exit = GetDriverParamBool(parm, "until_exit");
	_screen.width  = _screen.pitch = _cur_resolution.width;
	_screen.height = _cur_resolution.height;
	_screen.dst_ptr = nullptr;
	ScreenSizeChanged();

	/* Do not render, nor blit */
	Debug(misc, 1, "Forcing blitter 'null'...");
	BlitterFactory::SelectBlitter("null");
	return nullptr;
}

void VideoDriver_Null::Stop() { }

void VideoDriver_Null::MakeDirty(int, int, int, int) {}

void VideoDriver_Null::MainLoop()
{
	SetSelfAsGameThread();
	if (this->until_exit) {

        bool observed = false, replay_started = false;
        uint64_t slices = 0, maximum_us = 0;
        int64_t start_tick = 0;
        uint32_t start_frame = 0;
        while (!_exit_game) {
            auto &db = GetPassengerServiceDatabase();
            bool replay = db.GetLoadState() == PassengerServiceDatabase::LoadState::Replaying;
            if (replay && !replay_started) { replay_started = true; start_tick = _state_ticks.base(); start_frame = _frame_counter; }
            auto started = std::chrono::steady_clock::now();
            ::GameLoop(); ::InputLoop(); ::UpdateWindows();
            if (replay) {
                ++slices;
                maximum_us = std::max<uint64_t>(maximum_us, std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - started).count());
            }
            if (replay_started && db.GetLoadState() == PassengerServiceDatabase::LoadState::Ready && !observed) {
                std::ofstream out("join-replay.json");
                out << "{\"slices\":" << slices << ",\"maximum_loop_us\":" << maximum_us << ",\"work\":" << db.GetLoadWork()
                    << ",\"start_tick\":" << start_tick << ",\"end_tick\":" << _state_ticks.base()
                    << ",\"start_frame\":" << start_frame << ",\"end_frame\":" << _frame_counter << "}\n";
                observed = true;
            }
            if (_networking && !_network_server && !_network_first_time) {
                std::ifstream request("probe-request.txt");
                if (request) {
                    std::vector<std::string> commands;
                    std::string command;
                    while (std::getline(request, command)) commands.push_back(command);
                    request.close(); std::remove("probe-request.txt");
                    for (const auto &line : commands) IConsoleCmdExec(line);
                }
            }
            CSleep(1);
        }

	} else {
		for (int i = 0; i < this->ticks; i++) {
			::GameLoop();
			::InputLoop();
			::UpdateWindows();
		}
	}

	/* If requested, make a save just before exit. The normal exit-flow is
	 * not triggered from this driver, so we have to do this manually. */
	if (_settings_client.gui.autosave_on_exit) {
		DoExitSave();
	}
#ifdef WITH_PASSENGER_BENCHMARK
	if (!this->until_exit) {
		IConsoleCmdExec("exec scripts/passenger_benchmark_end.scr 0");
	}
#endif
}

bool VideoDriver_Null::ChangeResolution(int, int) { return false; }

bool VideoDriver_Null::ToggleFullscreen(bool) { return false; }
