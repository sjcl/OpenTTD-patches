"""Summarize the independent target-OD trace without pooling censored trips.

Usage: python analyze-focused.py RUN_DIRECTORY OUTPUT_JSON
"""
import collections
import csv
import json
import math
import pathlib
import statistics
import sys


def distribution(values):
    values = sorted(values)
    return dict(n=len(values), mean=statistics.mean(values), median=statistics.median(values),
        p95=values[math.ceil(.95 * len(values)) - 1], maximum=values[-1]) if values else None


directory, output = map(pathlib.Path, sys.argv[1:])
rows = []
for fate in ['delivered', 'pending', 'lost']:
    path = directory / f'transport-{fate}.csv'
    if path.exists():
        for row in csv.DictReader(path.open(encoding='utf-8', newline='')):
            rows.append(dict(row, fate=fate))
events = list(csv.DictReader((directory / 'transport-target-events.csv').open(encoding='utf-8', newline='')))
result = {}
for origin, destination in [(3222, 400), (971, 916), (3393, 3394)]:
    matches = [row for row in rows if int(row['origin']) == origin and int(row['destination']) == destination]
    target = result[f'{origin}:{destination}'] = {}
    for label, select in [('fresh', lambda row: int(row['complete_origin'])),
            ('initial', lambda row: int(row['initial'])),
            ('late_observed', lambda row: not int(row['complete_origin']) and not int(row['initial']))]:
        group = [row for row in matches if select(row)]
        completed = [row for row in group if row['fate'] == 'delivered' and int(row['location']) == destination]
        pending = [row for row in group if row['fate'] == 'pending']
        target[label] = dict(fates=collections.Counter(row['fate'] for row in group),
            completed_observed_ticks=distribution([int(row['at']) - int(row['born']) for row in completed]),
            completed_metrics={key: distribution([int(row[key]) for row in completed]) for key in
                ['riding_ticks', 'waiting_ticks', 'origin_waiting_ticks', 'transfer_waiting_ticks', 'boardings', 'revisits']},
            completed_services=collections.Counter(row['services'] for row in completed),
            pending_observed_elapsed_ticks=distribution([int(row['at']) - int(row['born']) for row in pending]),
            pending_maximum_wait=distribution([int(row['maximum_wait']) for row in pending]),
            longest_wait_examples=sorted(group, key=lambda row: -int(row['waiting_ticks']))[:3])
    target_events = [row for row in events if int(row['origin']) == origin and int(row['destination']) == destination]
    target['queried_events'] = dict(events=collections.Counter(row['event'] for row in target_events),
        candidate_reasons=collections.Counter(row['reason'] for row in target_events if row['event'] == 'candidate'),
        actual_boarding_services=collections.Counter(row['actual_service'] for row in target_events if row['event'] == 'board'))
output.write_text(json.dumps(dict(target_ods=result, limitations='One midpoint representative per target packet, not passenger-weighted. Fresh, initial and late-observed samples are separate. Pending and lost are excluded from completed durations. Candidate reasons are auxiliary wrapper classifications of queried cohorts, may repeat cached opportunities and do not enumerate every train arrival.'), indent=2) + '\n', encoding='utf-8')
