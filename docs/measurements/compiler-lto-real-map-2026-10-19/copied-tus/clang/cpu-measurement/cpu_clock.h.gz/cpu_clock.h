#pragma once
#include <windows.h>
#include <chrono>
struct MeasurementCpuClock {
    using rep = int64_t;
    using period = std::nano;
    using duration = std::chrono::nanoseconds;
    using time_point = std::chrono::time_point<MeasurementCpuClock>;
    static constexpr bool is_steady = true;
    static uint64_t Value(FILETIME value) { return (uint64_t(value.dwHighDateTime) << 32) | value.dwLowDateTime; }
    static time_point now() {
        FILETIME creation{}, exit{}, kernel{}, user{};
        if (!GetThreadTimes(GetCurrentThread(), &creation, &exit, &kernel, &user)) std::abort();
        return time_point(duration((Value(kernel) + Value(user)) * 100));
    }
    static uint64_t process_us() {
        FILETIME creation{}, exit{}, kernel{}, user{};
        if (!GetProcessTimes(GetCurrentProcess(), &creation, &exit, &kernel, &user)) std::abort();
        return (Value(kernel) + Value(user)) / 10;
    }
};
