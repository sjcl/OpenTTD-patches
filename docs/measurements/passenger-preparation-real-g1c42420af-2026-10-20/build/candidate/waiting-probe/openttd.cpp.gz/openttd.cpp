/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file openttd.cpp Functions related to starting OpenTTD. */

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/stdafx.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/build-preparation/waiting-probe/waiting.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/passenger_journey_active.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/passenger_service_database.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/passenger_precomputed_gui.h"

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/blitter/factory.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/sound/sound_driver.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/music/music_driver.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/video/video_driver.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/mixer.h"

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/fontcache.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/error.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/error_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/gui.h"

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/base_media_base.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/base_media_graphics.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/base_media_music.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/base_media_sounds.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/sl/saveload.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/sl/saveload_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/company_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/company_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/company_gui.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/command_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/command_log.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/news_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/fios.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/load_check.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/aircraft.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/roadveh.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/train.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/ship.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/console_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/screenshot.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/network/network.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/network/network_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/ai/ai.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/ai/ai_config.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/settings_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/genworld.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/progress.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/strings_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/date_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/vehicle_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/gamelog.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/animated_tile_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/roadstop_base.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/elrail_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/rev.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/highscore.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/station_base.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/crashlog.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/engine_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/engine_override.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/core/random_func.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/rail_gui.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/road_gui.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/core/backup_type.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/hotkeys.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/newgrf.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/newgrf_commons.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/misc/getoptdata.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/game/game.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/game/game_config.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/town.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/subsidy_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/gfx_layout.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/viewport_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/viewport_sprite_sorter.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/framerate_type.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/programmable_signals.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/smallmap_gui.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/viewport_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/thread.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/bridge_signal_map.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/zoning.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/cargopacket.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/string_func_extra.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/industry.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/network/network_gui.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/cargopacket.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/core/checksum_func.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/tbtr_template_vehicle_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/debug_desync.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/event_logs.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/worker_thread.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/scope_info.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/network/network_survey.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/time_chrono.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/timer/timer.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/timer/timer_game_realtime.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/timer/timer_game_tick.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/social_integration.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/network/network_sync.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/plans_func.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/misc_cmd.h"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/core/string_consumer.hpp"
#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/session_stats.h"

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/linkgraph/linkgraphschedule.h"

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/3rdparty/cpp-btree/btree_set.h"

#include <atomic>
#include <mutex>

#include <system_error>

#include "table/strings.h"

#ifdef __EMSCRIPTEN__
#	include <emscripten.h>
#	include <emscripten/html5.h>
#endif

#include "C:/Users/bebe/.codex/worktrees/ba19/OpenTTD-patches/src/safeguards.h"

void CallLandscapeTick();
void IncreaseDate();
void IncreaseCalendarDate();
void DoPaletteAnimations();
void MusicLoop();
void CallWindowGameTickEvent();
bool HandleBootstrap();
void OnTick_Companies(bool main_tick);
void OnTick_LinkGraph();

FiosNumberedSaveName &GetAutoSaveFiosNumberedSaveName();
FiosNumberedSaveName &GetLongTermAutoSaveFiosNumberedSaveName();

extern Company *DoStartupNewCompany(bool is_ai, CompanyID company = CompanyID::Invalid());
extern void OSOpenBrowser(const std::string &url);
extern void ShowOSErrorBox(std::string_view buf, bool system);
[[noreturn]] extern void DoOSAbort();
extern std::string _config_file;
extern uint64_t _station_tile_cache_hash;
extern uint32_t _engine_seed;

bool _save_config = false;
bool _request_newgrf_scan = false;
NewGRFScanCallback *_request_newgrf_scan_callback = nullptr;

SimpleChecksum64 _state_checksum;

std::mutex _music_driver_mutex;
static std::string _music_driver_params;
static std::atomic<bool> _music_inited;

std::mutex _sound_driver_mutex;
static std::string _sound_driver_params;
static std::atomic<bool> _sound_inited;

/**
 * Error handling for fatal user errors.
 * @param str the string to print.
 * @attention Function does not return.
 */
void UserErrorI(const std::string &str)
{
	ShowOSErrorBox(str, false);
	if (VideoDriver::GetInstance() != nullptr) VideoDriver::GetInstance()->Stop();

#ifdef __EMSCRIPTEN__
	emscripten_exit_pointerlock();
	/* In effect, the game ends here. As emscripten_set_main_loop() caused
	 * the stack to be unwound, the code after MainLoop() in
	 * openttd_main() is never executed. */
	EM_ASM(if (window["openttd_abort"]) openttd_abort());
#endif

	_exit(1);
}

/**
 * Error handling for fatal non-user errors.
 * @param str the string to print.
 * @attention Function does not return.
 */
void FatalErrorI(const std::string &str)
{
	if (CrashLog::HaveAlreadyCrashed()) DoOSAbort();

	if (VideoDriver::GetInstance() == nullptr || VideoDriver::GetInstance()->HasGUI()) {
		ShowOSErrorBox(str, true);
	}

	/* Set the error message for the crash log and then invoke it. */
	CrashLog::SetErrorMessage(str.c_str());
	DoOSAbort();
}

/**
 * Show the help message when someone passed a wrong parameter.
 */
static void ShowHelp()
{
	format_buffer msg;

	msg.format("OpenTTD {}\n", _openttd_revision);
	msg.append("\n"
		"\n"
		"Command line options:\n"
		"  -v drv              = Set video driver (see below)\n"
		"  -s drv              = Set sound driver (see below)\n"
		"  -m drv              = Set music driver (see below)\n"
		"  -b drv              = Set the blitter to use (see below)\n"
		"  -r res              = Set resolution (for instance 800x600)\n"
		"  -h                  = Display this help text\n"
		"  -t year             = Set starting year\n"
		"  -d [[fac=]lvl[,...]]= Debug mode\n"
		"  -e                  = Start Editor\n"
		"  -g [savegame|scenario|heightmap] = Start new/savegame/scenario/heightmap immediately\n"
		"  -G seed             = Set random seed\n"
		"  -n host[:port][#company]= Join network game\n"
		"  -p password         = Password to join server\n"
		"  -P password         = Password to join company\n"
		"  -D [host][:port]    = Start dedicated server\n"
#if !defined(_WIN32)
		"  -f                  = Fork into the background (dedicated only)\n"
#endif
		"  -I graphics_set     = Force the graphics set (see below)\n"
		"  -S sounds_set       = Force the sounds set (see below)\n"
		"  -M music_set        = Force the music set (see below)\n"
		"  -c config_file      = Use 'config_file' instead of 'openttd.cfg'\n"
		"  -x                  = Never save configuration changes to disk\n"
		"  -X                  = Don't use global folders to search for files\n"
		"  -q savegame         = Write some information about the savegame and exit\n"
		"  -Q                  = Don't scan for/load NewGRF files on startup\n"
		"  -QQ                 = Disable NewGRF scanning/loading entirely\n"
		"  -Z                  = Write detailed version information and exit\n"
		"\n");

	/* List the graphics packs */
	BaseGraphics::GetSetsList(msg);

	/* List the sounds packs */
	BaseSounds::GetSetsList(msg);

	/* List the music packs */
	BaseMusic::GetSetsList(msg);

	/* List the drivers */
	DriverFactoryBase::GetDriversInfo(msg);

	/* List the blitters */
	BlitterFactory::GetBlittersInfo(msg);

	/* List the debug facilities. */
	DumpDebugFacilityNames(msg);

	/* We need to initialize the AI, so it finds the AIs */
	AI::Initialize();
	msg.append(AI::GetConsoleList(true));
	AI::Uninitialize(true);

	/* We need to initialize the GameScript, so it finds the GSs */
	Game::Initialize();
	msg.append(Game::GetConsoleList(true));
	Game::Uninitialize(true);

	/* ShowInfo put output to stderr, but version information should go
	 * to stdout; this is the only exception */
#if !defined(_WIN32)
	msg.push_back('\n');
	fwrite(msg.data(), 1, msg.size(), stdout);
#else
	ShowInfoI(msg);
#endif
}

static void WriteSavegameInfo(const char *name)
{
	extern SaveLoadVersion _sl_version;
	extern std::string _sl_xv_version_label;
	uint32_t last_ottd_rev = 0;
	uint8_t ever_modified = 0;
	bool removed_newgrfs = false;

	GamelogInfo(_load_check_data.gamelog_actions, &last_ottd_rev, &ever_modified, &removed_newgrfs);

	format_buffer buffer;
	buffer.format("Name:         {}\n", name);
	const char *type = "";
	extern bool _sl_is_faked_ext;
	extern bool _sl_is_ext_version;
	if (_sl_is_faked_ext) {
		type = " (fake extended)";
	} else if (_sl_is_ext_version) {
		type = " (extended)";
	}
	buffer.format("Savegame ver: {}{}\n", _sl_version, type);
	if (!_sl_xv_version_label.empty()) {
		buffer.format("    Version label: {}\n", _sl_xv_version_label);
	}
	if (SlXvGetUpstreamVersion() != SL_MIN_VERSION) {
		buffer.format("    Upstream version: {}\n", SlXvGetUpstreamVersion());
	}
	for (size_t i = 0; i < XSLFI_SIZE; i++) {
		if (_sl_xv_feature_versions[i] > 0) {
			buffer.format("    Feature: {} = {}\n", SlXvGetFeatureName((SlXvFeatureIndex) i), _sl_xv_feature_versions[i]);
		}
	}
	buffer.format("NewGRF ver:   0x{:08X}\n", last_ottd_rev);
	buffer.format("Modified:     {}\n", ever_modified);

	if (removed_newgrfs) {
		buffer.append("NewGRFs have been removed\n");
	}

	buffer.append("NewGRFs:\n");
	if (_load_check_data.HasNewGrfs()) {
		for (const auto &c : _load_check_data.grfconfig) {
			buffer.format("{} {} {}\n", c->ident.grfid, c->flags.Test(GRFConfigFlag::Compatible) ? c->original_md5sum : c->ident.md5sum, c->filename);
		}
	}

	/* ShowInfo put output to stderr, but version information should go
	 * to stdout; this is the only exception */
#if !defined(_WIN32)
	buffer.push_back('\n');
	fwrite(buffer.data(), 1, buffer.size(), stdout);
#else
	ShowInfoI(buffer);
#endif
}

static void WriteSavegameDebugData(const char *name)
{
	format_buffer out;

	if (!StrEmpty(name)) out.format("Name: {}\n", name);
	auto write_box = [&](std::string_view msg) {
		auto top = out.append_as_span(msg.size() + 4);
		std::fill(top.begin(), top.end(), '#');
		out.format("\n# {} #\n", msg);
		auto bottom = out.append_as_span(msg.size() + 4);
		std::fill(bottom.begin(), bottom.end(), '#');
		out.push_back('\n');
	};
	if (_load_check_data.debug_log_data.size()) {
		write_box(fmt::format("Start of debug log data ({} bytes)", _load_check_data.debug_log_data.size()));
		out.append(_load_check_data.debug_log_data);
		if (!_load_check_data.debug_log_data.empty() && _load_check_data.debug_log_data.back() != '\n') out.push_back('\n');
		write_box("End of debug log data");
	} else {
		out.format("No debug log data in savegame\n");
	}
	if (_load_check_data.debug_config_data.size()) {
		write_box(fmt::format("Start of debug config data ({} bytes)", _load_check_data.debug_config_data.size()));
		out.append(_load_check_data.debug_config_data);
		if (!_load_check_data.debug_config_data.empty() && _load_check_data.debug_config_data.back() != '\n') out.push_back('\n');
		write_box("End of debug config data");
	} else {
		out.format("No debug config data in savegame\n");
	}

	/* ShowInfo put output to stderr, but version information should go
	 * to stdout; this is the only exception */
#if !defined(_WIN32)
	out.push_back('\n');
	fwrite(out.data(), 1, out.size(), stdout);
#else
	ShowInfoI(out);
#endif
}


/**
 * Extract the resolution from the given string and store
 * it in the 'res' parameter.
 * @param res variable to store the resolution in.
 * @param s   the string to decompose.
 */
static void ParseResolution(Dimension &res, std::string_view s)
{
	StringConsumer consumer(s);
	auto width = consumer.TryReadIntegerBase<uint>(10);
	auto valid = consumer.ReadIf("x");
	auto height = consumer.TryReadIntegerBase<uint>(10);
	if (!width.has_value() || !valid || !height.has_value() || consumer.AnyBytesLeft()) {
		ShowInfo("Invalid resolution '{}'", s);
		return;
	}

	res.width  = std::max<uint>(*width, 64);
	res.height = std::max<uint>(*height, 64);
}


/**
 * Uninitializes drivers, frees allocated memory, cleans pools, ...
 * Generally, prepares the game for shutting down
 */
static void ShutdownGame()
{
	IConsoleFree();

	if (_network_available) NetworkShutDown(); // Shut down the network and close any open connections

	SocialIntegration::Shutdown();
	DriverFactoryBase::ShutdownDrivers();

	UnInitWindowSystem();

	/* stop the scripts */
	AI::Uninitialize(false);
	Game::Uninitialize(false);

	/* Uninitialize variables that are allocated dynamically */
	GamelogReset();

	LinkGraphSchedule::Clear();
	ClearTraceRestrictMapping();
	ClearBridgeSimulatedSignalMapping();
	ClearBridgeSignalStyleMapping();
	ClearCargoPacketDeferredPayments();
	ClearTemplateReplacements();
	PoolBase::Clean(PT_ALL);
	_passenger_od_revision = 0;
	_passenger_od_stats = {};

	FreeSignalPrograms();
	FreeSignalDependencies();

	extern void ClearNewSignalStyleMapping();
	ClearNewSignalStyleMapping();

	extern void ClearAllSignalSpeedRestrictions();
	ClearAllSignalSpeedRestrictions();

	ClearZoningCaches();
	InvalidatePlanCaches();
	ClearOrderDestinationRefcountMap();
	TraceRestrictClearRecentSlotsAndCounters();

	/* No NewGRFs were loaded when it was still bootstrapping. */
	if (_game_mode != GameMode::Bootstrap) ResetNewGRFData();

	FontCache::UninitializeFontCaches();

	ViewportMapClearTunnelCache();
	InvalidateVehicleTickCaches();
	InvalidateEffectVehicleTickCache();
	ClearVehicleTickCaches();
	InvalidateTemplateReplacementImages();
	ResetDisasterVehicleTargeting();
	ClearCommandLog();
	ClearCommandQueue();
	ClearSpecialEventsLog();
	ClearDesyncMsgLog();

	extern void UninitializeCompanies();
	UninitializeCompanies();

	_loaded_local_company = COMPANY_SPECTATOR;
	_game_events_since_load = (GameEventFlags) 0;
	_game_events_overall = (GameEventFlags) 0;
	_game_load_cur_date_ymd = { EconTime::Year{0}, 0, 0 };
	_game_load_date_fract = 0;
	_game_load_tick_skip_counter = 0;
	_game_load_state_ticks = StateTicks{0};
	_game_load_time = 0;
	_extra_aspects = 0;
	_aspect_cfg_hash = 0;
	_station_tile_cache_hash = 0;
	_engine_seed = 0;
	InitGRFGlobalVars();
	_loadgame_DBGL_data.clear();
	_loadgame_DBGC_data.clear();
}

/**
 * Load the introduction game.
 * @param load_newgrfs Whether to load the NewGRFs or not.
 */
static void LoadIntroGame(bool load_newgrfs = true)
{
	UnshowCriticalError();
	for (Window *w : Window::Iterate()) {
		w->Close();
	}

	_game_mode = GameMode::Menu;

	if (load_newgrfs) ResetGRFConfig(false);

	/* Setup main window */
	ResetWindowSystem();
	SetupColoursAndInitialWindow();

	/* Load the default opening screen savegame */
	if (SaveOrLoad("opntitle.dat", SaveLoadOperation::Load, DetailedFileType::GameFile, Subdirectory::Baseset) != SaveLoadResult::Ok) {
		GenerateWorld(GWM_EMPTY, 64, 64); // if failed loading, make empty world.
		SetLocalCompany(COMPANY_SPECTATOR);
	} else {
		SetLocalCompany(CompanyID::Begin());
	}

	FixTitleGameZoom();
	_pause_mode = {};
	_pause_countdown = 0;
	_cursor.fix_at = false;

	CheckForMissingGlyphs();

	MusicLoop(); // ensure music is correct
}

void MakeNewgameSettingsLive()
{
	for (CompanyID c = CompanyID::Begin(); c < MAX_COMPANIES; ++c) {
		_settings_game.script_config.ai[c].reset();
	}
	_settings_game.script_config.game.reset();

	/* Copy newgame settings to active settings.
	 * Also initialise old settings needed for savegame conversion. */
	_settings_game = _settings_newgame;
	_settings_time = _settings_game.game_time = (TimeSettings)_settings_client.gui;
	_old_vds = _settings_client.company.vehicle;

	/* Unconditionally set freeform_edges, this is set to false by vanilla infinite water, so might end up false in shared config files. */
	_settings_game.construction.freeform_edges = true;

	UpdateEffectiveDayLengthFactor();
}

void OpenBrowser(const std::string &url)
{
	/* Make sure we only accept urls that are sure to open a browser. */
	if (url.starts_with("http://") || url.starts_with("https://")) {
		OSOpenBrowser(url);
	}
}

/** Callback structure of statements to be executed after the NewGRF scan. */
struct AfterNewGRFScan : NewGRFScanCallback {
	CalTime::Year startyear = CalTime::INVALID_YEAR; ///< The start year.
	uint32_t generation_seed = GENERATE_NEW_SEED; ///< Seed for the new game.
	std::string dedicated_host;                   ///< Hostname for the dedicated server.
	uint16_t dedicated_port = 0;                  ///< Port for the dedicated server.
	std::string connection_string;                ///< Information about the server to connect to
	std::string join_server_password;             ///< The password to join the server with.
	std::string join_company_password;            ///< The password to join the company with.
	bool save_config = true;                      ///< The save config setting.

	/**
	 * Create a new callback.
	 */
	AfterNewGRFScan()
	{
		/* Visual C++ 2015 fails compiling this line (AfterNewGRFScan::generation_seed undefined symbol)
		 * if it's placed outside a member function, directly in the struct body. */
		static_assert(sizeof(generation_seed) == sizeof(_settings_game.game_creation.generation_seed));
	}

	void OnNewGRFsScanned() override
	{
		ResetGRFConfig(false);

		TarScanner::DoScan(TarScanner::Mode::Scenario);

		AI::Initialize();
		Game::Initialize();

		/* We want the new (correct) NewGRF count to survive the loading. */
		uint last_newgrf_count = _settings_client.gui.last_newgrf_count;
		LoadFromConfig();
		_settings_client.gui.last_newgrf_count = last_newgrf_count;
		/* Since the default for the palette might have changed due to
		 * reading the configuration file, recalculate that now. */
		UpdateNewGRFConfigPalette();

		Game::Uninitialize(true);
		AI::Uninitialize(true);
		LoadFromHighScore();
		LoadHotkeysFromConfig();
		WindowDesc::LoadFromConfig();

		/* We have loaded the config, so we may possibly save it. */
		_save_config = save_config;

		/* restore saved music and effects volumes */
		MusicDriver::GetInstance()->SetVolume(_settings_client.music.music_vol);
		SetEffectVolume(_settings_client.music.effect_vol);

		if (startyear != CalTime::INVALID_YEAR) IConsoleSetSetting("game_creation.starting_year", startyear.base());
		_settings_newgame.game_creation.generation_seed = generation_seed;

		if (!dedicated_host.empty()) {
			_network_bind_list.clear();
			_network_bind_list.emplace_back(dedicated_host);
		}
		if (dedicated_port != 0) _settings_client.network.server_port = dedicated_port;

		/* initialize the ingame console */
		IConsoleInit();
		InitializeGUI();
		IConsoleCmdExec("exec scripts/autoexec.scr 0");

		/* Make sure _settings is filled with _settings_newgame if we switch to a game directly */
		if (_switch_mode != SwitchMode::None) MakeNewgameSettingsLive();

		if (_network_available && !connection_string.empty()) {
			LoadIntroGame();
			_switch_mode = SwitchMode::None;

			NetworkClientConnectGame(connection_string, COMPANY_NEW_COMPANY, join_server_password, join_company_password);
		}

		/* After the scan we're not used anymore. */
		delete this;
	}
};

void PostMainLoop()
{
	WaitTillSaved();

	/* only save config if we have to */
	if (_save_config) {
		SaveToConfig(STCF_ALL);
		SaveHotkeysToConfig();
		WindowDesc::SaveToConfig();
		SaveToHighScore();
	}

	/* Reset windowing system, stop drivers, free used memory, ... */
	ShutdownGame();
}

#if defined(UNIX)
extern void DedicatedFork();
#endif

/**
 * Create all the options that OpenTTD supports. Each option is
 * always a single character with no, an optional or a required value.
 * @return The available options.
 */
static std::vector<OptionData> CreateOptions()
{
	std::vector<OptionData> options;
	/* Options that require a parameter. */
	for (char c : "GIMSbcmnpqrstv") options.push_back({ .type = ODF_HAS_VALUE, .id = c, .shortname = c });

	/* Options with an optional parameter. */
	for (char c : "Ddg") options.push_back({ .type = ODF_OPTIONAL_VALUE, .id = c, .shortname = c });

	/* Options without a parameter. */
	for (char c : "QXehx") options.push_back({ .type = ODF_NO_VALUE, .id = c, .shortname = c });
#if !defined(_WIN32)
	options.push_back({ .type = ODF_NO_VALUE, .id = 'f', .shortname = 'f' });
#endif

	/* Non-upstream options */
	for (char c : "PKJ") options.push_back({ .type = ODF_HAS_VALUE, .id = c, .shortname = c });
	for (char c : "Z") options.push_back({ .type = ODF_NO_VALUE, .id = c, .shortname = c });

	return options;
}

/**
 * Main entry point for this lovely game.
 * @param arguments The command line arguments passed to the application.
 * @return 0 when there is no error.
 */
int openttd_main(std::span<char * const> arguments)
{
	SetSelfAsMainThread();
	PerThreadSetup(false);
	SlXvSetStaticCurrentVersions();

	_game_session_stats.start_time = std::chrono::steady_clock::now();
	_game_session_stats.savegame_size = std::nullopt;

	std::string musicdriver;
	std::string sounddriver;
	std::string videodriver;
	std::string blitter;
	std::string graphics_set;
	std::string sounds_set;
	std::string music_set;
	Dimension resolution = {0, 0};
	std::unique_ptr<AfterNewGRFScan> scanner = std::make_unique<AfterNewGRFScan>();
	bool dedicated = false;
	bool only_local_path = false;

	extern bool _dedicated_forks;
	_dedicated_forks = false;

	_game_mode = GameMode::Menu;
	_switch_mode = SwitchMode::Menu;

	auto options = CreateOptions();
	GetOptData mgo(arguments.subspan(1), options);

	int i;
	while ((i = mgo.GetOpt()) != -1) {
		switch (i) {
		case 'I': graphics_set = mgo.opt; break;
		case 'S': sounds_set = mgo.opt; break;
		case 'M': music_set = mgo.opt; break;
		case 'm': musicdriver = mgo.opt; break;
		case 's': sounddriver = mgo.opt; break;
		case 'v': videodriver = mgo.opt; break;
		case 'b': blitter = mgo.opt; break;
		case 'D':
			musicdriver = "null";
			sounddriver = "null";
			videodriver = "dedicated";
			blitter = "null";
			dedicated = true;
			SetDebugString("net=3", [](std::string_view err) { ShowInfoI(err); });
			if (mgo.opt != nullptr) {
				scanner->dedicated_host = ParseFullConnectionString(mgo.opt, scanner->dedicated_port);
			}
			break;
		case 'f': _dedicated_forks = true; break;
		case 'n':
			scanner->connection_string = mgo.opt; // host:port#company parameter
			break;
		case 'p':
			scanner->join_server_password = mgo.opt;
			break;
		case 'P':
			scanner->join_company_password = mgo.opt;
			break;
		case 'r': ParseResolution(resolution, mgo.opt); break;
		case 't':
			if (auto value = ParseInteger(mgo.opt); value.has_value()) {
				scanner->startyear = CalTime::Year(*value);
			} else {
				fmt_print_no_system_error(stderr, "Invalid start year: {}\n", mgo.opt);
			}
			break;
		case 'd': {
#if defined(_WIN32)
				CreateConsole();
#endif
				if (mgo.opt != nullptr) SetDebugString(mgo.opt, [](std::string_view err) { ShowInfoI(err); });
				break;
			}
		case 'e':
			/* Allow for '-e' before or after '-g'. */
			switch (_switch_mode) {
				case SwitchMode::Menu: _switch_mode = SwitchMode::Editor; break;
				case SwitchMode::LoadGame: _switch_mode = SwitchMode::LoadScenario; break;
				case SwitchMode::StartHeightmap: _switch_mode = SwitchMode::LoadHeightmap; break;
				default: break;
			}
			break;
		case 'g':
			if (mgo.opt != nullptr) {
				_file_to_saveload.name = mgo.opt;

				/* if the file doesn't exist or it is not a valid savegame, let the saveload code show an error */
				std::string extension;
				auto t = _file_to_saveload.name.find_last_of('.');
				if (t != std::string::npos) {
					extension = _file_to_saveload.name.substr(t);
				}
				FiosType ft = FiosGetSavegameListCallback(SaveLoadOperation::Load, _file_to_saveload.name, extension.c_str(), nullptr, nullptr);
				if (ft == FIOS_TYPE_INVALID) {
					ft = FiosGetScenarioListCallback(SaveLoadOperation::Load, _file_to_saveload.name, extension.c_str(), nullptr, nullptr);
				}
				if (ft == FIOS_TYPE_INVALID) {
					ft = FiosGetHeightmapListCallback(SaveLoadOperation::Load, _file_to_saveload.name, extension.c_str(), nullptr, nullptr);
				}

				/* Allow for '-e' before or after '-g'. */
				switch (ft.abstract) {
					case AbstractFileType::Savegame: _switch_mode = (_switch_mode == SwitchMode::Editor ? SwitchMode::LoadScenario : SwitchMode::LoadGame); break;
					case AbstractFileType::Scenario: _switch_mode = (_switch_mode == SwitchMode::Editor ? SwitchMode::LoadScenario : SwitchMode::LoadGame); break;
					case AbstractFileType::Heightmap: _switch_mode = (_switch_mode == SwitchMode::Editor ? SwitchMode::LoadHeightmap : SwitchMode::StartHeightmap); break;
					default: break;
				}

				_file_to_saveload.SetMode(ft, SaveLoadOperation::Load);
				break;
			}

			_switch_mode = SwitchMode::NewGame;
			/* Give a random map if no seed has been given */
			if (scanner->generation_seed == GENERATE_NEW_SEED) {
				scanner->generation_seed = InteractiveRandom();
			}
			break;
		case 'q':
		case 'K': {
			DeterminePaths(arguments[0], only_local_path);
			if (StrEmpty(mgo.opt)) {
				return 1;
			}

			char title[80];
			title[0] = '\0';
			FiosGetSavegameListCallback(SaveLoadOperation::Load, mgo.opt, strrchr(mgo.opt, '.'), title, lastof(title));

			_load_check_data.Clear();
			if (i == 'K') _load_check_data.want_debug_data = true;
			_load_check_data.want_grf_compatibility = false;
			SaveLoadResult res = SaveOrLoad(mgo.opt, SaveLoadOperation::Check, DetailedFileType::GameFile, Subdirectory::Save, false);
			if (res != SaveLoadResult::Ok || _load_check_data.HasErrors()) {
				fprintf(stderr, "Failed to open savegame\n");
				if (_load_check_data.HasErrors()) {
					InitializeLanguagePacks(); // A language pack is needed for GetString()
					format_buffer buf;
					AppendStringInPlace(buf, _load_check_data.error, _load_check_data.error_msg);
					buf.push_back('\n');
					fwrite(buf.data(), 1, buf.size(), stderr);
				}
				return 1;
			}

			if (i == 'q') {
				WriteSavegameInfo(title);
			} else {
				WriteSavegameDebugData(title);
			}
			return 0;
		}
		case 'Q': {
			extern int _skip_all_newgrf_scanning;
			_skip_all_newgrf_scanning += 1;
			break;
		}
		case 'G':
			if (auto value = ParseInteger<uint32_t>(mgo.opt); value.has_value()) {
				scanner->generation_seed = *value;
			} else {
				fmt_print_no_system_error(stderr, "Invalid generation seed: {}\n", mgo.opt);
			}
			break;
		case 'c': _config_file = mgo.opt; break;
		case 'x': scanner->save_config = false; break;
		case 'J':
			if (auto value = ParseInteger<uint32_t>(mgo.opt); value.has_value()) {
				_quit_after_days = *value;
			} else {
				fmt_print_no_system_error(stderr, "Invalid quit after days: {}\n", mgo.opt);
			}
			break;
		case 'Z': {
			format_buffer buffer;
			CrashLog::VersionInfoLog(buffer);
			fwrite(buffer.data(), 1, buffer.size(), stdout);
			return 0;
		}
		case 'X': only_local_path = true; break;
		case 'h': break; // handled below
		}
		if (i == 'h' || i == -2) break;
	}

	if (i == 'h' || i == -2 || !mgo.arguments.empty()) {
		/* Either the user typed '-h', they made an error, or they added unrecognized command line arguments.
		 * In all cases, print the help, and exit.
		 *
		 * The next two functions are needed to list the graphics sets. We can't do them earlier
		 * because then we cannot show it on the debug console as that hasn't been configured yet. */
		DeterminePaths(arguments[0], only_local_path);
		TarScanner::DoScan(TarScanner::Mode::Baseset);
		BaseGraphics::FindSets();
		BaseSounds::FindSets();
		BaseMusic::FindSets();
		ShowHelp();

		/* Return zero when asked to print help, and 1 for all other cases. */
		if (i == 'h') return 0;
		return 1;
	}

	DeterminePaths(arguments[0], only_local_path);
	TarScanner::DoScan(TarScanner::Mode::Baseset);

	if (dedicated) Debug(net, 3, "Starting dedicated server, version {}", _openttd_revision);
	if (_dedicated_forks && !dedicated) _dedicated_forks = false;

#if defined(UNIX)
	/* We must fork here, or we'll end up without some resources we need (like sockets) */
	if (_dedicated_forks) DedicatedFork();
#endif

	LoadFromConfig(true);

	if (resolution.width != 0) _cur_resolution = resolution;

	/* Limit width times height times bytes per pixel to fit a 32 bit
	 * integer, This way all internal drawing routines work correctly.
	 * A resolution that has one component as 0 is treated as a marker to
	 * auto-detect a good window size. */
	_cur_resolution.width  = std::min(_cur_resolution.width, UINT16_MAX / 2u);
	_cur_resolution.height = std::min(_cur_resolution.height, UINT16_MAX / 2u);

	/* Assume the cursor starts within the game as not all video drivers
	 * get an event that the cursor is within the window when it is opened.
	 * Saying the cursor is there makes no visible difference as it would
	 * just be out of the bounds of the window. */
	_cursor.in_window = true;

	/* enumerate language files */
	InitializeLanguagePacks();

	/* Initialize the font cache */
	FontCache::LoadFontCaches(FONTSIZES_REQUIRED);

	/* This must be done early, since functions use the SetWindowDirty* calls */
	InitWindowSystem();

	BaseGraphics::FindSets();
	bool valid_graphics_set;
	if (!graphics_set.empty()) {
		valid_graphics_set = BaseGraphics::SetSetByName(graphics_set);
	} else if (BaseGraphics::ini_data.shortname != 0) {
		graphics_set = BaseGraphics::ini_data.name;
		valid_graphics_set = BaseGraphics::SetSetByShortname(BaseGraphics::ini_data.shortname);
		if (valid_graphics_set && !BaseGraphics::ini_data.extra_params.empty()) {
			GRFConfig &extra_cfg = BaseGraphics::GetUsedSet()->GetOrCreateExtraConfig();
			if (extra_cfg.IsCompatible(BaseGraphics::ini_data.extra_version)) {
				extra_cfg.SetParams(BaseGraphics::ini_data.extra_params);
			}
		}
	} else if (!BaseGraphics::ini_data.name.empty()) {
		graphics_set = BaseGraphics::ini_data.name;
		valid_graphics_set = BaseGraphics::SetSetByName(BaseGraphics::ini_data.name);
	} else {
		valid_graphics_set = true;
		BaseGraphics::SetSet(nullptr); // ignore error, continue to bootstrap GUI
	}
	if (!valid_graphics_set) {
		BaseGraphics::SetSet(nullptr);

		ErrorMessageData msg(GetEncodedString(STR_CONFIG_ERROR), GetEncodedString(STR_CONFIG_ERROR_INVALID_BASE_GRAPHICS_NOT_FOUND, graphics_set));
		ScheduleErrorMessage(msg);
	}

	/* Initialize game palette */
	GfxInitPalettes();

	Debug(misc, 1, "Loading blitter...");
	if (blitter.empty() && !_ini_blitter.empty()) blitter = _ini_blitter;
	_blitter_autodetected = blitter.empty();
	/* Activate the initial blitter.
	 * This is only some initial guess, after NewGRFs have been loaded SwitchNewGRFBlitter may switch to a different one.
	 *  - Never guess anything, if the user specified a blitter. (_blitter_autodetected)
	 *  - Use 32bpp blitter if baseset or 8bpp-support settings says so.
	 *  - Use 8bpp blitter otherwise.
	 */
	if (!_blitter_autodetected ||
			(_support8bpp != Support8bpp::None && (BaseGraphics::GetUsedSet() == nullptr || BaseGraphics::GetUsedSet()->blitter == BLT_8BPP)) ||
			BlitterFactory::SelectBlitter("32bpp-anim") == nullptr) {
		if (BlitterFactory::SelectBlitter(blitter) == nullptr) {
			blitter.empty() ?
				UserError("Failed to autoprobe blitter") :
				UserError("Failed to select requested blitter '{}'; does it exist?", blitter.c_str());
		}
	}

	if (videodriver.empty() && !_ini_videodriver.empty()) videodriver = _ini_videodriver;
	DriverFactoryBase::SelectDriver(videodriver, Driver::Type::Video);

	InitializeSpriteSorter();

	/* Initialize the zoom level of the screen to normal */
	_screen.zoom = ZoomLevel::Min;

	/* The video driver is now selected, now initialise GUI zoom */
	AdjustGUIZoom(AGZM_STARTUP);

	SocialIntegration::Initialize();
	NetworkStartUp(); // initialize network-core

	if (!HandleBootstrap()) {
		ShutdownGame();
		return 0;
	}

#ifdef DEDICATED
	/* Pre-initialise autosave sequence for dedicated servers (for autosave copy on crash) */
	GetAutoSaveFiosNumberedSaveName();
#endif

	VideoDriver::GetInstance()->ClaimMousePointer();

	BaseSounds::FindSets();
	if (sounds_set.empty() && !BaseSounds::ini_set.empty()) sounds_set = BaseSounds::ini_set;
	if (!BaseSounds::SetSetByName(sounds_set)) {
		if (sounds_set.empty() || !BaseSounds::SetSet({})) {
			UserError("Failed to find a sounds set. Please acquire a sounds set for OpenTTD. See section 1.4 of README.md.");
		} else {
			ErrorMessageData msg(GetEncodedString(STR_CONFIG_ERROR), GetEncodedString(STR_CONFIG_ERROR_INVALID_BASE_SOUNDS_NOT_FOUND, sounds_set));
			ScheduleErrorMessage(msg);
		}
	}

	BaseMusic::FindSets();
	if (music_set.empty() && !BaseMusic::ini_set.empty()) music_set = BaseMusic::ini_set;
	if (!BaseMusic::SetSetByName(music_set)) {
		if (music_set.empty() || !BaseMusic::SetSet({})) {
			UserError("Failed to find a music set. Please acquire a music set for OpenTTD. See section 1.4 of README.md.");
		} else {
			ErrorMessageData msg(GetEncodedString(STR_CONFIG_ERROR), GetEncodedString(STR_CONFIG_ERROR_INVALID_BASE_MUSIC_NOT_FOUND, music_set));
			ScheduleErrorMessage(msg);
		}
	}

	if (sounddriver.empty() && !_ini_sounddriver.empty()) sounddriver = _ini_sounddriver;
	_sound_driver_params = std::move(sounddriver);
	if (musicdriver.empty() && !_ini_musicdriver.empty()) musicdriver = _ini_musicdriver;
	_music_driver_params = std::move(musicdriver);

	if (_sound_driver_params.empty() && BaseSounds::GetUsedSet()->name == "NoSound" && _music_driver_params.empty() && BaseMusic::GetUsedSet()->name == "NoMusic") {
		Debug(driver, 1, "Deferring loading of sound driver until a sound or music set is loaded");
		DriverFactoryBase::SelectDriver("null", Driver::Type::Sound);
	} else {
		InitSoundDriver();
	}

	if (_music_driver_params.empty() && BaseMusic::GetUsedSet()->name == "NoMusic") {
		Debug(driver, 1, "Deferring loading of music driver until a music set is loaded");
		DriverFactoryBase::SelectDriver("null", Driver::Type::Music);
	} else {
		InitMusicDriver(false);
	}

	GenerateWorld(GWM_EMPTY, 64, 64); // Make the viewport initialization happy
	LoadIntroGame(false);

	/* ScanNewGRFFiles now has control over the scanner. */
	RequestNewGRFScan(scanner.release());

	_general_worker_pool.Start("ottd:worker", 8);

	VideoDriver::GetInstance()->MainLoop();

	_general_worker_pool.Stop();

	PostMainLoop();
	return 0;
}

void InitMusicDriver(bool init_volume)
{
	if (_music_inited.exchange(true)) return;

	{
		std::unique_lock<std::mutex> lock(_music_driver_mutex);

		static std::unique_ptr<MusicDriver> old_driver;
		old_driver = MusicDriver::ExtractDriver();

		DriverFactoryBase::SelectDriver(_music_driver_params, Driver::Type::Music);
	}

	if (init_volume) MusicDriver::GetInstance()->SetVolume(_settings_client.music.music_vol);
}

void InitSoundDriver()
{
	if (_sound_inited.exchange(true)) return;

	{
		std::unique_lock<std::mutex> lock(_sound_driver_mutex);

		static std::unique_ptr<SoundDriver> old_driver;
		old_driver = SoundDriver::ExtractDriver();

		DriverFactoryBase::SelectDriver(_sound_driver_params, Driver::Type::Sound);
	}
}

void HandleExitGameRequest()
{
	if (_game_mode == GameMode::Menu || _game_mode == GameMode::Bootstrap) { // do not ask to quit on the main screen
		_exit_game = true;
	} else if (_settings_client.gui.autosave_on_exit) {
		DoExitSave();
		_survey.Transmit(NetworkSurveyHandler::Reason::Exit, true);
		_exit_game = true;
	} else {
		AskExitGame();
	}
}

/**
 * Triggers everything required to set up a saved scenario for a new game.
 */
static void OnStartScenario()
{
	/* Reset engine pool to simplify changing engine NewGRFs in scenario editor. */
	EngineOverrideManager::ResetToCurrentNewGRFConfig();

	/* Make sure all industries were built "this year", to avoid too early closures. (#9918) */
	for (Industry *i : Industry::Iterate()) {
		i->last_prod_year = EconTime::CurYear();
	}
}

/**
 * Triggers everything that should be triggered when starting a game.
 * @param dedicated_server Whether this is a dedicated server or not.
 */
static void OnStartGame(bool dedicated_server)
{
	/* Update the local company for a loaded game. It is either always
	 * a company or in the case of a dedicated server a spectator */
	if (_network_server && !dedicated_server) {
		NetworkServerDoMove(ClientID::Server, GetDefaultLocalCompany());
	} else {
		SetLocalCompany(dedicated_server ? COMPANY_SPECTATOR : GetDefaultLocalCompany());
	}
	if (_ctrl_pressed && !dedicated_server) {
		Command<Commands::Pause>::Post(PauseMode::Normal, true);
	}

	NetworkOnGameStart();

	/* Execute the game-start script */
	IConsoleCmdExec("exec scripts/game_start.scr 0");
}

static void MakeNewGameDone()
{
	SettingsDisableElrail(_settings_game.vehicle.disable_elrails);

	extern void PostCheckNewGRFLoadWarnings();
	PostCheckNewGRFLoadWarnings();

	/* In a dedicated server, the server does not play */
	if (!VideoDriver::GetInstance()->HasGUI()) {
		OnStartGame(true);
		if (_settings_client.gui.pause_on_newgame) Command<Commands::Pause>::Post(PauseMode::Normal, true);
		return;
	}

	/* Create a single company */
	DoStartupNewCompany(DSNC_NONE);

	Company *c = Company::Get(CompanyID::Begin());
	c->settings = _settings_client.company;

	/* Overwrite colour from settings if needed
	 * Colours::End corresponds to Random colour */

	if (_settings_client.gui.starting_colour != Colours::End) {
		Command<Commands::SetCompanyColour>::Post(LiveryScheme::Default, true, _settings_client.gui.starting_colour);
	}

	if (_settings_client.gui.starting_colour_secondary != Colours::End && _loaded_newgrf_features.used_liveries.Test(LiveryScheme::Default)) {
		Command<Commands::SetCompanyColour>::Post(LiveryScheme::Default, false, _settings_client.gui.starting_colour_secondary);
	}

	OnStartGame(false);

	InitializeRailGUI();
	InitializeRoadGUI();

	/* We are the server, we start a new company (not dedicated),
	 * so set the default password *if* needed. */
	if (_network_server && !_settings_client.network.default_company_pass.empty()) {
		NetworkChangeCompanyPassword(_local_company, _settings_client.network.default_company_pass);
	}

	if (_settings_client.gui.pause_on_newgame) Command<Commands::Pause>::Post(PauseMode::Normal, true);

	CheckEngines();
	CheckIndustries();
	MarkWholeScreenDirty();
}

/*
 * Too large size may be stored in settings (especially if switching between between OpenTTD
 * versions with different map size limits), we have to check if it is valid before generating world.
 * Simple separate checking of X and Y map sizes is not enough, as their sum is what counts for the limit.
 * Check the size and decrease the larger of the sizes till the size is in limit.
 */
static void FixConfigMapSize()
{
	while (_settings_game.game_creation.map_x + _settings_game.game_creation.map_y > MAX_MAP_TILES_BITS) {
		/* Repeat reducing larger of X/Y dimensions until the map size is within allowable limits */
		if (_settings_game.game_creation.map_x > _settings_game.game_creation.map_y) {
			_settings_game.game_creation.map_x--;
		} else {
			_settings_game.game_creation.map_y--;
		}
	}
}

static void MakeNewGame(bool from_heightmap, bool reset_settings)
{
	_game_mode = GameMode::Normal;
	if (!from_heightmap) {
		/* "reload" command needs to know what mode we were in. */
		_file_to_saveload.SetMode(FIOS_TYPE_INVALID, SaveLoadOperation::Invalid);
	}

	ResetGRFConfig(true);

	GenerateWorldSetCallback(&MakeNewGameDone);
	FixConfigMapSize();
	GenerateWorld(from_heightmap ? GWM_HEIGHTMAP : GWM_NEWGAME, 1 << _settings_game.game_creation.map_x, 1 << _settings_game.game_creation.map_y, reset_settings);
}

static void MakeNewEditorWorldDone()
{
	SetLocalCompany(OWNER_NONE);

	extern void PostCheckNewGRFLoadWarnings();
	PostCheckNewGRFLoadWarnings();
}

static void MakeNewEditorWorld()
{
	_game_mode = GameMode::Editor;
	/* "reload" command needs to know what mode we were in. */
	_file_to_saveload.SetMode(FIOS_TYPE_INVALID, SaveLoadOperation::Invalid);

	ResetGRFConfig(true);

	GenerateWorldSetCallback(&MakeNewEditorWorldDone);
	FixConfigMapSize();
	GenerateWorld(GWM_EMPTY, 1 << _settings_game.game_creation.map_x, 1 << _settings_game.game_creation.map_y);
}

/**
 * Load the specified savegame but on error do different things.
 * If loading fails due to corrupt savegame, bad version, etc. go back to
 * a previous correct state. In the menu for example load the intro game again.
 * @param filename file to be loaded
 * @param fop mode of loading, always SaveLoadOperation::Load
 * @param dft Type of file that is going to be loaded.
 * @param newgm switch to this mode of loading fails due to some unknown error
 * @param subdir default directory to look for filename, set to 0 if not needed
 * @param lf Load filter to use, if nullptr: use filename + subdir.
 * @param error_detail Optional string to fill with detaied error information.
 * @return \c true iff the save was loaded without problems.
 */
bool SafeLoad(const std::string &filename, SaveLoadOperation fop, DetailedFileType dft, GameMode newgm, Subdirectory subdir,
		std::shared_ptr<struct LoadFilter> lf = nullptr, std::string *error_detail = nullptr)
{
	assert(fop == SaveLoadOperation::Load);
	assert(dft == DetailedFileType::GameFile || (lf == nullptr && dft == DetailedFileType::OldGameFile));
	GameMode ogm = _game_mode;

	_game_mode = newgm;

	SaveLoadResult result = (lf == nullptr) ? SaveOrLoad(filename, fop, dft, subdir) : LoadWithFilter(std::move(lf));
	if (result == SaveLoadResult::Ok) return true;

	if (error_detail != nullptr) *error_detail = GetSaveLoadErrorType().GetDecodedString() + GetSaveLoadErrorMessage().GetDecodedString();

	if (_network_dedicated && ogm == GameMode::Menu) {
		/*
		 * If we are a dedicated server *and* we just were in the menu, then we
		 * are loading the first savegame. If that fails, not starting the
		 * server is a better reaction than starting the server with a newly
		 * generated map as it is quite likely to be started from a script.
		 */
		Debug(net, 0, "Loading requested map failed; closing server.");
		_exit_game = true;
		return false;
	}

	if (result != SaveLoadResult::ReInit) {
		_game_mode = ogm;
		return false;
	}

	if (_network_dedicated) {
		/*
		 * If we are a dedicated server, have already loaded/started a game,
		 * and then loading the savegame fails in a manner that we need to
		 * reinitialize everything. We must not fall back into the menu mode
		 * with the intro game, as that is unjoinable by clients. So there is
		 * nothing else to do than start a new game, as it might have failed
		 * trying to reload the originally loaded savegame/scenario.
		 */
		Debug(net, 0, "Loading game failed, so a new (random) game will be started");
		MakeNewGame(false, true);
		return false;
	}

	if (_network_server) {
		/* We can't load the intro game as server, so disconnect first. */
		NetworkDisconnect();
	}

	switch (ogm) {
		default:
		case GameMode::Menu: LoadIntroGame(); break;
		case GameMode::Editor: MakeNewEditorWorld(); break;
	}
	return false;
}

static void UpdateSocialIntegration(GameMode game_mode)
{
	switch (game_mode) {
		case GameMode::Bootstrap:
		case GameMode::Menu:
			SocialIntegration::EventEnterMainMenu();
			break;

		case GameMode::Normal:
			if (_networking) {
				SocialIntegration::EventEnterMultiplayer(Map::SizeX(), Map::SizeY());
			} else {
				SocialIntegration::EventEnterSingleplayer(Map::SizeX(), Map::SizeY());
			}
			break;

		case GameMode::Editor:
			SocialIntegration::EventEnterScenarioEditor(Map::SizeX(), Map::SizeY());
			break;
	}
}

void SwitchToMode(SwitchMode new_mode)
{
	/* If we are saving something, the network stays in its current state */
	if (new_mode != SwitchMode::SaveGame) {
		/* If the network is active, make it not-active */
		if (_networking) {
			if (_network_server && (new_mode == SwitchMode::LoadGame || new_mode == SwitchMode::NewGame || new_mode == SwitchMode::RestartGame)) {
				NetworkReboot();
			} else {
				NetworkDisconnect();
			}
		}

		/* If we are a server, we restart the server */
		if (_is_network_server) {
			/* But not if we are going to the menu */
			if (new_mode != SwitchMode::Menu) {
				/* check if we should reload the config */
				if (_settings_client.network.reload_cfg) {
					LoadFromConfig();
					MakeNewgameSettingsLive();
					ResetGRFConfig(false);
				}
				NetworkServerStart();
			} else {
				/* This client no longer wants to be a network-server */
				_is_network_server = false;
			}
		}
	}

	/* Make sure all AI controllers are gone at quitting game */
	if (new_mode != SwitchMode::SaveGame) AI::KillAll();

	/* When we change mode, reset the autosave. */
	if (new_mode != SwitchMode::SaveGame) ChangeAutosaveFrequency(true);

	/* Transmit the survey if we were in normal-mode and not saving. It always means we leaving the current game. */
	if (_game_mode == GameMode::Normal && new_mode != SwitchMode::SaveGame) _survey.Transmit(NetworkSurveyHandler::Reason::Leave);

	/* Keep track when we last switch mode. Used for survey, to know how long someone was in a game. */
	if (new_mode != SwitchMode::SaveGame) {
		_game_session_stats.start_time = std::chrono::steady_clock::now();
		_game_session_stats.savegame_size = std::nullopt;
	}

	switch (new_mode) {
		case SwitchMode::Editor: // Switch to scenario editor
			MakeNewEditorWorld();
			GenerateSavegameId();

			UpdateSocialIntegration(GameMode::Editor);
			break;

		case SwitchMode::ReloadGame: // Reload with what-ever started the game
			if (_file_to_saveload.ftype.abstract == AbstractFileType::Savegame || _file_to_saveload.ftype.abstract == AbstractFileType::Scenario) {
				/* Reload current savegame/scenario */
				_switch_mode = _game_mode == GameMode::Editor ? SwitchMode::LoadScenario : SwitchMode::LoadGame;
				SwitchToMode(_switch_mode);
				break;
			} else if (_file_to_saveload.ftype.abstract == AbstractFileType::Heightmap) {
				/* Restart current heightmap */
				_switch_mode = _game_mode == GameMode::Editor ? SwitchMode::LoadHeightmap : SwitchMode::RestartHeightmap;
				SwitchToMode(_switch_mode);
				break;
			}

			MakeNewGame(false, new_mode == SwitchMode::NewGame);
			GenerateSavegameId();

			UpdateSocialIntegration(GameMode::Normal);
			break;

		case SwitchMode::RestartGame: // Restart --> 'Random game' with current settings
		case SwitchMode::NewGame: // New Game --> 'Random game'
			MakeNewGame(false, new_mode == SwitchMode::NewGame);
			GenerateSavegameId();

			UpdateSocialIntegration(GameMode::Normal);
			break;

		case SwitchMode::LoadGame: { // Load game, Play Scenario
			ResetGRFConfig(true);
			ResetWindowSystem();

			if (!SafeLoad(_file_to_saveload.name, _file_to_saveload.file_op, _file_to_saveload.ftype.detailed, GameMode::Normal, Subdirectory::None)) {
				ShowErrorMessage(GetSaveLoadErrorType(), GetSaveLoadErrorMessage(), WarningLevel::Critical);
			} else {
				if (_file_to_saveload.ftype.abstract == AbstractFileType::Scenario) {
					OnStartScenario();
				}
				OnStartGame(_network_dedicated);
				/* Decrease pause counter (was increased from opening load dialog) */
				Command<Commands::Pause>::Post(PauseMode::SaveLoad, false);
			}

			UpdateSocialIntegration(GameMode::Normal);
			break;
		}

		case SwitchMode::RestartHeightmap: // Load a heightmap and start a new game from it with current settings
		case SwitchMode::StartHeightmap: // Load a heightmap and start a new game from it
			MakeNewGame(true, new_mode == SwitchMode::StartHeightmap);
			GenerateSavegameId();

			UpdateSocialIntegration(GameMode::Normal);
			break;

		case SwitchMode::LoadHeightmap: // Load heightmap from scenario editor
			SetLocalCompany(OWNER_NONE);

			_game_mode = GameMode::Editor;

			FixConfigMapSize();
			GenerateWorld(GWM_HEIGHTMAP, 1 << _settings_game.game_creation.map_x, 1 << _settings_game.game_creation.map_y);
			GenerateSavegameId();
			MarkWholeScreenDirty();

			UpdateSocialIntegration(GameMode::Editor);
			break;

		case SwitchMode::LoadScenario: { // Load scenario from scenario editor
			if (SafeLoad(_file_to_saveload.name, _file_to_saveload.file_op, _file_to_saveload.ftype.detailed, GameMode::Editor, Subdirectory::None)) {
				SetLocalCompany(OWNER_NONE);
				GenerateSavegameId();
				_settings_newgame.game_creation.starting_year = CalTime::CurYear();
				/* Cancel the saveload pausing */
				Command<Commands::Pause>::Post(PauseMode::SaveLoad, false);
			} else {
				ShowErrorMessage(GetSaveLoadErrorType(), GetSaveLoadErrorMessage(), WarningLevel::Critical);
			}

			UpdateSocialIntegration(GameMode::Editor);
			break;
		}

		case SwitchMode::JoinGame: // Join a multiplayer game
			LoadIntroGame();
			NetworkClientJoinGame();

			SocialIntegration::EventJoiningMultiplayer();
			break;

		case SwitchMode::Menu: // Switch to game intro menu
			LoadIntroGame();
			if (BaseSounds::ini_set.empty() && BaseSounds::GetUsedSet()->fallback && SoundDriver::GetInstance()->HasOutput()) {
				ShowErrorMessage(GetEncodedString(STR_WARNING_FALLBACK_SOUNDSET), {}, WarningLevel::Critical);
				BaseSounds::ini_set = BaseSounds::GetUsedSet()->name;
			}
			if (_settings_client.network.participate_survey == ParticipateSurvey::Ask) {
				/* No matter how often you go back to the main menu, only ask the first time. */
				static bool asked_once = false;
				if (!asked_once) {
					asked_once = true;
					ShowNetworkAskSurvey();
				}
			}

			UpdateSocialIntegration(GameMode::Menu);
			break;

		case SwitchMode::SaveGame: { // Save game.
			/* Make network saved games on pause compatible to singleplayer mode */
			SaveModeFlags flags = SMF_NONE;
			if (_game_mode == GameMode::Editor) flags |= SMF_SCENARIO;
			if (SaveOrLoad(_file_to_saveload.name, SaveLoadOperation::Save, DetailedFileType::GameFile, Subdirectory::None, true, flags) != SaveLoadResult::Ok) {
				ShowErrorMessage(GetSaveLoadErrorType(), GetSaveLoadErrorMessage(), WarningLevel::Error);
			} else {
				CloseWindowById(WindowClass::SaveLoad, 0);
			}
			break;
		}

		case SwitchMode::SaveHeightmap: // Save heightmap.
			MakeHeightmapScreenshot(_file_to_saveload.name.c_str());
			CloseWindowById(WindowClass::SaveLoad, 0);
			break;

		case SwitchMode::GenerateRandomLand: // Generate random land within scenario editor
			SetLocalCompany(OWNER_NONE);
			FixConfigMapSize();
			GenerateWorld(GWM_RANDOM, 1 << _settings_game.game_creation.map_x, 1 << _settings_game.game_creation.map_y);
			/* XXX: set date */
			MarkWholeScreenDirty();
			break;

		default: NOT_REACHED();
	}

	SmallMapWindow::RebuildColourIndexIfNecessary();
}

void WriteVehicleInfo(format_target &buffer, const Vehicle *u, const Vehicle *v, uint length)
{
	buffer.format(": type {}, vehicle {} ({}), company {}, unit number {}, wagon {}, engine: ",
			u->type, u->index, v->index, u->owner, v->unitnumber, length);
	AppendStringInPlace(buffer, STR_ENGINE_NAME, u->engine_type);
	GrfID grfid = u->GetGRFID();
	if (!grfid.Empty()) {
		buffer.format(", GRF:{}", grfid);
		GRFConfig *grfconfig = GetGRFConfig(grfid);
		if (grfconfig) {
			buffer.format(", {}, {}", grfconfig->GetName(), grfconfig->filename);
		}
	}
}

/**
 * State controlling game loop.
 * The state must not be changed from anywhere but here.
 * That check is enforced in DoCommand.
 */
void StateGameLoop()
{
	/* A setting command can enable routing in this frame. Finish that network
	 * frame without advancing simulation; prepare at its boundary on every peer. */
	if (_game_mode == GameMode::Normal && GetPassengerServiceDatabase().IsPreparingPrecomputed()) return;
	if (!_networking || _network_server) {
		StateGameLoop_LinkGraphPauseControl();
	}

	/* Don't execute the state loop during pause or when modal windows are open. */
	if (_pause_mode.Any() || HasModalProgress()) {
		PerformanceMeasurer::Paused(PerformanceElement::GameLoop);
		PerformanceMeasurer::Paused(PerformanceElement::GameLoopEconomy);
		PerformanceMeasurer::Paused(PerformanceElement::GameLoopTrains);
		PerformanceMeasurer::Paused(PerformanceElement::GameLoopRoadVehicles);
		PerformanceMeasurer::Paused(PerformanceElement::GameLoopShips);
		PerformanceMeasurer::Paused(PerformanceElement::GameLoopAircraft);
		PerformanceMeasurer::Paused(PerformanceElement::GameLoopLandscape);

		if (!HasModalProgress()) UpdateLandscapingLimits();
#ifndef DEBUG_DUMP_COMMANDS
		if (_game_mode == GameMode::Normal) Game::GameLoop();
#endif
		return;
	}

	PerformanceMeasurer framerate(PerformanceElement::GameLoop);
	const auto passenger_tick_started = std::chrono::steady_clock::now();
	PerformanceAccumulator::Reset(PerformanceElement::GameLoopLandscape);

	if (_game_mode == GameMode::Editor) {
		BasePersistentStorageArray::SwitchMode(PSM_ENTER_GAMELOOP);

		/* _state_ticks and _state_ticks_offset must update in lockstep here,
		 * as _date, _tick_skip_counter, etc are not updated in the scenario editor,
		 * but _state_ticks should still update in case there are vehicles running,
		 * to avoid problems with timetables and train speed adaptation
		 */
		_state_ticks++;
		DateDetail::_state_ticks_offset++;
		BeginPassengerJourneyTick();
		GetPassengerServiceDatabase().Tick(PassengerServiceDatabase::BUILD_WORK, true, true);
		RunPassengerWaitingEvents();

		RunTileLoop();
		CallVehicleTicks();
		CallLandscapeTick();
		TimerManager<TimerGameTick>::Elapsed(1);
		BasePersistentStorageArray::SwitchMode(PSM_LEAVE_GAMELOOP);
		UpdateLandscapingLimits();

		CallWindowGameTickEvent();
		NewsLoop();
	} else {
		if (GetDebugLevel(DebugLevelID::desync) > 2 && DateDetail::_tick_skip_counter == 0 && EconTime::CurDateFract() == 0 && (EconTime::CurDate().base() & 0x1F) == 0) {
			/* Save the desync savegame if needed. */
			std::string name = fmt::format("dmp_cmds_{:08x}_{:08x}.sav", _settings_game.game_creation.generation_seed, EconTime::CurDate());
			SaveOrLoad(name, SaveLoadOperation::Save, DetailedFileType::GameFile, Subdirectory::Autosave, false);
		}

		CheckCaches(false, nullptr, CHECK_CACHE_ALL | CHECK_CACHE_EMIT_LOG);

		/* All these actions has to be done from OWNER_NONE
		 *  for multiplayer compatibility */
		AutoRestoreBackup cur_company(_current_company, OWNER_NONE);

		BasePersistentStorageArray::SwitchMode(PSM_ENTER_GAMELOOP);
		DateDetail::_tick_skip_counter++;
		_scaled_tick_counter++;
		if (_game_mode != GameMode::Bootstrap) {
			_state_ticks++;   // This must update in lock-step with _tick_skip_counter, such that _state_ticks_offset doesn't need to be changed.
		}
		BeginPassengerJourneyTick();
		GetPassengerServiceDatabase().Tick(PassengerServiceDatabase::BUILD_WORK, true, true);
		RunPassengerWaitingEvents();

		if (!(_game_mode == GameMode::Menu || _game_mode == GameMode::Bootstrap) && !_settings_client.gui.autosave_realtime && _settings_client.gui.autosave_interval != 0 &&
				(_state_ticks.base() % (_settings_client.gui.autosave_interval * (60000 / MILLISECONDS_PER_TICK))) == 0) {
			_do_autosave = true;
			_check_special_modes = true;
			SetWindowDirty(WindowClass::Statusbar, 0);
		}

		RunAuxiliaryTileLoop();
		if (DateDetail::_tick_skip_counter < DayLengthFactor()) {
			if (_settings_game.economy.timekeeping_units == TimekeepingUnits::Wallclock && !(_game_mode == GameMode::Menu || _game_mode == GameMode::Bootstrap)) {
				IncreaseCalendarDate();
			}
			AnimateAnimatedTiles();
			RunTileLoop(true);
			CallVehicleTicks();
			OnTick_Companies(false);
		} else {
			DateDetail::_tick_skip_counter = 0;
			IncreaseDate();
			AnimateAnimatedTiles();
			RunTileLoop(true);
			CallVehicleTicks();
			CallLandscapeTick();
			OnTick_Companies(true);
		}
		OnTick_LinkGraph();
		TimerManager<TimerGameTick>::Elapsed(1);
		BasePersistentStorageArray::SwitchMode(PSM_LEAVE_GAMELOOP);

#ifndef DEBUG_DUMP_COMMANDS
		{
			PerformanceMeasurer script_framerate(PerformanceElement::AllScripts);
			AI::GameLoop();
			Game::GameLoop();
		}
#endif
		UpdateLandscapingLimits();

		CallWindowGameTickEvent();
		NewsLoop();

		if (_networking) {
			RecordSyncEvent(NSRE_PRE_DATES);
			UpdateStateChecksum(_tick_counter);
			UpdateStateChecksum(_scaled_tick_counter);
			UpdateStateChecksum(_state_ticks.base());
			UpdateStateChecksum(CalTime::CurDate().base());
			UpdateStateChecksum(CalTime::CurDateFract());
			UpdateStateChecksum(CalTime::CurSubDateFract());
			UpdateStateChecksum(EconTime::CurDate().base());
			UpdateStateChecksum(EconTime::CurDateFract());
			UpdateStateChecksum(TickSkipCounter());

			RecordSyncEvent(NSRE_PRE_COMPANY_STATE);
			for (Company *c : Company::Iterate()) {
				DEBUG_UPDATESTATECHECKSUM("Company: {}, Money: {}", c->index, (int64_t)c->money);
				UpdateStateChecksum(c->money);

				for (uint i = 0; i < ROADTYPE_END; i++) {
					DEBUG_UPDATESTATECHECKSUM("Company: {}, road[{}]: {}", c->index, i, c->infrastructure.road[i]);
					UpdateStateChecksum(c->infrastructure.road[i]);
				}

				for (uint i = 0; i < RAILTYPE_END; i++) {
					DEBUG_UPDATESTATECHECKSUM("Company: {}, rail[{}]: {}", c->index, i, c->infrastructure.rail[i]);
					UpdateStateChecksum(c->infrastructure.rail[i]);
				}

				DEBUG_UPDATESTATECHECKSUM("Company: {}, signal: {}, water: {}, station: {}, airport: {}",
						c->index, c->infrastructure.signal, c->infrastructure.water, c->infrastructure.station, c->infrastructure.airport);
				UpdateStateChecksum(c->infrastructure.signal);
				UpdateStateChecksum(c->infrastructure.water);
				UpdateStateChecksum(c->infrastructure.station);
				UpdateStateChecksum(c->infrastructure.airport);
			}
		}
	}
	if (_extra_aspects > 0) FlushDeferredAspectUpdates();

	if (_pause_countdown > 0 && --_pause_countdown == 0) {
		_pause_mode = PauseMode::Normal;
		SetWindowDirty(WindowClass::MainToolbar, 0);
	}

	dbg_assert(IsLocalCompany());
	if (_game_mode == GameMode::Normal) RecordPassengerJourneySimulationTick(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - passenger_tick_started).count());
}

FiosNumberedSaveName &GetAutoSaveFiosNumberedSaveName()
{
	static FiosNumberedSaveName _autosave_ctr("autosave");
	return _autosave_ctr;
}

FiosNumberedSaveName &GetLongTermAutoSaveFiosNumberedSaveName()
{
	static FiosNumberedSaveName _autosave_lt_ctr("ltautosave");
	return _autosave_lt_ctr;
}

/**
 * Create an autosave. The default name is "autosave#.sav". However with
 * the setting 'keep_all_autosave' the name defaults to company-name + date
 */
static void DoAutosave()
{
	FiosNumberedSaveName *lt_counter = nullptr;
	if (_settings_client.gui.max_num_autosaves > 0) {
		lt_counter = &GetLongTermAutoSaveFiosNumberedSaveName();
	}
	DoAutoOrNetsave(GetAutoSaveFiosNumberedSaveName(), true, lt_counter);
}

/** Interval for regular autosaves. Initialized at zero to disable till settings are loaded. */
static IntervalTimer<TimerGameRealtime> _autosave_interval({std::chrono::milliseconds::zero(), TimerGameRealtime::Trigger::Autosave}, [](auto)
{
	/* We reset the command-during-pause mode here, so we don't continue
	 * to make auto-saves when nothing more is changing. */
	_pause_mode.Reset(PauseMode::CommandDuringPause);

	_do_autosave = true;
	DoAutosave();
	_do_autosave = false;
	SetWindowDirty(WindowClass::Statusbar, 0);
});

/**
 * Reset the interval of the autosave.
 *
 * If reset is not set, this does not set the elapsed time on the timer,
 * so if the interval is smaller, it might result in an autosave being done
 * immediately.
 *
 * @param reset Whether to reset the timer back to zero, or to continue.
 */
void ChangeAutosaveFrequency(bool reset)
{
	std::chrono::minutes interval = _settings_client.gui.autosave_realtime ? std::chrono::minutes(_settings_client.gui.autosave_interval) : std::chrono::minutes::zero();
	_autosave_interval.SetInterval({interval, TimerGameRealtime::Trigger::Autosave}, reset);
}

/**
 * Request a new NewGRF scan. This will be executed on the next game-tick.
 * This is mostly needed to ensure NewGRF scans (which are blocking) are
 * done in the game-thread, and not in the draw-thread (which most often
 * triggers this request).
 * @param callback Optional callback to call when NewGRF scan is completed.
 * @return True when the NewGRF scan was actually requested, false when the scan was already running.
 */
bool RequestNewGRFScan(NewGRFScanCallback *callback)
{
	if (_request_newgrf_scan) return false;

	_request_newgrf_scan = true;
	_request_newgrf_scan_callback = callback;
	return true;
}

void GameLoopSpecial()
{
	/* autosave game? */
	if (_do_autosave) {
		DoAutosave();
		_do_autosave = false;
		SetWindowDirty(WindowClass::Statusbar, 0);
	}

	extern std::string _switch_baseset;
	if (!_switch_baseset.empty()) {
		if (BaseGraphics::GetUsedSet()->name != _switch_baseset) {
			BaseGraphics::SetSetByName(_switch_baseset);

			ReloadNewGRFData();
		}
		_switch_baseset.clear();
	}

	extern std::function<void()> _exec_with_generate_world;
	if (_exec_with_generate_world) {
		ExecuteWithGenerateWorld(std::move(_exec_with_generate_world));
		_exec_with_generate_world = nullptr;
	}

	_check_special_modes = false;
}

void GameLoop()
{
	if (_game_mode == GameMode::Bootstrap) {
		/* Check for UDP stuff */
		if (_network_available) NetworkBackgroundLoop();
		return;
	}

	if (_request_newgrf_scan) {
		ScanNewGRFFiles(_request_newgrf_scan_callback);
		_request_newgrf_scan = false;
		_request_newgrf_scan_callback = nullptr;
		/* In case someone closed the game during our scan, don't do anything else. */
		if (_exit_game) return;
	}

	ProcessAsyncSaveFinish();

	if (unlikely(_check_special_modes)) GameLoopSpecial();

	if (_game_mode == GameMode::Normal) {
		static auto last_time = std::chrono::steady_clock::now();
		auto now = std::chrono::steady_clock::now();
		auto delta_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_time);
		if (delta_ms.count() != 0) {
			TimerManager<TimerGameRealtime>::Elapsed(delta_ms);
			last_time = now;
		}
	}

	/* switch game mode? */
	if (_switch_mode != SwitchMode::None && !HasModalProgress()) {
		SwitchToMode(_switch_mode);
		_switch_mode = SwitchMode::None;
		if (_exit_game) return;
	}

	IncreaseSpriteLRU();

	/* Check for UDP stuff */
	if (_network_available) NetworkBackgroundLoop();

	DebugSendRemoteMessages();
	UpdateInitialPassengerProgress();

	/* Initial trees and replacement graph preparation yield to video/input
	 * between slices, including while paused. Network peers use the shared
	 * frame barrier in NetworkGameLoop before resuming simulation. */
	if (!_networking && _game_mode == GameMode::Normal && !HasModalProgress()) {
		const auto started = std::chrono::steady_clock::now();
		bool ready;
		try {
			do {
				ready = GetPassengerServiceDatabase().PreparePrecomputed();
			} while (!ready && std::chrono::steady_clock::now() - started < std::chrono::milliseconds(8));
		} catch (const std::exception &) {
			/* Deferred singleplayer replay now runs outside SafeLoad's error
			 * boundary. An invalid saved cursor must still return to the menu. */
			if (GetPassengerServiceDatabase().GetLoadState() != PassengerServiceDatabase::LoadState::Invalid) throw;
			auto type = GetSaveLoadErrorType();
			auto message = GetSaveLoadErrorMessage();
			SwitchToMode(SwitchMode::Menu);
			ShowErrorMessage(std::move(type), std::move(message), WarningLevel::Critical);
			return;
		}
		UpdateInitialPassengerProgress();
		if (!ready) {
			SetWindowDirty(WindowClass::Statusbar, 0);
			ExecuteCommandQueue();
			SoundDriver::GetInstance()->MainLoop();
			MusicLoop();
			SocialIntegration::RunCallbacks();
			return;
		}
	}

    if (!_networking && _game_mode == GameMode::Normal && WaitingProbe::Complete("singleplayer")) return;
	if (_networking && !HasModalProgress()) {
		/* Multiplayer */
		NetworkGameLoop();
		UpdateInitialPassengerProgress();
	} else {
		if (_network_reconnect > 0 && --_network_reconnect == 0) {
			/* This means that we want to reconnect to the last host
			 * We do this here, because it means that the network is really closed */
			NetworkClientConnectGame(_settings_client.network.last_joined, COMPANY_SPECTATOR);
		}
		/* Singleplayer */
		StateGameLoop();
	}
	ExecuteCommandQueue();

	if (_pause_mode.None() && _display_opt.Test(DisplayOption::FullAnimation)) {
		extern std::mutex _cur_palette_mutex;
		std::lock_guard<std::mutex> lock_state(_cur_palette_mutex);
		DoPaletteAnimations();
	}

	SoundDriver::GetInstance()->MainLoop();
	MusicLoop();
	SocialIntegration::RunCallbacks();
}
